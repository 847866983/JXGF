# PROJECT.md — 班长全家桶（ComfyUI-Banzhang-All）

> 目录 + 进度 + 已知问题。每次大改动后更新。

## 目录速览

| 路径 | 内容 |
|---|---|
| `__init__.py` | 节点注册（`WEB_DIRECTORY = "./js"`，静态路径 `/extensions/ComfyUI-Banzhang-All/<文件>`，**不带 js/ 前缀**） |
| `banzhang_*.py` / `csglide_*.py` | 节点后端，一节点一文件 |
| `js/` | 前端 ES module；`js/bvl/`、`js/core/` 等子目录靠相对 import |
| `js/painter_video.js` | 视频合并节点（预览 + 调色 + 同步控制器） |
| `js/minimax_h3_preview.js` | H3 采样预览面板（MiniMaxH3PreviewOverride） |
| `js/csglide_film.js` / `join_panel.js` / `rack_*.js` | 导演台 / 接片 / 媒体架 |
| `js/banzhang_dev_utils.js` | 执行时间徽章（rAF 仅执行期间跑） |
| `templates/` | 制片中枢工作流模板 + 自测脚本 |
| `tests/` | 自测总入口 `run_all.mjs`；前端用例在 `tests/js/`（`node tests/run_all.mjs`） |
| `docs/` | 设计/使用文档；`docs/AI节点开发铁律.md` 为开发必读 |

## 2026-10-18 前端性能专项（内存 + 卡顿）

### 已确认根因（有实测数据）

1. **视频解码缓冲不释放（内存大头）**：`<video>` 播放过就把整片留在内存，3 个视频合并节点共约 1GB+（用户实测：删掉一个节点内存立刻回落）。`preload="metadata"` 挡不住。
2. **每帧强制回流（卡顿）**：litegraph 渲染循环 `renderFrame` 无脏门控，每帧 `draw()` → 每可见节点 `arrange()` → `computeLayoutSize` 每帧读 `clientWidth`/`offsetHeight`（每节点每帧 2 次同步布局）。叠加官方 `Comfy.DOMClippingEnabled`（**默认 true**，每 DOM 控件每帧 2 次 `getBoundingClientRect`）。
3. **退出同步重新点燃解码**：`VideoSyncController.disable()` 曾对全部视频 `play()`（含视口外），muted 视频被浏览器放行 → 3 路 loop 解码（实测 CPU 148%）。
4. **H3 预览同款自播**：videoEl `muted+loop+autoplay` + `showVideo` 无条件 `play()`；`tickScrub` 常驻 rAF 每帧写 `style.width`。

### 本次改动（备份 `.bak_reflow_idle_20261018` / `.bak_pre_mse_20261018`）

| 文件 | 改动 |
|---|---|
| `js/painter_video.js` | ① `previewContentW`/`domChrome` 按节点宽缓存，宽度不变零 DOM 读；② 首帧截 `<img>` 海报（**缩到节点显示宽度、上限 640**：只用于显示和算宽高比，1080p 全尺寸解码位图约 8MB/张常驻）+ 空闲 20s 释放；③ `disable()` 退出同步不再 play 全部视频 |
| `js/minimax_h3_preview.js` | ① videoEl 去 autoplay，`showVideo` 显首帧；② `tickScrub` 改播放时才跑 rAF |

**MSE 已整体移除（2026-10-19，用户决定）**

实测证明 16 秒级短片走 MSE 是**负优化**——普通 src 是 Chrome 内部一份压缩数据 + 解码帧（空闲释放已管住）；MSE 是 `m.media` 段数组一份 + SourceBuffer 内部再一份（`appendBuffer` 是拷贝）+ mp4box 解析峰值，而 trim 阈值是播放点前 5 秒，16 秒片播到第 10 秒才第一次 remove，收益≈0，固定开销实打实（3 节点实测 +0.3G）。代码存档 `.bak_mse_full_20261019`，将来若出现分钟级长片预览需求再取回。

**MSE 踩坑记录（已随代码移除，仅存档知识）**

1. **codec 不能猜**：`MediaSource.isTypeSupported('video/mp4; codecs="avc1.640028"')` 返回 true 只证明"浏览器支持这个串"，不证明"文件是这个串"；猜错就在 `appendBuffer` 时报 `append error`。实测同一工作流产出过 4 种 codec：`avc1.640020` / `avc1.4d4015` / `avc1.4d401f` / `avc1.640028`，猜 6 个候选只覆盖一半。正解 = mp4box demux 读 moov。
2. **mp4box 三段式 API 顺序不能省**（2024-02-11 构建实测）：`setSegmentOptions(trackId)` 注册 fragmentedTracks → **`initializeSegmentation()`**（置位 `isFragmentationInitialized` 并**返回** init segment——它自己构造只含目标轨的 moov）→ `start()` 后 `onSegment` 只推**媒体段**。少了 `initializeSegmentation`，`processSamples` 的 onSegment 分支整个不跑（静默无输出，不报错）。`setExtractionOptions`+`onSamples` 是样本级 API，与 `onSegment` 二选一，混用无效。
3. mime 只声明视频轨时，append 的数据也必须只有视频轨（mp4box 抽纯视频轨的意义）；`+empty_moov` 无总时长靠 `ms.duration = 帧数/帧率` 补。
4. hydrate（刷新后自动加载预览）**绝不能走 MSE 全量通路**：3 个节点各 fetch 整文件 + demux + 全量 append + 预解码帧 → 初始内存 +0.3G 且要等 20 秒空闲释放。

行为变化（对用户可见）：空闲 20 秒后视频合并节点显示首帧海报，点击画面即播（有 0.3~2s 装回延迟）；H3 预览成片不再自动循环播。

### 排除项（有证据，别再重复排查）

- 同步预览功能：开关不持久化，不开 = 零开销
- 执行时间统计（`banzhang_dev_utils.js`）：rAF 仅执行期间，结束/中断/报错都停
- 网易UU远程（GameViewerServer）：占 GPU 3D 24% + 编码 20%，与 ComfyUI 无关，用户确认未使用
- 显存：空闲 1424MiB/24576MiB，模型不驻留显存，正常
- 视频解码：诊断确认 6 个 video 全部 `paused: true`

### 待办 / 已知问题

- [ ] 官方 DOMClipping 默认开启的每帧回流：已在对话中给用户设置项开关（`Comfy.DOMClippingEnabled`），未在代码侧处理
- [ ] litegraph 无脏门控的全帧重绘是上游行为，本包无法根治；本包侧已做到 arrange 路径零回流
- [ ] 视频合并节点「前端窗口不跟随节点边框」：曾因删 healNode 巡逻出现，待用户真机复现确认
- [ ] 浏览器扩展会给 video 注入随机 class（如 `mtz-vlc-*`），排查时别误判

## 2026-10-19 拖动节点边角卡顿 + 底部空白

**根因**：`js/bz_ui_scheduler.js` 的「交互优先」策略把「用户亲手拖边角」也当成「扩展自发布局」推迟了。

上游 litegraph 拖边角是在 `pointer.onDrag` 里每移动一次鼠标执行
`node.computeSize()` → `node.setSize(newBounds.size)` → `#dirty()`，尺寸靠 setSize 落地（不是直接改 size 数组）。
被推迟后：拖动全程尺寸不更新、只有 `node.pos` 更新 → 鼠标在动节点不动 = 卡顿感；
松手后 `flushPending` 一次性补做 → 尺寸跳变 → 底部多出一截与拖动终点对不上的空白。

**改动**（备份 `js/bz_ui_scheduler.js.bak_preresize_20261019`）

| 文件 | 改动 |
|---|---|
| `js/bz_ui_scheduler.js` | `hookSetSize` 新增 `isResizeTarget(node)`（查 `LGraphCanvas.active_canvas.resizing_node` + `graph.list_of_graphcanvas`），命中的尺寸实时执行、不进 `pendingSize` |

**曾误改并已回退**：同一轮顺手把 `hookSetDirtyCanvas` 改成「按节点记录 fg/bg、不再一律 `(true,true)`」——
结果所有节点拉大后松手就缩回原尺寸（详见下面经验 5）。**合并必须仍按 `(true,true)` 全量重绘发出，不能省。**

**状态：已真机验证通过**（2026-10-19）。`resizing_node` 判定在该版本前端有效。

### 经验（本次沉淀，别再重犯）

1. **任何「为了性能把写入推迟/节流/批处理」的机制，必须先分两类写入**：
   **用户直接操作的写入**（拖边角、拖滑块、打字）永远实时，推迟 = 不跟手 = 用户口中的「卡」；
   **代码自发的写入**（扩展重算布局、批量刷新）才可以推迟/合并。
   `bz_ui_scheduler` 的坑就是拿一个粗粒度状态 `interacting`（pointerdown 置 true）去拦所有 `setSize`，
   把用户亲手拖的边角也一起推迟了。
   → 判定条件要从「是否在交互中」升级为「是不是这次交互的目标对象」。
2. **节流/合并类 hook 容易把所有请求一律升格成最贵那一档，是隐性性能债**。
   本次 `setDirtyCanvas` 合并时无论调用方传什么都写成 `(true, true)`，等于每帧全量重绘。
   → 合并要「按目标取并集」，不能图省事写死最贵参数。
3. **排查上游行为别凭记忆，去前端包里挖真实调用链**：
   `python_embeded/Lib/site-packages/comfyui_frontend_package/static/assets/*.js.map` 里有完整未压缩源码。
   超长单行 grep 不到上下文时用 `grep -o -E "关键字.{1400}" xxx.js.map | head -2` 逐段往后扒。
   本次靠它确认了 `pointer.onDrag → computeSize() → setSize(newBounds.size) → #dirty()`，
   才锁定「尺寸靠 setSize 落地」这个关键前提 —— 否则根本想不到是调度器拦的。
4. **症状翻译**：用户说「缩放卡顿」+「拉高后底部多空白」= 拖动时尺寸不更新（不跟手）+ 松手后尺寸跳变。
   → 凡「鼠标在动、东西不动」，先查有没有全局 hook 拦住写入，别急着怀疑节点多或渲染慢。
5. **别顺手改无关代码 —— 这次当场翻车**：
   修拖拽时顺手「优化」了 `setDirtyCanvas` 的合并逻辑（把一律 `(true,true)` 改成按节点记录 fg/bg）。
   结果：只脏前景时 DOM 容器高度跟不上 `node.size`，而新版前端 `GraphView` 有一条
   **DOM→节点的单向尺寸覆盖** —— 只要 `liteNode.size` 与 Vue 算的 `layout.size` 不相等，
   就用 `layout.size` **覆盖**（不是取大）。于是手动拉大的节点松手瞬间被缩回内容高度。
   → 两条硬结论：① 该文件的重绘合并**必须**发 `(true,true)`，这是功能依赖不是性能债；
   ② 修 A 问题时别顺手改 B，哪怕 B 看起来确实是浪费。

### 待办 / 已知问题

- [ ] 遗留：5 处手算高度（`selflift_avatar.js:109` 的 `+170`、`note.js:563/651`、`minimax_h3_preview.js:366`、`painter_video.js:928`）—— 只影响单节点，与「所有节点都卡」无关，另开一轮清理
- [ ] `banzhang_widget_width_fix.js` 把 widget.width 强制 undefined，拖宽度时 DOM 每帧重排；修的是官方 #12443，本轮未动
- [ ] 同类自查未做：全局还有 `banzhang_note.js:753` / `banzhang_universal_slider.js:557` 两个 `drawNode` 猴子补丁，以及其它「为了性能」加的钩子，是否也踩了「一刀切」的毛病

## 2026-10-19 🎬 剧本全流程生图 V2（标签页 · 流程透明 · 单张重生）

V1 痛点：流程不透明、不能及时改正、节点太长。V2 重新设计：
- 顶部 4 步步骤条（解析→资产→核心帧→完成），实时状态与计数；
- 4 个标签页：📁 文件 / 🖼️ 资产 / 🎬 核心帧 / 📊 日志，面板高度固定、内容滚动；
- 每卡片：🔄 重生（立即单张重跑，不排队）、🔒 锁定（整批跳过）；失败标红不连带；
- 核心帧卡片显示引用资产小图；底部「▶ 继续生成」= 断点续跑（只跑 pending/failed）。

**文件结构**：

| 文件 | 内容 |
|---|---|
| `banzhang_script_pipeline.py` | 节点层：参数 + 路由 sp_rebuild / sp_rerun / sp_lock / sp_state + upload_script |
| `_script_pipeline/parser.py` | 双格式解析、未闭合报错、名称提取 |
| `_script_pipeline/state.py` | 会话状态：每条目状态/图片/日志持久化到 `caches/script_pipeline/<会话>/` |
| `_script_pipeline/runner.py` | 执行器：单张/批量、阶段推进、事件广播（stage/item/log/done），失败不连带 |
| `js/banzhang_sp_main.js` | 步骤条、标签页、拖拽、路由通信 |
| `js/banzhang_sp_cards.js` | 卡片网格、状态徽章、引用资产小图 |

会话 id 由文件路径集合 hash 生成；图片存输出目录（默认 output/剧本资产，平铺）。
旧的三节点版、V1 单文件 JS 均已删除。备份：`__init__.py.bak_parser_20261019`。

**已验证**：py_compile、node --check 通过；离线 mock 端到端：21 资产全成、核心帧缺色板正确失败、补色板后成功、单张重跑/锁定跳过全部符合预期。
**待真机确认**：标签页与卡片布局、真实 API 出图。

### 2026-10-19 V2 修复：参数/UI 错乱 + 隐患

| # | 问题 | 根因 | 修法 | 文件 |
|---|---|---|---|---|
| 1 | 面板重复、参数乱序 | `configure` 重复进 `setup` → `addDOMWidget` 堆积 | `setup` 加幂等守卫 | `js/banzhang_sp_main.js` |
| 2 | 单张「重生」KeyError 崩溃 | 前端 `getParams` 无 `subfolder`，后端硬取 | `params.get("subfolder") or _subfolder(out_dir)` | `_script_pipeline/runner.py` |
| 3 | 核心帧 id 空串，跨文件同名互串 | parser 不产 id，`_merge` 退回 name | id 改 `{文件}#kf{序号}` | `parser.py` |
| 4 | 资产 `@图片N` 跨文件重复，状态静默互串 | `old_assets` 按编号建 dict | rebuild 源头检测重复并报错 | `state.py` + `banzhang_script_pipeline.py` |
| 5 | 尺寸预设/宽/高三控件平铺 | 无显隐联动 | 按「尺寸规则」联动显隐（同 FlashVSR 机制） | `js/banzhang_sp_main.js` |
| 6 | 步骤条首开显示 NaN | `asset_stat` 空对象相加 | `|| 0` 兜底 | `js/banzhang_sp_main.js` |

备份：`*.bak_spfix_20261019`（5 个文件）。已验证：py_compile + node --check + 离线自测（id 唯一化/来源字段/冲突报错/正常重建）全过；UI 三处（面板不重复/尺寸联动/NaN）待真机确认。

### 2026-10-19 V2 优化：苹果标准 + ComfyUI 专业（11 项全做）

| # | 类别 | 改动 | 文件 |
|---|---|---|---|
| 1 | P0 | 输出目录越界拦截（`_ensure_inside_output`），越界报错而非缩略图全裂 | `runner.py` |
| 2 | P0 | `run_pending` 循环加 `current_interrupted` 检测，点停止即中止剩余 | `runner.py` |
| 3 | P0 | 核心帧无 `@图片N` 引用时退化为文生图并提示 | `runner.py` |
| 4 | P1 | CSS token 收敛：圆角 6/8、字号 11/12/13、间距 4/8、灰阶 5 档、CSS 变量 | `js/banzhang_sp_main.js` |
| 5 | P1 | 「继续生成」运行中禁用+变「生成中…」，防重复入队 | `js/banzhang_sp_main.js` |
| 6 | P1 | 状态条加批量进度条（跨资产+核心帧比例） | `js/banzhang_sp_main.js` |
| 7 | P1 | 每张记录实际 seed 到 state，卡片显示 🎲种子；重生用原种子+1 | `runner.py`+`state.py`+`cards.js` |
| 8 | P1 | 面板高度改 DOM 实测 `panelHeight()`，消除 92 硬编码 | `js/banzhang_sp_main.js` |
| 9 | P2 | 资产/核心帧/日志空状态文案 | `cards.js`+`main.js` |
| 10 | P2 | lightbox 加 ESC 关闭 + ← → 左右切换 + 计数导航 | `js/banzhang_sp_main.js` |
| 11 | P2 | 事件精细化：stage/item/log 只刷对应区域，done 才全量 renderAll，消除无关重建闪烁 | `js/banzhang_sp_main.js` |

备份：`*.bak_uiopt_20261019`（5 个文件）。已验证：py_compile + node --check + 离线自测（越界拦截/无引用文生图/种子记录/重生种子）全过；全部 UI 改动待真机确认。

## 2026-10-19 媒体架「按提示词顺序排序」认错主人

**现象**：点排序显示「顺序已对齐」，但陈墨白没挪到 @图片2。

**两个叠加根因**（都已在 `js/csglide_rack_sort.js` 修掉）：

| # | 根因 | 修法 |
|---|---|---|
| 1 | 段键用错：拿媒体架的 `ui.st.cur`（「第七段」）去查文案台 `segs`（按 cid 建的字典），查不到 → 本段段词整段丢失，只剩 global | 改用文案台自己的 `chain.clip`（与导演台 `csglide_cast_slots.js:109` 同口径） |
| 2 | **`ownerOfToken` 取名字越界**：只限制「同一行 ±120 字」，条目只用句号分隔（或换行被粘贴吃掉）时，前一个 @标签 把后一条的名字抢走 → 后者报「已占位」，`moved=0` | 边界改成「条目边界（`\n \r 。；;！!？?\|`）＋ 别的 @标签 也是硬边界 ＋ ±120 上限」；取舍改成**先右后左**（剧本都是 `@图片N 定义为 名字`），标签前紧邻括号/等号时反向取左 |

**附带**：
- 拼接顺序 `deskPrompt` 改成本段 → 全局（global 里常有另一套全片编号，先写先赢会让旧编号抢占）。⚠ 与导演台 `composedWords` 的 `global + 本段` **故意不同**——那是送模型顺序，改不得。
- 排序结果不再撒谎：按钮报 `没读到编号 / 没认出名字 / 顺序已对齐 / 已对齐 N 个`；toast 报「读到几个、认出几个、挪动几个、谁被谁占位、哪些素材没被点名」；控制台打完整明细（`[媒体架] 按提示词排序诊断`）。
- `js/csglide_media_rack.js`：`ui.toast` 新增可选停留时长（诊断文本长，3.6s 读不完）。

**自测**：`_selftest_rack_sort_owner.mjs`（从源码抠真实函数跑，不是手抄）——分层换行 / 压成一行 / 无标点 / 名字在前 / 仅 `\r` 换行 5 种写法全对；并复现了「全局在前→图片1=陈墨白（旧 bug）」vs「本段在前→图片2=陈墨白（已修）」。

**已真机确认**：陈墨白已对准 @图片2。备份 `js/csglide_rack_sort.js.bak_diag_20261019`。

### 通用化：不再猜左右，改成判句式（同日追加）

原取舍是「先看右边再看左边 + 标签前紧邻括号/等号就反向」——本质是**按位置猜**，每来一种新写法就要补一条启发式。改成看**标签与名字之间那一截是什么**：

- `LINK_PURE`：只有空白 / 中英文标点 → 直接定义
- `LINK_WORD`：只有系动词与连接词（是 为 即 定义为 对应 / is are means named refers to…）→ 直接定义
- 判之前先剥掉成对括号及其内容：`@图片30（核心帧图标准名 KF_01-07）定义为核心帧参考图` 剥完就是「定义为」
- 夹了别的字（另一句描述、另一个素材名）就不是直接定义，退回按距离取

三级取舍：**直接定义 > 同侧最近（先右后左）> 另一侧最近**。从此不区分中英文、也不分名字在前还是在后。

**英文 / 官方式写法**：排序前先过 `normalizeRefs`（`js/csglide_ref_text.js`，与导演台/后端同口径）收 `<Picture N>` / `image 1` / `Image 1`；再补一层 `rackNormalize` 收**带 @ 的英文**（`@image1` / `@pic2`）——共享表里只有「不带 @ 的英文裸词」，这层只加在媒体架排序里，不动共享规则。

**顺带修**：`ITEM_CUT` 补 `，` `、` `,`——`@图片1=李墨白，@图片2=马魁` 靠逗号分条目，不补的话 `@图片2` 会抓到左边的李墨白。

**自测扩到 16 项全通过**（`node _selftest_rack_sort_owner.mjs`）：`定义为` / `@图片1是李墨白` / `@图片1=李墨白` / `李墨白=@图片1` / `陈墨白（@图片1）` / `：` / 括号附注 / `<Picture 1>:` / `<Picture 1>=` / `@image1 is` / `Picture 1 =` / `@image1 named` / 压成一行 / 无标点 / 仅 `\r` / 描述句。

## 2026-10-19 媒体架「一键排全部段」

**需求**：时间轴 8 段、每段提示词不同、素材是同一批，想一次按各段提示词排完。

**先查清的现状**（不是复制 8 遍文件）：
- 素材**文件只有一份**，每格存的是相对路径 + 别名
- **槽位清单是每段一份独立副本**（`ui.st.segs[cid]`，`copySeg` 走 `cloneRack` 深拷贝）
- 未认段时是一套「全片共用」（segChip 显示这四个字）
- 后果：改一段的顺序/别名不影响其它段，所以 8 段要各排各的

**为什么能不切界面就逐段读文本**：文案台的 `segWords(段id)` / `composedWords(段id)` 本来就接受段身份作参数（「按段身份直接读 `st.segs[key]`，不依赖界面此刻停在哪一段」），正好对上。

**改动**：

| 文件 | 改动 |
|---|---|
| `js/csglide_rack_sort.js` | `sortSlots(st, texts)` 抽出为可复用的单段排序（原地改 `st.slots`）；`deskPrompt` / `promptTexts` 加 `clipOverride` 按段读；新增 `sortAllSegs()`；新增 `rackHasFile` / `reportOf` / `syncCurToSegs` |
| `js/csglide_rack_bar.js` | 新增「全部段」按钮 `ui.bSortAll`（内联 `margin-left:6px` 抵消 `gmr-mini` 的 `margin-left:auto`，两颗才挨一起） |
| `js/csglide_rack_seg.js` | 暴露 `ui.saveSegRack = scheduleRackSave`（`ui.commit` 只存当前段，排其余段要按段落库） |

**两个坑（已处理）**：
1. 当前段排完必须 `syncCurToSegs()`：落库读的是 `segs[cur]` 而不是 `ui.st.slots`，不同步的话一切段/一提交就被旧副本盖回去。
2. `flashBtn` 已自带判空，`ui.bSortAll` 未安装时不会炸。

**已验证**：3 个文件 `node --check` 通过；`_selftest_rack_sort_owner.mjs` 16 项仍全通过。
**待真机确认**：按钮在面板条上是否挤（bar 是单行 flex）、8 段是否各自按本段提示词排对。备份三个 `.bak_sortall_20261019`。

## 2026-10-19 媒体架两个音频「竖排堆成一列」

**现象**：参考音频区放两个音频文件，两张卡不并排、竖着摞成一列。只在部分用户可见，本机开发环境不可见。

**根因**：ComfyUI 对 `custom_nodes/**/js` 是静态文件服务、**无缓存戳**——用户覆盖更新插件后不硬刷新，浏览器新旧文件混跑。旧版样式表缺 `.gcast-grid.med` 的列定义时，网格退化成「有 `display:grid`、无 `grid-template-columns`」→ 所有卡落进单一隐式列，竖排堆叠。与插帧「没有输入」报错同源：**用户跑在旧包/旧缓存上**。

**排查中排除的**：卡片 keyed 缓存归位逻辑、load/切段/复制段的数据层（均深拷贝，无串槽）、当日 toast 改动——全部无关；当前代码 + 完好样式下两卡结构上不可能叠压（`.gcast-media` 无绝对定位、`overflow:hidden`）。

**改动**：

| 文件 | 改动 |
|---|---|
| `js/csglide_rack_cards.js` | 新增 `healGrids()`：每次 `rebuildMedia` 验算三个网格的**真实计算样式**，`display` 不是 grid 或列模板为 `none` 就把 display/列/间距补成**内联**（内联胜样式表，旧缓存压不住），console.warn 提示硬刷新；`ui.healGrids` 暴露给外壳。健康时零成本（三次 getComputedStyle），补进去的值与 RACK_CSS 规则逐字一致，硬刷新后视觉无差异 |
| `js/csglide_media_rack.js` | onNodeCreated 与热重建两条挂路径的 rAF 里首验 `healGrids()`，真修过就 toast「建议 Ctrl+F5 硬刷新」 |
| `js/csglide_rack_css.js` | `.gmr .gcast-grid.med` 由固定三列 `minmax(0,190px)` 改 `repeat(auto-fit, minmax(180px,1fr))`：窄节点自动降两列/一列（原是三列齐压扁），拖宽则列数自然增多、不再右侧留空白 |

**已验证**：3 文件 `node --check` 通过；`_selftest_grid_heal.mjs` 14 项全过（部分退化只修坏的 / 全健康零修 / 整体缺失修三个 / 未上文档不误诊 / 不覆盖已有 gap）——从源码真实抠 `healOne/healGrids` 配 DOM 桩跑。备份三个 `.bak_stack_20261019`。
**待真机确认**：旧缓存用户加载后是否自动恢复三列并弹提示；窄节点（约 400px）是否降为两列。
**顺带修掉（同日追加，用户确认「修吧」）**：`rebuildZone` 的 anchor 指针归位与图片区 20261012 修掉的同一类潜在 `NotFoundError`——同 cur 的 `load()`（Ctrl+Z 回滚 rack_data / 外部改 rack_data）经 `revive` 整批换 slot 对象，被换的旧卡当场 `remove()` 后 anchor 脱连，下一次 `insertBefore(card, anchor)` 当场抛，渲染链断在中间、网格停在半渲染态。已照图片区 `renderImages` 的 `grid.children[i]` 参照物写法重修：每轮重取 `children[i]`（越界传 null 等价 append），尾部按 `children.length > arr.length` 清残。回归自测 `_selftest_zone_rebuild.mjs` 16 项——**旧备份实现同场景必抛**（证明测试有牙）、新实现不抛，且换序/收缩/复用不重建/中间槽换文件全对。备份 `js/csglide_rack_cards.js.bak_zoneanchor_20261019`。

## 2026-10-19 集成 ⚡ Veda 稀疏注意力 (H3)

**来源**：[veda-sparse/Veda-on-ComfyUI](https://github.com/veda-sparse/Veda-on-ComfyUI) v0.3.1（MIT；INT8 kernel 派生自 SageAttention v1 BSD-3；打分器继承 MiniMax H3 Community License）。给 MiniMax-H3 加速：只算打分器判为重要的注意力块，跳过约 90%，官方实测端到端 2.9x / 注意力 7.1x。

**集成骨架（用户选定）**：vendor 零改动 + 中文薄壳。`_veda/` 原样复制上游 `veda_comfy/`，**一行不改**（上游升级直接覆盖该目录）；中文层三个文件，与 vendor 唯一耦合点是 `comfy_patch.apply(model, bundle, settings, node_id)`。

| 文件 | 职责 | 行数 |
|---|---|---|
| `_veda/` | 上游原样（含其自带英文 nodes.py，不注册、仅留存） | 4033 |
| `banzhang_veda.py` | 中文 schema + 组装 + 模型校验 | 210 |
| `banzhang_veda_texts.py` | 全部中文文案（description / 8 个 tooltip） | 73 |
| `banzhang_veda_predictor.py` | 打分器：目录注册 / 路径解析 / 下载 / 加载缓存 | 113 |
| `__init__.py` | 第 44 项注册块 + 并入两个合并字典 | +14 |

**关键设计**：
- **kernel 在节点执行时解析，不是采样时**——跑不了的 kernel 当场停在这个节点上并说明原因，不会等采样器启动后才炸（沿用上游「绝不静默失效」）。
- **打分器下载默认关**：上游原版本自带下载，后因「自定义节点联网 + 读 HF_TOKEN 触发 Comfy Registry 安全扫描」而移除。班长是本地安装不走 Registry，但保留上游边界——用户在节点上勾选「自动下载打分器」才联网，下完核 sha256（断网会留截尾文件，不核会变成莫名的张量形状报错）。
- **分类沿用 `👨‍🏫班长/MiniMax H3`**，与 h3_tweaks / h3_latent_upscaler_3d / h3_vae_decode / h3mc_zh 一致，未新建分类。

**已验证（本机实测）**：ComfyUI 0.42.0 / torch 2.9.1+cu130 / triton 3.3.1 / **RTX 3090 (sm86)**。
- 包整体导入无报错，节点总数 86 → 87
- 节点：`BanZhang_VedaSparseAttention` → `⚡ Veda 稀疏注意力 (H3)`，8 个参数 + 输出全部中文显示名
- **kernel 自检通过**：`Triton INT8 (SM86)` / `triton-int8: ok` / error=None，首次编译 11.8s（3090 属官方「未验证但代码路径就绪」名单，本机实测已验证可用）
- 打分器两个文件 sha256 与内置清单逐位匹配；加载 0.2s，`50 x 56 x 128`；T2VA 训练 90% sparse、R2VA 训练 32 tiles
- 备份 `__init__.py.bak_veda_20261019`

**版本核对（2026-10-19）**：vendor 来源 commit `67e4eb55` == 上游 GitHub main HEAD，**代码为最新**。两个打分器 sha256 与字节数均与 `_veda/predictors.py` 内置清单逐位一致（275415648 / 275415752），即官方 pin 的那版。
**升级方式**：上游出新版本时，① 覆盖 `_veda/`（新代码带来新的 pin revision 与 sha256）；② 按新 pin 重新下载打分器。不要自己追 HuggingFace 仓库 HEAD——pin 的是上游验证过的版本，自行追新可能与 kernel 不匹配。注：huggingface.co 在本机被代理拦截（502），无法直连核线上文件。

**待真机确认**：实际出片加速比与画质（896×512 会回退到最接近的 16:9 tile plan）；与班长 H3 Studio / H3 latent 放大串联的兼容性。

**已知约束**：只支持 MiniMax-H3；打分器训练于 1344×768 / 768×1344 / 768×768 / 1024×768 × 5/10/14s，超出范围会提示 `nearest trained size`；不能和 ComfyUI 自带「Model Sparse Attention」同时用；KJNodes「MiniMax H3 Mem Eff Sage Attention Patch」必须放在本节点之前。

**⚠️ 与班长自研 SLA 不可叠加（2026-10-19 诊断）**：`sla/patch.py:795-825` 对 H3 走块级替换（`set_model_patch_replace(..., "dit", "double_block", i)`），块补丁内部直接调 `_h3_producer_attention`，不经过 `optimized_attention`；Veda 挂的 `optimized_attention_override` 被整块绕开。且 Veda 的 `replaced_forwards()` 只扫 `object_patches`、**扫不到 `patches_replace`**，所以检测不到 SLA，只在 `on_cleanup` 兜底提示「没有任何 H3 注意力调用到达 Veda」——**静默失效**。两者功能重叠，二选一。
**通用判据**：`optimized_attention_override`（可链式共存，Veda 自带 previous 回退）vs `patches_replace` / `object_patches` 整块替换（屏蔽 override，后挂的收不到调用）。

**⚠️ 步数匹配：别照抄「8 步」——T2VA 与 R2VA 官方步数不同**（2026-10-20 查证，来自 Veda 仓库两个示例工作流的 `properties.models` 清单）：

| 任务 | 官方 Turbo LoRA | 步数 | 来源仓库 |
|---|---|---|---|
| T2VA / FL2VA | `minimax_h3_fl2v_turbo_8step_v1.0_comfyui_bf16.safetensors` | 8 步 | `lightx2v/Minimax-h3-Turbo`（**不是** Comfy-Org） |
| R2VA | `minimax_h3_ref2v_turbo_4step_v0.1_comfyui_bf16.safetensors` | **4 步** | `Comfy-Org/MiniMax-H3/loras` |

两个均 1.82 GB。`docs/hardware.md:183` 印证 R2VA 实测用「Ref2VA int8 + 4 步 Turbo LoRA」。**曾误判「4 步超出 Veda 训练范围」——那是 T2VA 的结论，套到 R2VA 上是错的，勿再犯。**
配套底模：T2VA/FL2VA 用 `minimax_h3_fl2va_pruned_int8_convrot`；R2VA 用 `minimax_h3_ref2va_pruned_int8_convrot`。R2VA 官方建议 `res_multistep` + `beta`/`normal`。
**本机默认值已固化**（2026-10-20，`banzhang_veda.py` 顶部 `_DEFAULT_PREDICTOR` / `_DEFAULT_REFERENCE` 两个常量，用户确认后改）：打分器默认 **R2VA**（上游默认是 T2VA，但本机主跑参考生视频）；参考段稀疏度默认 **`0%`**（给参考内容满注意力）。其余保持上游默认：生成段 `32`、全注意力层/步空、自动下载关闭、详细信息关闭。
**⚠️ 稀疏度字符串的两个坑**：必须写 `"0%"` 而不是 `"0"`——裸 `0` 被 `_TILES` 正则当成 tile 数、`Budget.__post_init__` 要求 >0 会直接报错；`100%` 同样报错（会跳过所有 tile）。`0%` → `Budget(ratio=1.0)` → `keeps_all=True` 才是满注意力。四者的正确写法：`trained` / `90%` / `32`（整数=固定 tile 数，抗闪烁）/ `0%`。
备份 `banzhang_veda.py.bak_defaults_20261020`。

## 2026-10-20 媒体架素材名自动多出「（02）」编号

**现象**：点时间轴的段（架上素材被清空）后，再添加**同一素材**，素材名后面自动多出编号（用户看到的是 `名 (2)` 形态，即 ComfyUI 上传去重的产物）。

**根因**：`uploadFile` 无条件把文件 POST 到 `/upload/image` **复制一份**到 `input/cglide/`；清空槽位只清引用、**磁盘上那份还在**。再导入同名文件时命中 `server.py` 的 `store_image_upload`：
- 内容哈希**相同** → 判重复，返回原文件名（不落第二份）；
- 内容哈希**不同** → 改名 `名 (1).ext` / `名 (2).ext` 落第二份 ← 就是编号的来源。

与 `bz_media_ref.js` 文件头自己写过的判断相悖：那条注释早就记下「重传必然在同目录里落第二个文件（同名被改名）」，但只有**拖拽那条零拷贝通道**遵守，文件选择器 / 拖文件这两条没遵守。

**中间方案（已弃用，留作决策记录）**：先做的是「上传前探同名 → 已有就引用旧文件、忽略新字节」。用户一句话否掉：**「同工程内重新导入同名素材 = 用新的替换旧的，名字要不变」**——引用旧文件正好反了。且跨工程同名不能覆盖（会污染别的工程），于是升级为方案 2。

**最终修复（方案 2：按工程分目录 + 原地替换）**：
`input/cglide/` 原本所有工程共用、文件名即全局身份，所以「替换」只能限定在本工程范围内。落盘规则（`js/csglide_rack_asset.js` 的 `assetDirFor`）：
- 本工程**有槽位在用同名素材** → 落回它**正在用的那个目录**，`overwrite=true` 原地覆盖：换新内容、名字不变、槽位路径不动（老存档在 `cglide` 根上的也能换掉）；
- 否则 → 落本工程子目录 `cglide/<片名>/`：跨工程互不干扰，名字同样不变；
- 拿不到片名（还没建工程）→ 落 `cglide` 根，与旧版一致。

| 文件 | 改动 |
|---|---|
| `js/csglide_rack_asset.js`（新） | `assetDirFor(st, 片名, 文件名)` + `safeDirName()`。**纯函数**（只吃槽位与片名，不认识 ui），可脱离浏览器单跑自测 |
| `js/csglide_rack_core.js` | `uploadFile(file, subfolder)` 支持指定目录，并**传 `overwrite=true`**（`server.py:491` 认它：同名直接覆盖、返回原文件名，不再改名 `(1)`）；删掉中间方案加的 `inputFileExists`（新方案不需要探存在，孤儿） |
| `js/csglide_media_rack.js` | `ui.uploadOrToast` 改为向 `assetDirFor` 要目录再上传 |

**为什么一处就够**：`ui.uploadOrToast` 是媒体架唯一的上传漏斗——视频/音频卡的 `fill()`（`csglide_rack_cards.js:38`）与图片格的 `assignImage()`（`csglide_rack_images.js:44`）都走它。

**已查证的上游行为**（不凭记忆）：`/upload/image` 会 `os.makedirs` 多级 subfolder 并做越界校验（server.py:486）；`/view` 认多级 subfolder（server.py:634）；我们自己的 `/cglide/probe` 的 `_resolve_inside(root, subfolder, filename)` 也支持多级。

**代价（用户已知并接受）**：素材不再跨工程共享——每个工程一份物理副本（18MB 视频会重复）。老存档的槽位仍指向 `cglide` 根，文件也在，照常可用，只是新导入的走工程目录。

**后续**：同一根因在导演台那一侧（含「取用输出」续接）当天已一并修掉，见下一节「导演台同步：工程彻底隔离」。

**已验证**：3 文件 `node --check` 通过；`_selftest_asset_dir.mjs` 13 项（老存档回根覆盖 / 工程目录命中 / 全新素材进工程目录 / 无片名回根 / 当前段也命中 / 空槽位不命中 / 片名非法字符换 `_`、空格连字符保留）全过；`_selftest_grid_heal.mjs` 14 项、`_selftest_zone_rebuild.mjs` 16 项复跑仍全过。备份 `js/csglide_rack_core.js.bak_projdir_20261020`、`js/csglide_media_rack.js.bak_projdir_20261020`。

**待真机确认**（改 js 需重启 ComfyUI + Ctrl+F5）：
1. 新建/打开一个工程（有片名），拖入**新素材** → `input/cglide/<片名>/` 下出现该文件，架上名字**不带编号**；
2. 点时间轴的段清空架子 → 再用文件选择器加**同一个文件** → 名字仍不带编号，且**内容是新的**（换一个同名但内容不同的文件试，架上缩略图/波形应变成新的）；
3. 换一个**别的工程**导入同名文件 → 落在 `cglide/<另一个片名>/`，**上一个工程那份内容不变**。

## 2026-10-20 导演台同步：工程彻底隔离（含续接）

**症状/需求**：「导演台新建工程后，媒体架素材、导演台参数槽位、中央系统数据、文案台数据等所有数据参数文件都放到同名工程文件夹中，工程相互彻底隔离；另外注意续接部分怎么解决」。

**排查结论（先查再改，省掉一半工作量）**：工程隔离的**主体早就有了**，一个字不用改——

| 内容 | 位置 |
|---|---|
| 片级设置、段落元数据、**导演台面板** | `output/h3_chain/<片名>/project.db` |
| **媒体架段槽位**、**文案台台词** | 同一个 `project.db`（`rack_slots` / `shot_state` 表） |
| **中央系统数据**（`bz_seg.js` 中央段档案，`/cglide/store/segment`、`/cglide/store/desk`） | 同一个 `project.db` |
| 成片 / 续拍档 | `clip_<cid>.mp4`、`clip_<cid>.cont.safetensors`（`csglide_chain.py:431/441`） |

`csglide_chain.py:3437` 的设计原话即「拷走 `h3_chain/<片名>/` 这一个文件夹就是完整工程」。

**真正漏在外面的只有 input 侧素材，三条通道**：

| # | 通道 | 改前 | 改后 |
|---|---|---|---|
| ① | 媒体架上传 | `input/cglide` 根 | 上一节已改 → `cglide/<片名>/` |
| ② | **导演台槽位**上传（拖/选文件） | `csglide_ui_kit.js:167 uploadFile` 死写 `cglide` | → `cglide/<片名>/` |
| ③ | **「取用输出」= 续接** | `csglide_adopt.py /cglide/adopt_output` 死写 `input/cglide` + `_unique_path` 加 `_1/_2` | → `cglide/<片名>/` + 同名覆盖 |

**续接怎么解决**：两条腿——接续拍档 `clip_<cid>.cont.safetensors` 本来就在工程目录内（腿 A，天然隔离，不用改）；「取用输出」当引导片是通道 ③（腿 B，本次改）。节点本体 `csglide_join.py` 靠输入口接线拼接、不读工程目录，不受影响。

**语义裁决（用户拍板）**：`_unique_path` 原注释说「同一个成片采纳两次很正常，静默覆盖会抽走还指着它的槽位脚下的地毯」，所以**故意**不覆盖。用户裁决沿用「同名 = 换新内容、名字不变」，即**覆盖**。理由：重拍一段再取用输出，就是要让引用它的槽位拿到新版。

**规则只有一份**：`safeDirName` / `castSlotFiles` / `assetDirOf` 下沉到 `csglide_cast_core.js`（**零 import**，导演台与媒体架都能安全引，不会成环）。媒体架侧 `csglide_rack_asset.js` 只保留「媒体架槽位长什么样」（多了 `segs` 分段记忆），把路径收集出来交给通用规则。后端 `csglide_adopt.py` 的 `_adopt_dir` 是同口径的 Python 版（注释里写明两边必须一起改）。

**顺手堵掉的一个坑**：续写卡潜空间档的 `cont.latent_video` 存的是**相对 output** 的路径（`h3_chain/<片名>/clip_000N.mp4`），basename 与刚渲染的成片恰恰同名。只比 basename 会命中它，把成片落进 `input/h3_chain/<片名>/` 这种垃圾目录，续接从此读不到素材 —— 所以两边都**先看根再比名**（只认 `cglide` / `whatdreamscost` 开头的 input 侧路径）。

| 文件 | 改动 |
|---|---|
| `js/csglide_cast_core.js` | 新增 `safeDirName` / `castSlotFiles` / `assetDirOf`（通用规则，零依赖） |
| `js/csglide_ui_kit.js` | `uploadFile(file, subfolder?)` + `overwrite=true`；新增 `castAssetDir(st, 文件名)` |
| `js/csglide_cast_slots.js` | `assign()` 传 `castAssetDir`；`adoptInto()` 传 `project` + `used` |
| `js/csglide_rack_asset.js` | 改为调通用 `assetDirOf`，删本地 `safeDirName` 副本 |
| `js/csglide_cast_preset.js` | 包内素材还原落本工程目录（见下） |
| `js/csglide_cast_conflict.js` | 「打开工程」包内素材落**即将载入那个工程**的目录（`d.name`，不是当前工程名） |
| `csglide_adopt.py` | `/cglide/adopt_output` 接受可选 `project` / `used`；`_adopt_dir` 决定目录；覆盖改为「写 `.tmp` + `os.replace` 原子替换」；删孤儿 `_unique_path` |

**为什么必须带上 preset/conflict 这两条**：`uploadFile` 现在带 `overwrite=true`，它们不传目录就落 `cglide` 根并**覆盖别的工程同名的那一份** —— 是本次改动新引入的跨工程污染，必须一起修。

**向后兼容**：`uploadFile` 第二参数可省、`/cglide/adopt_output` 两个字段可省 —— 不传时落 `cglide` 根，与旧版逐字一致。老存档槽位在根上的，`assetDirOf` 命中后**回根覆盖**（老工程照样换得掉内容）。`project` 会进目录名，拼路径前过 `_resolve_inside` 越界校验。

**已查证（不凭记忆）**：后端读得到分目录 —— `csglide_assets.resolve_asset()` 第一个候选即 `input/<ref>`，`csglide_join._open_source()` 也是 `input/<p>`，两者都按完整相对路径拼。全仓**没有**用 `get_filename_list` 列举 input 素材做下拉的地方，所以分目录不会让任何"已有素材"列表失效。

**已验证**：6 个 js 文件 `node --check` 通过；`csglide_adopt.py` `py_compile` 通过；`_selftest_asset_dir.mjs` 19 项（含导演台 first/last/cont 命中、`latent_video` 不命中）全过；`_selftest_adopt_dir.py`（新，Python 侧自抠 `csglide_adopt.py` 真实源码）13 项全过；`_selftest_grid_heal.mjs` 14 项、`_selftest_zone_rebuild.mjs` 16 项复跑仍全过。

**待真机确认**（改 js 需重启 ComfyUI + Ctrl+F5，改 py 需重启后端）：
1. 工程 A 拖入新素材 → `input/cglide/A/`；同工程重导同名 → 名字不变、内容变新；
2. 工程 B 导入同名素材 → `input/cglide/B/`，**A 那份不变**；
3. **续接**：工程 A 渲染一段 → 「取用输出」→ 成片落 `input/cglide/A/clip_000N.mp4`（**不带 `_1`**），续接卡能读到；再渲染一次同名成片再取用 → 仍是 `clip_000N.mp4`（覆盖，不新增文件）；
4. 打开一个打包工程（`.h3projpack`）→ 素材落 `cglide/<包里那个片名>/`，不污染别的工程。

## 2026-10-20 收尾：片名→目录名单一来源 + 改名搬素材目录

**这轮做了什么**：上一节把素材分进工程目录之后，把剩下的两个洞补掉。

### 1. 口径分裂（差点埋雷）

素材目录名**前端算**（`js/csglide_cast_core.js` 的 `safeDirName`），成片采纳目录**后端算**（`csglide_adopt._safe_dir_name`）——两份实现。差一个字符，同一工程的素材就落两个目录，隔离形同虚设，且极难察觉（槽位路径各自自洽，看着没坏）。

→ 唯一实现下沉到 `csglide_store.py`（单向依赖底层：chain → store，只依赖标准库 + folder_paths）：`safe_dir_name` + `asset_dir`。`csglide_adopt.py` 改为 `from . import csglide_store as store; _safe_dir_name = store.safe_dir_name`。

⚠️ **素材目录名与档案目录名算法不同，是历史包袱不是 bug**：
- `chain_dir`（output 侧）**删**非法字符 → `a/b` → `ab`
- `safe_dir_name`（input 侧）换成**下划线** → `a/b` → `a_b`

统一任何一边都会让老工程找不到自己的目录。所以改名时两边必须**各按各的算**（`csglide_chain.rename_chain` 的注释里写明了）。

### 2. 改名漏搬素材目录（⚠️ 已被方案 G 取代，见下一节）

`/cglide/chain/rename`（`csglide_chain.py:2668 rename_chain`）只搬 `output/h3_chain/<片名>/`，不搬 `input/cglide/<片名>/`。后果不致命（老槽位指向旧目录、文件还在、照样读得到），但改名后**新导入的素材落进新目录**，一个工程的素材散在两处。

→ `rename_chain` 加一段搬 `store.asset_dir(old)` → `store.asset_dir(new)`。失败**不回滚**已成功的档案改名（搬不动只是目录名脱节，不影响读写），返回值加 `assets_moved` 标记。

**20261020 晚些时候被推翻**：真机改名报 `PermissionError [WinError 5]`，目录搬不动。根因不是这段代码，而是「改名 = `os.rename(整个目录)`」这条路本身在 Windows 上就走不通 —— 改为**方案 G（目录永不改名）**后，上面这段搬素材目录的代码已删除（`_repoint_paths` / `repath_db` 一并删除）。

### 3. 完整性审计结论（这轮查出来的现状）

| 项 | 结论 |
|---|---|
| 制片中枢 `banzhang_producer.py` | **本来就是** `input/_producer/<片名>/pkg.json` + `assets.json` + `candidates/` → 已隔离，不用改 |
| `output/h3_chain/_last.json` | 全局「最近用过的片名」。语义就是跨工程的（像"最近打开的文档"），**不该**隔离 |
| 导演台设置 / 文案台 / 中央段档案 | 全在 `project.db` 里 → 已隔离 |
| `banzhang_video_tools` / `visual_loader` / `scene_splitter` / `script_pipeline` / `music_player` | 独立通用节点，不属于导演台工程体系，不纳入 |
| `input/cglide` 根上的历史素材 | 不迁移。老槽位指向根、`assetDirOf` 命中后**回根覆盖**，老工程照常能用 |

| 文件 | 改动 |
|---|---|
| `csglide_store.py` | 新增 `ASSET_SUBFOLDER` / `safe_dir_name` / `asset_dir`（唯一实现）；加 `import re` |
| `csglide_adopt.py` | 引 store，删本地 `_safe_dir_name` 副本；孤儿 `_ASSET_ROOTS` 改为实际使用（新增 `_is_asset_path`） |
| `csglide_chain.py` | `rename_chain` 搬素材目录，返回加 `assets_moved` |

**已验证**：3 个 py `py_compile` 过；`_selftest_adopt_dir.py` **16 项**（含「两个口径确实不同」这条反向断言）全过；新增 `_selftest_dirname_cross.mjs` **10 个片名前后端逐字一致**（JS 抠真源码 + 子进程跑 Python 抠真源码，逐条比对）；`_selftest_asset_dir.mjs` 19 项、旧自测 14/16 项复跑仍过。备份 `.bak_rename_20261020` ×3。

**待真机确认**（改 py 需重启后端）：工程改名前先导入一个素材 → 改名 → `input/cglide/<新片名>/` 里能看到它，旧目录消失；改名失败（新名字被占）时前端保持原名且素材目录不受影响。

## 2026-10-20 媒体架卡顿 / 缺素材（方案 A+B+C）

**症状**：素材多时特别卡，拖 100 张图片尤其明显；还会出现"缺少素材"。

### 根因：五层叠加，不是一个原因

拖 100 张时每张都要走一遍完整提交：

| 环节 | 次数 | 成本 |
|---|---|---|
| HTTP 上传 | 100，**串行 await**（`csglide_rack_drop.js:65`） | 最大的墙，几十秒 |
| `ui.snapshot()` | 100 | `JSON.parse(JSON.stringify(slots))`，数组渐长到 100 → O(n²) |
| `JSON.stringify(ui.st)` | 100 | 整个 st，含**所有段的 segs 记忆** → O(n²) |
| `node.setDirtyCanvas(true,true)` | 100 | **整个画布全量重绘** |
| `emitRackChange` 广播 | 100 | 同步派发给 desk / qwen / cast_meta / rack_seg… |
| **`<img>` 吃原图** | 100 | 没带 `preview` 参数，浏览器解码 4000×3000 原图做缩略图 |

最后一条是**「素材一多就卡」的真正大头**，跟导入快慢无关，滚动一下就卡。已查证 ComfyUI 的 `/view` 支持 `?preview=<格式>;<质量>`（`server.py:644-656`，服务端 PIL 出压缩图）。

### "缺少素材"是两个不同上限，都不是丢东西

| 上限 | 值 | 表现 |
|---|---|---|
| 存储 `MAX_SLOTS`（= 后端 REF_LIMIT） | 64 | 拖 100 张只存 64 张，第 65 张起弹 toast，**被后续 toast 覆盖** |
| 消费 `MAX_IMAGES`（导演台） | 9 | 存了 64 张，**只有前 9 张进提示词**。用户以为都用了 |

### 方案

| | 改什么 | 解决 |
|---|---|---|
| **A 批量导入** | 预分配下标 + 并发上传（限流 6）+ `beginBatch/endBatch` 末尾只 commit 一次 | 导入几十秒 → 几秒；消掉 99 次深拷贝/序列化/全画布重绘/广播 |
| **B 缩略图** | `<img src>` 改 `/view?...&preview=webp;50`，失败回退原图再失败才报缺失 | 「素材多了就卡」「滚动卡」 |
| **C 缺素材可见** | 超限改**汇总式**一次说清；第 10 张起卡片降饱和 + 虚线边 + tooltip 说明 | "素材去哪了"的困惑 |

| 文件 | 改动 |
|---|---|
| `js/csglide_rack_drop.js` | 新增 `allocImageSlots(n)`（预分配）/ `mapLimit`（限流并发）；drop 改「同步挑拣 → 一次性分配 → 并发上传 → 汇总提示」 |
| `js/csglide_media_rack.js` | 新增 `ui.beginBatch/endBatch`；`ui.commit` 批量中只记 `commitPending`、末尾做一次 |
| `js/csglide_rack_core.js` | 新增 `THUMB_PREVIEW`；`viewURL(file, preview)` 支持可选缩略图参数 |
| `js/csglide_rack_images.js` | `<img>` 吃缩略图 + 两级 onerror 兜底；`i >= MAX_IMAGES` 加 `gcast-beyond` 与 tooltip |
| `js/csglide_cast.css.js` | `.gcast-beyond` 样式（降饱和 + 虚线边 + 灰角标） |
| `js/csglide_rack_cards.js` | 视频/音频卡同口径加 `gcast-beyond`（消费上限 `MAX_VIDEOS`/`MAX_AUDIOS` = 3）+ token tooltip |

### 视频/音频不是卡顿源（已排查，不用改）

`csglide_rack_media.js:81` 的 `preload = "metadata"` 只拉元数据/首帧，且**按文件路径池化**（上限 32，FIFO 释放 `pause + src=""`）。多视频不会同时缓冲整个文件。所以"素材一多就卡"只来自图片原图解码。

### 已确认的安全项

- **装配顺序**：`ui.beginBatch` 定义在 `csglide_media_rack.js:102`，`installDrop(ui)` 在 `:156` —— 事件触发时 beginBatch 必然已存在，不会抛 `undefined is not a function`。
- **`index` 是稳定槽号**：视频/音频槽位 append-only、编号永不漂移（cards.js 注释明说），所以拿 `index` 判"是否超出消费上限"是可靠的。

### 批量导入的收尾反馈

卡片是逐个出现的，但**结束后没有"到底进了多少"的交代**——全都在上限内时更是一声不响。补了一条：≥10 个才报数（拖 2 张还弹提示很烦），且只有真出问题才用错误样式，"已导入 N 个"是报喜不该标红。

### 两个必须守住的约束（都写进注释了）

1. **不去抖用户直接操作**（`AGENTS.md` 铁律）：commit 是用户操作的结果，不能简单去抖。所以 batch 只由批量导入**显式**包起来，日常路径 `batchDepth` 恒为 0，行为与改动前逐字一致。
2. **批量必须一次把下标要齐**：分配出去的槽位在 `file` 写进去**之前**仍是空的，循环调 `allocImageSlots(1)` 会全部撞在第 0 格 —— 这正是"少素材"的成因，我第一版就写错了，自测 1.5 条钉死了它。

**自测抓到的真 bug**（值得记）：第一版在批量循环里逐个分配，4 项断言直接红。改成一次性分配后 22 项全过。

**已验证**：12 个 js `node --check` 过；新增 `_selftest_rack_batch.mjs` **22 项**（分配不重复 / 上限 / 限流全跑完 / 并发峰值 ≤6 / 单个失败不拖累整批 / 反向断言钉住"循环单分配会撞车"）全过；原有 19+16+10+14+16 项复跑仍过，**共 97 项**。备份 `.bak_batch_20261020` ×5。

**待真机确认**（改 js 需重启 + Ctrl+F5）：
1. 拖 100 张图片 → 明显变快，且**全部 100 张里的前 64 张都在**、没有少了的；
2. 超限提示变成**一条汇总**（"图片槽位上限 64，36 张没导入：xxx…"），不再被覆盖；
3. 素材多了以后**滚动**明显流畅（缩略图生效）——控制台 Network 里 `/view` 请求带 `preview=webp;50`，且体积小很多；
4. 第 10 张及以后的卡片**虚线边 + 变淡**，悬停提示"不会进提示词"；
5. 单张拖入 / 点格子选文件 / 拖到某一格 —— 行为与改动前一致（batch 没被误触发）。

## 2026-10-20 槽位上限：存储 64 → 200（消费上限不动）

**需求**：「图片音频视频都不要有上限」。

**先分清两类上限——它们不是一回事，只有一个能改**：

| | 值 | 性质 | 能改？ |
|---|---|---|---|
| **存储** `MAX_SLOTS` / `REF_LIMIT` | 64 → **200** | 我们自己定的（原注释：防失控 JSON） | ✅ |
| **消费** `MAX_IMAGES/VIDEOS/AUDIOS` | 9 / 3 / 3 | **模型硬限制**（`csglide_cast.py:2574`：官方交互代码图片侧上限是 `<Picture 1>~<Picture 9>`） | ❌ |

消费上限**绝对不能放宽**：`csglide_cast.py:1179` 写明「`<Picture 10>` / `<Video 4>` 这类标签模型不认，送进去只会**静默失效**（图没生效却没报错）」。硬去掉的后果是摆 30 张、后 21 张悄悄不生效，比现在"明确只有前 9 张进提示词"糟糕得多。

**想用超过 9 张只能靠流程**：分多段（每段 9 张），或把多张拼成一张参考图。

### 改动（四处常量同值，前端 8 处引用自动跟着走）

| 文件 | 位置 |
|---|---|
| `js/csglide_rack_core.js` | `MAX_SLOTS` 64 → 200 |
| `csglide_assets.py` | `REF_LIMIT` 64 → 200（`merge_rack_refs` 截断） |
| `csglide_media_rack.py` | `REF_LIMIT` 64 → 200（槽位截断 + 两个 widget 的 `max`） |
| `banzhang_producer.py` | `REF_LIMIT` 64 → 200（含 865-868 的截断告警） |

**为什么不收敛成一处**：`csglide_assets.py` 依赖 numpy/torch/PIL，让 producer 去 import 它会加重依赖链，不划算（对比：`safe_dir_name` 能下沉到 `csglide_store.py` 是因为那是零依赖底层）。所以保持四份 + 注释 + **自测钉死同值**。

### 代价（已知）

素材越多，每次 commit 的 `JSON.stringify(整个 st)` 越大、`renderImages` 遍历越长。本轮 A 方案的批量优化只解决**导入那一下**；**日常切段、编辑仍是 O(n)**。200 张以内可控；再往上要先做虚拟列表（只渲视口内卡片）。

### 验证

新增 `_selftest_slot_cap.mjs` **9 项**：读四个文件的真实常量值，断言同值；并**反向钉住消费上限仍是 9/3/3**（谁"顺便放宽"了立刻红）。`_selftest_rack_batch.mjs` 改为**从源码读真实 MAX_SLOTS**（不再在测试里抄一份 64 —— 抄了就会在改常量那天静默失配）。

全量 106 项通过（9+22+19+16+10+14+16）。3 个 py `py_compile` 过。备份 `.bak_cap200_20261020` ×4。

## 2026-10-20 按提示词排序：括号里的标准名认不到（问题 2，已修）

**症状**：`将 @图片26（核心帧图标准名 KF_01-03）定义为核心帧参考图` —— 括号里写好的标准名 `KF_01-03` 没被认出来，`@图片26` 那一格不挪。

**根因**（已复现，不是猜）：`csglide_rack_sort.js:99-105` 的 `linkOnly` 剥括号用的是**成对**正则 `/[（(][^）)]*[）)]/g`。但名字 `KF_01-03` **就在括号里**，所以 `ownerOfToken` 的切片只切到名字**前面**（`text.slice(pos+tokLen, k)`），拿到的是 `（核心帧图标准名 ` —— **左括号没有配对的右括号**，剥不掉 → 剩下"核心帧图标准名"这些中文字 → 判为"夹了别的字" → **不算直接定义** → 标准名白写。

用旧备份 `js/csglide_rack_sort.js.bak_sortall_20261019` 实测：`linkOnly("（核心帧图标准名 ")` = **false**（修复前确认失败，测试有牙）。

**修法**：`linkOnly` 加一条 —— 见到**未闭合的左括号**一律放行。括号里的附注本来就是这个标签自己的说明（"核心帧图标准名"是提示词作者加的注释），不是"夹了别的字"。改动 1 处约 3 行。

**验证**：新增 `_selftest_sort_link.mjs` **20 项**：
- 括号内标准名 3 条（中英文括号、冒号分隔）→ 均判为直接定义；
- 端到端 3 条：拿用户真实提示词跑 `ownerOfToken`，确认 `@图片26` **真的**认到 `KF_01-03`，且 `direct === true`（走直接定义而非距离兜底）；`@图片3 → 陈九一` 回归不坏；
- **反向断言 4 条**（防修宽）：` 场景中出现 `、` 的色调参考 `、` 与 `、` 和 陈九一 一起出现 ` 必须仍判 false —— 否则就是把什么名字都算作直接定义，会让「@图片14 抢走 @图片13 的升山符」那种错位回来。

全量 126 项通过（20+9+22+19+16+10+14+16）。备份 `js/csglide_rack_sort.js.bak_sortlink_20261020`。

**还原方法**：删掉 `csglide_rack_sort.js` 里 `if (/[（(][^）)]*$/.test(s)) return true;` 这一行及其上方 7 行注释。

### 排序逻辑本身已验证正确（20261020）

新增 `_selftest_sort_place.mjs` **18 项**：从 `csglide_rack_sort.js` 真实抠 `nameIndex` / `ownerOfToken` / `applyOrder` / `sortSlots` 端到端跑，确认：
- `陈九一 → 第 3 格`、`马魁 → 第 4 格`、`守缺斋前堂 → 第 6 格`；
- 用户真实提示词的 `@图片26（核心帧图标准名 KF_01-03）` → `KF_01-03` 落到第 26 格，4 个编号全认出、零「认不出」；
- 名字架上没有 → 不挪动、进「没被点名」；未点名的保持原相对顺序（设计如此）。

**所以「很多图片没排序」不在排序逻辑，而在「读的是哪份文本」**（`promptTexts` / `deskPrompt`）。

排查时的两个已知机制：

- **架上认得的只有两种名字**（`csglide_rack_sort.js:59-70` `nameIndex`）：`slot.alias`（别名）+ `baseName(slot.file)`（文件名主干）。提示词里的名字必须等于其中之一。
- **别名开关与排序无关**：`normalizeRefs`（排序前过一遍）只做写法归一化，**不做别名展开**，不受开关影响。但关掉别名会导致提示词里的角色名不展开成 `@图片N` → **素材不会送进模型**（`csglide_cast_slots.js` 的 `if (aliasOn) out = ui.expandAliases(out)`）——想要素材生效，开关得开着。

**诊断改进（20261020）**：读到 0 个编号时，toast 直接报「本段 X 字 / 全局 Y 字」，并在本段 0 字时提示「确认文案台是否停在这一段、且已接到导演台的提示词口」——不用再开控制台翻 `ui.__deskSplit`。

**最常见的真因**：读到的是**全局**而不是**本段**（`deskPrompt` 拼「本段 → 全局」，本段取不到就只剩全局，而全局通常不写 `@图片N`）。判读：toast 第一行「读到 N 个编号」——0 个 = 文本没读到；少于预期 = 读的是全局。

**注意**：没被提示词点名的素材**保持原相对顺序**填剩余格子，这是设计（`applyOrder`），不是 bug。

## 2026-10-20 改名必崩 → 方案 G：名字与目录彻底解耦

**症状**：监视器上点工程名改名，报 `PermissionError: [WinError 5] 拒绝访问。: '…output\h3_chain\未命名工程 16' -> '…h3_chain\第一集'`，名字保持原样。

### 根因：Windows 目录改名锁（本地已复现，不是猜的）

临时探针 `_probe_rename_lock.py`（验证完已删）实测：目录里只要**有任何一个文件被打开**，`os.rename(目录)` 就是 `WinError 5`。SQLite 连接开着 → 失败；关掉 → 成功；普通 mp4 被打开 → 同样失败。

而"刚渲染完想改个名"恰恰是**句柄最多**的时候：成片刚写完、预览可能开着、库连接还在。所以这不是偶发，是必崩。

### 方案 G：目录建好后永远不动，改名只改索引里的一条记录

`output/h3_chain/_index.json`：

```json
{"version": 1, "names": {"第一集": "未命名工程 16"}}
```

- **只登记改过名的工程**；没登记过走老规则（目录名 = 片名）→ **老工程零迁移**。
- `chain_dir(name)` 是唯一实现（下沉到 `csglide_store.py`）：先查索引，查不到再按老规则拼。`csglide_chain.chain_dir` 委托过去。
- `rename_chain` 不再碰磁盘：只 `rename_index_key(old, new)`（先写新键再删旧键，中间崩溃不会留旧键）+ 同步 `chain.json` 里的 `name` + `mark_last`。
- 连带省掉：`os.rename`、关 SQLite 连接、`_repoint_paths` / `repath_db`（绝对路径没变，不需要回写）、搬素材目录。

### 为什么"目录后台搬"（原方案 2）不能直接上

改名后到目录搬完之间存在**窗口期**：所有请求都带**新名字**来 → `chain_dir(new)` 拼出一个不存在的目录 → `csglide_store.py:135 os.makedirs(..., exist_ok=True)` 凭空建空目录 → `js/bz_seg.js`「没档案就现场补建」→ 新旧两份数据并存、**改名永久失败**。

所以方案 2 必须先有映射 —— **方案 2 = 方案 G + 可选美化**。G 是地基，美化以后想加随时能加。

### 连带修掉的三个坑

| 坑 | 表现 | 修法 |
|---|---|---|
| `unique_chain_name` 按名字硬拼 | 改过名的工程目录名 ≠ 片名 → 硬拼出不存在的目录 → 判成"没被占用" → **新片写进旧片档案** | 改走 `chain_dir(cand)` 判存在 |
| `delete_project` 按名字硬拼 | 改名后按片名去删，删的是**一个不存在的目录** → 报"没有这个工程" | 走 `store.dir_name_of(name)` 解析，删完 `drop_dir_of` |
| `history_list` 显示目录名 | 历史清单里出现改名前的旧目录名 | `store.name_of_dir(d0)` 反查回用户看到的名字 |

**`producer_pkg_path` 也补了**：中枢目录 `input/_producer/<片名>/` 是按**建工程时**的片名建的，改名后按新片名查不到 → `assert_no_producer_project` 失效 → 手工导演台认不出这是中枢工程、直接打开覆盖中枢数据。现在多查一个候选名（索引里的目录名 = 当年的片名）。

### 代价（已知，接受）

1. **目录名不等于片名**。看 `output/h3_chain/` 会看到 `未命名工程 16` 里装的是「第一集」。前端「档案」行已改成「目录名不一定等于片名」。
2. **素材目录不搬**（`input/cglide/<片名>/` 按片名算）。改名后新导入的素材落新目录、老槽位仍指向旧目录 → 一个工程的素材可能分在两处，但**不会错**，只是不整齐。
3. **旧片名不能复用**：改名后旧名从索引里抹掉了，但它按老规则拼出的**目录**仍被新片占着 → 用它开新片会写进别人的档案。`unique_chain_name` 判成"已占用"并跳号（自测第 17 项钉住）。

### 改动

| 文件 | 改动 |
|---|---|
| `csglide_store.py` | 新增索引整块（`_index_path` / `_read_index` / `_write_index` / `dir_name_of` / `name_of_dir` / `set_dir_of` / `drop_dir_of` / `rename_index_key`）；`chain_dir` 改为唯一实现；删孤儿 `repath_db` |
| `csglide_chain.py` | `chain_dir` 委托 store；`rename_chain` 重写；`delete_project` / `history_list` / `unique_chain_name` / `producer_pkg_path` 走索引；删孤儿 `_repoint_paths` |
| `js/csglide_cast_cmdbar.js` | tooltip / 成功提示改掉"目录跟着改名"的旧说法 |
| `js/csglide_cast_review.js` | 档案行改「目录名不一定等于片名」 |

**验证**：`py_compile` 过；新增 `_selftest_gindex.py` **25 项**（索引读写/反查/改键/老工程补登记/判重）+ `_selftest_rename_e2e.py` **34 项**（真跑 `rename_chain`，含「成片句柄开着时改名照样成功」这条直击 WinError 5 的断言、中枢互斥不失效）全过；旧自测 19/10/22/16/14/16/20/18/9 项复跑仍过。备份 `.bak_gindex_20261020` ×4。

**待真机确认**（改 py 需重启后端）：新建工程 → 渲染一段 → 改名 → 提示「片子已改名为「X」（档案目录不动，改名不会再失败）」；段/台词/素材全在；历史清单显示新名字；`output/h3_chain/` 里目录名仍是旧的。

## 2026-10-20 接缝胶囊：「自动接续 + 连播」合成一个

**症状**：续接胶囊弹窗里「自动接续」按钮和「连播」开关并排，用户读成"同一件事的两个选项"。

### 两个控件其实分属两个维度（别再搞混）

| 控件 | 底层字段 | 管什么 |
|---|---|---|
| 自动接续（`source`） | `pins.disp_pin_mode` | **生成时**钉不钉上一段画面 |
| 连播 | `transitions[cid].type` = `cut`/`unlink` | **播放时**连着放还是停在接缝 |

### 为什么看着奇怪（三个叠加）

1. **把「状态」做成了「按钮」**：常驻网格里它是唯一一个接法按钮，高亮 = "你就是默认接法"。点它永远没变化 → 像坏了或多余。
2. **3 列网格只放 2 个东西**：右边空一格，空格让两者读成"一组里剩下的两个选项"。
3. **名字都带"接"**：「自动接**续**」/「**连**播」像同义词。

### 方案 A（已落地）：常驻只留一个可点控件

- 接法降级成一行**状态字**：`接法：自动接续`（不可点），右边是**唯一的** `[● 连播]` 开关
- 4 种特殊接法全收进折叠区，标题实时带当前值：`▸ 特殊接法（当前：往后接）`
- 非 `source` 时，折叠区内出现 `↩ 恢复自动接续`
- 收起时地面真相也不丢（常驻那行状态字就是）

### 顺手补的死角

钉住上段画面的接法（`extend`/`bridge`/`loop`）→ 左接缝**必然**连播，此时开关**置灰**。旧版能凑出「画面钉着上段尾巴、播放却在接缝停住」的矛盾组合 —— 反方向（`applyMode` 里"钉头必取消断链"）早有，正方向没有。

### 两个实现要点

- **写两遍必漂移**：原来常驻按钮与折叠按钮各一套 onclick，已抽成 `applyMode(row)` 共用（4 个特殊接法 + 恢复按钮都调它）。
- **折叠开合要记住**：卡每次 `menu.replaceChildren` 整张重建，不记 `seamAdvOpen` 的话每选一次接法折叠就自己收起来，连试几种接法根本没法用。

| 文件 | 改动 |
|---|---|
| `js/csglide_cast_sync.js` | `buildModeRow`（565–688）重写：`applyMode` 抽出、`gcast-seam-curline` 常驻行、`seamAdvOpen` 记忆；`SEAM_MODES[0]` 的 tip 改口径 |
| `js/csglide_cast.css.js` | 新增 `.gcast-seam-curline` / `.gcast-seam-cur`；接法网格 3 列 → **2 列**（不留空格）；`.gcast-seam-mbtn.wide` 跨整行 |

**验证**：`node --check` 过（拷成 `.mjs`）。真机：重启 + `Ctrl+F5` → 右键接缝胶囊 → 常驻只有状态字 + 1 个开关；选「往后接」→ 折叠标题变「当前：往后接」、开关置灰；点「↩ 恢复自动接续」→ 回到状态字 + 开关可用。备份 `.bak_seamui_20261020` ×2。

## 2026-10-20 重抽档位体系整体取消：只留「保留头 / 尾」两个帧数框

**起因**：用户用不到微调，只有重抽。原先 6 个控件管同一件事：上下文条「改动幅度」档位（微调/重来）+ 「高级 ▾」弹层里的精细 / 尾部 / 骨架锚点 / 钉头 / 钉尾。

### 收敛后的语义（一句话）

| 保留头 / 尾 | 效果 | 后面各段 |
|---|---|---|
| 都填 **0** | 整段从零重拍 | ⚠ 要跟着重跑 |
| 填了帧数 | 只抽中间，头尾沿用旧版 | 不用重跑 |

**一个机制覆盖两种需求**，档位概念整个消失。

### 后端本来就是这么判的

```python
# csglide_cast.py:2007
if (redo_mode) == "完整重拍" or int(pin_tail or 0) <= 0:   # 同一分支
```

且 `_pin_count(0, 22)` 会正确保留 0（只有脏值/越界才退回默认）。

### ⚠️ 唯一硬前提（不处理就白改）

```python
# csglide_cast.py:2091
if mode == "完整重拍":
    return latent      # pin_head / pin_tail 一个都不读
```

钉帧要生效，档位**必须**是「重画」（无骨架 + 只钉头尾）。三处一起锁死：

| 位置 | 做法 |
|---|---|
| `settings.js` 建面板末尾 | 当前段 `redo_mode` 不是「重画」就改掉 + commit + stash |
| `mkPinInp.onchange` | 每次动框再锁一次（防切段被冲） |
| `run.js` 多段渲染 | 统一本轮各段的 `redo_mode` + `pin_head` + `pin_tail` |

### 删掉的控件 / 孤儿

- 控件：改动幅度档位胶囊、精细、尾部、骨架锚点、「高级 ▾」整个弹层
- 函数：`segmented()`（唯一调用点没了）、`paintRedoLink()`（没有"本档不适用"的控件了）
- 引用：`view.js` 档位回显、`run.js` 的 `redoGroupOf` import、`sync.js` 的 `closest(".gcast-redo-adv")` 排除项
- CSS：`.gcast-ctx-advbtn` / `.gcast-ctx-advmenu` / `.gcast-adv-row` / `.gcast-adv-lbl`

### 连带改的判定

| 处 | 原 | 现 |
|---|---|---|
| `sync.js` `full` | `redo_mode === "完整重拍"` | `pin_head <= 0 && pin_tail <= 0` |
| 主按钮文案（`sync.js:965`） | `完整重拍这一段` / `重抽这一段` | 同上判定（**这就是用户说的那个按钮**） |
| `run.js` flash | 「重抽档已统一为『重来 · 重画』」 | 「保留头 N 帧 / 尾 N 帧」 |
| `csglide_cast.py` 默认 state | `redo_mode:"保留动作"`、`pin_tail:22` | `redo_mode:"重画"`、`pin_tail:0` |

**默认值定 0** = 开箱就是整段重拍（用户主用路径）。`_pin_count` / 1985 / 2089 三处兜底仍是 22，**故意不改** —— 只在老档案没存过 pin_tail 时触发，22 更保守。

### ~~⚠️ 主按钮 `⟳ 重抽这一段` 不能删~~（同日已被推翻，见下一节）

用户要一个运行按钮。当时查证后我说"不能删"，理由是 `renderAll()` 在入队前做 5 件事且全局只有它一个调用点：`syncCheck` / `setSaveNewTake` / `snapProject` / `stash` / `beginRender`。**这个结论后来被自己推翻**（下一节）。

### 方案 S：删掉 `⟳ 重抽这一段`，只留画布运行按钮（同日收官）

**用户诉求**：两个运行入口让人不知道该用哪个 → 只要一个。他自己就习惯"填帧数 → 画布运行"。

**查证推翻了两个论据**（教训写进 MEMORY.md）：

1. 「按钮=范围控制」**错** —— 导演台一次 `queuePrompt` 就渲染一段（节点读 `h3_data` 当前 clip），画布运行跑的就是当前选中那段，与 `renderAll("clip")` 范围相同。
2. 「`beginRender` 是尺寸不生效根因」**错** —— 它只 `this._phase.set(node,"rendering")`，**全库没有任何地方读 `"rendering"`**。空操作/死代码（仅 `beginEdit` 判 boot 用）。

**决定性发现**：ComfyUI 前端 `queuePrompt` 在 `graphToPrompt` **之前**会调

```js
executeWidgetsCallback(this.graph.nodes, 'beforeQueued')
// 官方注释：Allow widgets to run callbacks before a prompt has been queued
```

→ **不用 override 任何 API**，给 `h3_data` widget 挂 `beforeQueued`，每次入队前自动跑准备逻辑，无论点哪个运行按钮。

**`syncCheck` 早已不是弹窗**（20261013 用户定「一切以面板为准」）：自动按面板改齐档案 + 一行 flash，`return true` 不拦渲染，失败也放行。所以**不需要冲突警告条**，异步 fire-and-forget 即可。

| 文件 | 改动 |
|---|---|
| `js/csglide_cast.js` | `h3_data.beforeQueued` = 另存（仅该段有 clip = 重抽时）+ 快照 + 落档 + `void syncCheck()`；batch 800ms 去重；找不到 widget 时 `console.warn` 兜底 |
| `js/csglide_cast_settings.js` | 删 `btnRedoClip` 与其入条；`renderAll` 保留（时间轴「全部渲染」批量跑多段还在用） |
| `js/csglide_cast_sync.js` | 删按钮 onclick 与 tooltip 逻辑；`redoCurrentClip` 保留导出（无 UI 入口） |
| `js/csglide_cast.css.js` | 删孤儿 `.gcast-ctx-go` |

**上下文条最终形态**：`第 N 段 ▾ | 保留 [0]头 [0]尾 | ⊘ 取消接续`，渲染一律走画布运行按钮。

**代价（已知）**：`syncCheck` 是 fire-and-forget，档案改齐可能晚一拍 —— 不影响本次渲染（渲染用面板值）。

备份 `.bak_onebtn_20261020` ×4。

### 主按钮不再改名叫「完整重拍这一段」（同日追加）

全局**只有这一个**主按钮 `btnRedoClip`。「完整重拍这一段」不是独立按钮，是它在头尾都留 0 时的**变体文案**（`sync.js` `updatePlanNote` 里 `full ? "完整重拍这一段" : "重抽这一段"`）。

已删：一个按钮两个名字会被读成两种操作 —— 与"接缝胶囊那两个按钮看着奇怪"是同一类根因。名字固定为「重抽这一段」，是整段重拍还是只抽中间交给 tooltip（`整段重拍第 N 段（头尾都不留）` / `重抽第 N 段（留头 N 帧 / 尾 N 帧）`）与上下文条的两个数字框说明。`full` 变量仍用于 plan 文案与接缝卡提示行，没有变孤儿。备份 `.bak_btnname_20261020`。

### 已知坑（已写进 tooltip）

钉尾**填得比「下一段的承接窗口」小会被自动抬上去**（`cast.py:2097-2120`）。填 10 → 实际按 22 钉。不是 bug：留少了下一段照样接不上，那几帧等于白留。

**改动**：`js/csglide_cast_settings.js`（主体）、`csglide_cast_view.js`、`csglide_cast_run.js`、`csglide_cast_sync.js`、`csglide_cast.css.js`、`csglide_cast.py`。全部 `node --check` / `py_compile` 过。备份 `.bak_redosimp_20261020` ×6。

**待真机确认**（改 py 必须完全重启）：上下文条只剩 `第 N 段 ▾ | 保留 [0]头 [0]尾 | ⟳ 重抽这一段`；① 都留 0 点运行 → 整段重拍，按钮 tooltip 显示「整段重拍…（头尾都不留）」；② 填 22/22 → tooltip 显示「留头 22 帧 / 尾 22 帧」，只有中间变。

### 「高级」折叠去掉标题、常驻展开（同日小改）

红框那行 `▸ 高级　语义桥 · 放大重绘` 是噪音 → 删掉，内容（语义桥 / 抽帧 / 放大重绘）直接显示。

`details + summary` → 普通 `div`（`settings.js` 170–180），导出去掉 `advSum`，CSS 删 `.gcast-adv > summary` 三条（`.gcast-adv` 的 `border-top` 与 `.adv-bd` 保留 —— 分隔与内边距仍需要）。`sync.js:676` 的 `advSum` 是接缝卡「特殊接法（当前：X）」的折叠，独立变量，未动。备份 `.bak_advopen_20261020` ×2。

## 2026-10-20 「班长 MiniMax H3 预览覆盖」画面不自动播放

**症状**：预览画面要点一下才播，用户预期是自动播。

**根因**（`js/minimax_h3_preview.js:308-309`）：某次优化**刻意关掉自动播放**：

```js
// 刻意不设 autoplay：muted 视频浏览器直接放行自动播放，采样预览的
// 成片会被无限循环解码（视频合并节点同款坑）。预览只需首帧，点画面才播。
```

换源时 `pause()` + `显首帧`（强制 `currentTime = 0.001`），只有 `imageArea` 的 click 才 `play()`。

**根治**：不是"永远不播"，而是**看不见就停**。

| 位置 | 改动 |
|---|---|
| videoEl 创建处 | 加 `povVisible` + `povPlay()` + `IntersectionObserver`（滚出视口/被挡住 → `pause()`，回视口 → 续播）；老浏览器 `try/catch` 兜底退化成一直播 |
| `showVideo(url)` | 换源后自动 `povPlay()`（替换原来的"显首帧"） |
| `imageArea` click | **不动** —— 它本来就是 toggle（play / pause），保留手动暂停能力 |

**用户明确：只改这一个节点** —— 画布上其他有同款坑的视频合并节点不要顺手改。

**代价**：节点可见时是持续解码（这是"自动播放"本身的代价）。画布上挂多个这种节点都在跑采样时负载会比"点一下才播"高。

备份 `js/minimax_h3_preview.js.bak_autoplay_20261020`。

## 2026-10-20 SelfLift-Avatar 升级官方 main（v0.1.4 → 全局上下文省显存）

- 上游源码快照在 `selflift-Avatar-main/`（官方 main 分支，含 README_CN / 75 项测试）。
- `_selflift_avatar/` 已整目录覆盖为该版本（8 个文件：nodes / h3_tiling / tiling_ui / PROVENANCE + 5 个新文件 h3_global_tiling、h3_stream_attention、h3_ram_attention、h3_output_chunking、h3_prepared_weights）。备份在 `_selflift_avatar.bak_v014_20261020/`。
- 升级三块内容：① 分块显存估算遍历失效模型引用不再崩（h3_tiling.py None 防护）；② 上游接口改名 `model`→`low_res_model`、`model_hires`→`high_res_model`（汉化层已同步）；③ 高清省显存 4 模式 spatial/global_stream/global/global_ram + token 分块 + 权重缓存预算。
- 汉化层 `banzhang_selflift_avatar_zh.py` 新增 3 个中文端口（省显存模式 / token分块大小 / 权重缓存预算）透传；`__init__.py` 的 TST pop 逻辑对上游新版仍有效。
- `js/banzhang_selflift_avatar.js` 状态栏按模式分流显示（global 系显示全序列/token/回退，不再错显 spatial 参数）；官方 web/ 两个 js 只认英文控件名，对汉化层无效，未引入。
- 已验证：py_compile 9 文件、冒烟 import、官方 75 项 CPU 测试全过、node --check。待真机：重启后节点出现 3 个新控件、global 模式跑一轮看状态栏。

## 2026-10-20 🎯 SelfLift 多级渐进：参数清理 + 补官方能力

改的文件：`banzhang_selflift.py`（备份 `banzhang_selflift.py.bak_cleanup_20261020`）。

已改（4 项）：
1. 删「伪影修正比例」+「视频VAE」两个半残端口（默认 0 永久关闭、DESCRIPTION 自相矛盾），连带清掉 `_SelfLiftMultiStage` 的 rho/vae/w_min/w_max 与 `artifact_aware_consistency_lift` 调用，换纸只剩 learned lifter 一条路径。
2. 「满分辨率分块」下拉 11 项精简为 自动 / 关 / 2 / 4 / 8 / 16（二合一节点共用同一常量，一并受益）。
3. 删「放大后卸载」开关，行为统一为自动搬迁（`make_lifter(..., True)`）。
4. 新增「高分辨率阶段模型」（可选 MODEL）：末段满分辨率换用第二个模型。

关键事实（供后续维护）：
- 实现靠替换 `guider.model_patcher` 运行时生效——ComfyUI `CFGGuider.inner_sample` 每次重新 `prepare_sampling(self.model_patcher, ...)`（comfy/samplers.py CFGGuider），但 `CFGGuider.__init__` 缓存的 `self.model_options` 不跟着换，所以第二个模型的 model_options/patch 不会生效，仅去噪权重不同。已加三重校验（H3 架构 / CONST 采样 / latent 通道数）+ finally 还原。
- 工作流需手动改：删掉的端口在 `templates/producer_video_h3.json`、`producer_video_h3.base.json`、`MiniMax-H3 (4).json` 各有引用（用户已知，自行改接线）。

5. **音频遮罩生效（2026-10-20）**：原来 1702 行把整个 `denoise_mask` 一刀切丢弃（连带埋掉了音频遮罩能力）。现在按流分开处置：视频有空间维度、跨网格会炸 → 保留区置全 1 并告警；音频只有时间轴、不跨网格 → 原样保留，"保住原声"由此生效。配套补了 `audio_anchor`（口径同单级：audio_ms 已是内层采样空间，不可再乘 audio_scale）与非首段的 `_resume_pack_with_pure_audio`（防止内嵌噪声被当残差导致音频发闷）。
   - 四种组合已单测：都无保留→等价无遮罩；仅音频→生效；仅视频→忽略+告警；都有→视频忽略、音频生效。
   - 用法：给 latent 挂噪声掩码（音频那一路填 0），不需要新增节点端口。

6. **移植官方 4 种省显存模式（2026-10-21）**：新增「省显存模式」（spatial/global_stream/global/global_ram）+「token分块大小」+「权重缓存预算」三个端口。
   - 实现：替换 `guider.model_patcher` 为 `h3_global_tiling.tiled_model(...)` 的包装（与第 4 项「高分辨率阶段模型」共用同一套运行时替换机制），包装按 base 对象缓存，换纸多次只包一次。
   - 作用段：网格 ≥ 最终网格的段（标准渐进 = 末段；级间倍率 < 1 时峰值在前段，也会生效）。
   - 互斥：选 global 系时「满分辨率分块」不生效（那是 spatial 专属），已加条件与 tooltip 说明。
   - 入口校验（模式合法性 / chunk 128~16384 / 预算 0~64），`_global_tiled_model` 用 lazy import，缺原生稀疏依赖只有真选 global 才报错。
   - 已验证：py_compile、端口清单、签名一致、import 链路通（能进到 tiled_model 内部）。待真机跑 global_stream。

7. **「💾 H3 显存优化」改傻瓜档位（2026-10-21）**：required 只剩「模型」+「省显存档位」两个；原细调项（省显存模式/前馈分块/分块触发长度/注意力头分组/token分块大小/权重缓存预算）全部下沉到 optional，只有档位选「⑥ 自定义」才生效。
   - 档位表 `_MEM_PRESETS`（顺序 = 越往下越省也越慢）：①关 = 无损1/1；②轻度 = 无损2/4（画面逐位不变）；③强力 = global_stream 4096/4.0；④更强 = global_stream 2048/2.0；⑤极限 = global_ram；⑥自定义。
   - 档位解析集中在 `_resolve_mem_preset()`，apply 只做装配；节点 ID 与显示名未变。
   - 前端 `js/banzhang_mem_optimizer.js`：档位选①~⑤时隐藏 6 个细项 widget（`widget.hidden` + inputEl display，抄 `banzhang_h3_upscale_params.js` 的成熟模式），选⑥自定义才展开；隐藏不影响保存与运行。改 js 需重启 + Ctrl+F5。
   - 兼容做法（可复用）：新增参数放 required 首个并给默认值，旧参数下沉 optional 且一律 None 默认 → 档位优先、细调兜底。
   - 路线①`无损（前馈+注意力）`：老行为，只改计算顺序、数学等价（**默认，老工作流零影响**）；路线②`global / global_stream / global_ram`：完整上下文省显存，复用第 6 项的 `_global_tiled_model`。
   - 节点 ID `BanZhang_H3MemoryOptimizer` 与显示名「💾 H3 显存优化」均未变，新参数全部带默认值 → 已存工作流不用改接线。
   - 选 global 系时建议把前馈分块/注意力头分组调回 1（前馈已被官方包装接管，重复分块白增开销），已写进 tooltip。

**未做（待裁决）**：
- 三节点合一：原本判断「渐进提升」可并入「多级渐进」——**判断有误**。单级是"输出 = 原始 × 放大倍率"（自下而上），多级的最终网格恒等于 KSampler 的 latent（自上而下），二者语义不同。单级的能力实际已被「二合一（latent 放大 + 多级补丁）」覆盖。
- 音视频遮罩：1715 行注释记录 20261010 修花屏结论——钉帧遮罩与多级提升互斥（遮罩参照物跨 1.5× 网格已不在 → 13% 离群 → 满屏彩色光点），当时选择丢弃遮罩 + 方案 B 尾帧回填。加视频局部遮罩等于重开该 bug；音频遮罩无空间维度，可单独先做。

## 2026-10-21 ⏱ 核心帧替换 UI 改版：方案 B「接缝双画面」

**需求**：原面板（标尺+胶片条+取景器+参数行+按钮共 7 层）信息层级多、替换前看不到要换掉什么。出 A/B/C 三方案后用户选定 B。

**最终布局（约 255px 高）**：标题行 → 30px 薄胶片条（滚轮缩放/拖搓/双击适配/Shift+拖平移，标尺取消）→ 双画面接缝：左卡=源帧（`/preview`，左右毛玻璃步进，默认尾帧）、中间 36px 圆形主按钮（→ 替换 / ↩ 橙还原）、右卡=媒体架目标栏位（`/cglide/thumb` 缩略图，角标「当前/已替换/缺」）→ 单行状态。

**关键实现**：

| 点 | 做法 |
|---|---|
| 右卡缩略图 | 复用 `csglide_rack_core.viewURL(file, THUMB_SIZE)`，后端零改动 |
| 媒体架外部改动 | `onRackChange`（bz_rack.js）订阅刷新右卡，onRemoved 解绑 |
| 防呆 | 无文案台/无核心帧行/栏位不存在/栏位空/文件 404 全部在右卡与状态行前置显错，圆按钮禁用 |
| 高度 | 双引擎仍双通道声明；minH 改 DOM 实测 `root.scrollHeight`（ro.observe(root)），兜底常量 248；旧 litegraph `computeSize` 同步 |
| 重绘消息 | 异步错误记 `errMsg`，withBusy finally 重绘不盖错；成功置空 |
| 右卡防闪 | tgtShown+tgtLoaded 缓存，src 未变不重设、重绘不藏图；替换成功后边框 flash 动画 |
| 替换/还原 | 原原位换 file 逻辑（slots + segs[cur] 双写、origFile 还原）不变；取片/选帧/缓冲/预览单飞引擎全部保留 |

**改动文件**：`js/csglide_tailref.js`、`js/csglide_tailref.css.js`（整体重写，备份 `.bak_ui2_20261021`；更早的 `.bak_ui1_20261021` 为旧版）。
**已验证**：两文件 `node --check` 通过；四态（待替换/已替换/未取片/目标缺失）Edge headless 静态截图布局正常。
**首轮真机三问题（2026-10-21 晚，已修）**：
1. 胶片条「抽帧失败」：实际是 sprite 接口 404（3ms 空 body）——后端 py 当晚 20:06 才含 sprite 路由，ComfyUI 进程 18:01 启动未重启（Ctrl+F5 只刷前端 JS，aiohttp 路由必须重启进程）。独立 PyAV 复现 789 帧抽帧完全正常。**修复＝重启 ComfyUI 进程，不改代码**。
2. 白框破图：CSS `.bz-view img{display:block}` 顶掉 `[hidden]` → 加 `.bzt img[hidden]{display:none!important}`。
3. 节点底部 ~445px 空白、状态行被盖：隐藏的 tail_state 只做了旧 litegraph 通道，v2 缺 `computeLayoutSize=零`，其 `.dom-widget` 包装层仍占位。hideState 照搬 csglide_cast 完整写法，addDOMWidget 后 rAF+250ms 藏 stray wrapper（`node._bztTidy`），onConfigure 补跑。
**备份**：`.bak_ui2_20261021`（旧 ui1）、`.bak_b1_20261021`（方案 B 初版）。
4. 高度仍不贴合（二次修复，照搬 minimax_h3_preview 推导模式）：旧写法是"测 DOM 反报 minH"的被动模式，v2 不会因 measured 变化重读布局。改为 `computeLayoutSize = { minHeight:180, maxHeight:undefined }` + `onResize` 双 rAF 后用「面板 scrollHeight + 包装层 offsetTop」推 `size[1]`（差 ≤1px 收敛，不猜标题栏常数）；RO 与 onConfigure 都触发 `node._bztFit`；删掉初值 `+60` 像素补偿，固定初值 300 后收敛。
5. 搓帧滞后（三修）：preview 单帧后端要 seek+解码约 0.3~0.4s，逐帧请求必滞后。改为拖动中零网络：左卡新增 `.bz-stripzoom` 覆盖层，直接铺已下载 sprite 胶片的对应格子（background-size=cols×100% + position 百分比定位），松手 endDrag 才发一张高清 preview；缓冲未覆盖才退回低清网络帧；strip.onload 拖动中即时刷新。
6. 替换后文案台 @图片N 参考图不更新：只 rebuildMediaRackUI 不够，文案台 renderChips 监听 `bz:rack-change`。grab/restore 写数据后补 `emitRackChange({ node: 媒体架id, reason })`。
7. 面板不贴节点外框（四修，照搬 minimax_h3_preview root 机制）：`.bzt` 原是带 border+radius 的内嵌浮层卡片，与节点外框双层、缩放有缝。改 `width/height:100%` 铺满 `.dom-widget`、去 border/radius、背景即节点底色（#191919），padding 改 `8px 10px 10px`；外层框完全交给节点。Edge 静态截图四态确认贴边无双层框。
**待真机验收**（重启 ComfyUI + Ctrl+F5）：① 取片默认尾帧、拖/滚轮/←→ 选帧、胶片条有画面、搓帧左卡实时跟手（短暂糊正常）、松手变清晰；② 右卡显示媒体架核心帧，媒体架手动换文件后右卡跟随；③ 点 → 右卡变尾帧、媒体架栏位同步、**文案台对应 @图片N 参考图立即更新**、状态绿；④ ↩ 还原（文案台也回旧图）；⑤ 无文案台/空栏位时按钮禁用且提示明确；⑥ 节点高度贴合消息行、无底部空白、拖宽/拖窄高度按 16:9 联动、刷新后不缩回。

**五修（2026-10-21 深夜，用户报「窗口没有贴合节点」+ 文案台改名）**：
1. **贴合的根因**：`.bzt` 是 `height:100%` 的盒子，`measure()` 直接读 `root.scrollHeight`
   —— 读到的是「盒子当前高度」，内容比盒子矮时也一样高，于是**永远量不出富余**。
   `fitHeight` 又拿同一个 `scrollHeight` 推 `size[1]`，推导结果恒等于当前节点高度 →
   高度被锁死在初值 300px，底部留一块空白。修法：量的时候把 `root.style.height`
   放开成 `auto`、量完同一帧内恢复（无闪动），`fitHeight` 改用 `panel.minH()`
   （= 内容自然高度），不再读 `scrollHeight`。**根因是「测盒子」而不是「测内容」**，
   以后再改这个面板的高度逻辑，一律以 `minH()` 为唯一来源。
2. **文案台改名**：SEG 模板现在写「将 @图片N 定义为本段的空间关系参照图（…）」，
   不再是「核心帧」。`readCoreFrame` 改为认**结构**（同一行既有 `@图片N` 又有
   「定义为 X」）而非某一名词，`CORE_HINTS = [核心帧, 空间关系参照图, 参照图]` 优先匹配，
   兜底只接受「定义为…图／帧」——同一段里还有「将 @图片12 定义为林昭（主角）」这类
   主体定义行，认错行会把主角槽位换成尾帧，**宁可报错也不猜**。
   别名剥掉「本段的/该段的」前缀，`@图片25 定义为本段的空间关系参照图` → alias = `空间关系参照图`。
**改动**：仅 `js/csglide_tailref.js`（`measure()`、`fitHeight()`、`readCoreFrame()`），
备份 `.bak_fit5_20261021`。`node --check` 通过；四组文案用例（新版/旧版/裸写/只有主体行）实测正确。

**六修（2026-10-21 深夜，用户新提示词 + 改名）**：
1. **新增「编号对照式」候选**：SEG 里同一张参照图有两种写法，都指向同一栏：
   `将 @图片25 定义为本段的空间关系参照图（…）` 与 `图片编号对照：@图片25 对应 KF_01-02。`
   两种都进候选，谁在用谁。候选分层：**名词命中**（核心帧/空间关系参照图/参照图/参考图）
   > **名词兜底**（定义为…图／帧）> **编号对照式**。
   编号对照式还加了一条硬约束：**整段恰好一个对照项**才敢用 —— 若模板给每个资产
   都写了一行对照，取第一条会把主角图当参照图换掉；有歧义就不出手。
2. **改名**：节点显示名 `⏱ 核心帧替换 (Tail Ref)` → `⏱ 参照图替换 (Tail Ref)`；
   面板标题、按钮 tooltip、右卡 alt、终端日志前缀、DESCRIPTION 同步。
   `CORE_HINTS` 里保留「核心帧」——旧模板还要认。
   改名动了 `.py`：**必须完全重启 ComfyUI**（Ctrl+F5 只刷前端）。
**改动**：`js/csglide_tailref.js`（`coreRef()` 候选分层 + UI 文案）、`csglide_tailref.py`（显示名/描述/日志）、`js/csglide_tailref.css.js`（文件头注释）。
**已验证**：五组文案用例实测（新格式两式并存→@图片25 空间关系参照图；只有单条编号对照→@图片25 KF_01-02；
多条编号对照→不认报错；旧格式核心帧→@图片7 核心帧；只有主体行→不认报错）。`node --check` ×2、`py_compile` 通过。

**七修（2026-10-21 深夜，媒体架排序诊断去噪 + 多张 KF 参照图）**：
新 SEG 模板里同一张参照图出现两次（定义式一行 + 编号对照一行），架上参照图又有很多张
（KF_01-02 / KF_01-05 / KF_02-03…），原来的诊断有两处噪音，且关键信息反而看不到：
1. **误报「认不出」**：第一处 `@图片25` 认不出主人（架上没设别名），后面编号对照那行
   认得出 —— 排序结果其实是对的，诊断却报「认不出：@图片25」。改法：某个编号在后面
   认出了主人，就把它前面那条「认不出」撤掉（只清本 kind 的区间，三种素材编号各一套）。
2. **误报「编号重复」**：同一编号在文本里出现两次被当成冲突。改法：重复处照样去认一次
   主人，**同一件素材**不报，**指向另一件素材**才报（那才是真问题）。
3. **补「认出」清单**：`认出：空间关系参照图→@图片25、色彩参考色板→@图片12、张三→@图片7`
   （上限 8 项）。素材多到几十张时，「挪动 7 个」根本看不出哪张落到第几栏，名字→编号
   一行摊开才可对账。
4. **「顺序已对齐」不再报红**：一格没挪不一定是坏事，原来 `!r.total` 分支无条件传
   `bad=true`，红字报「顺序已对齐」；现在只有真读不到编号/真认不出名字才红。
5. **参照图替换节点的歧义提示**：本段出现多条编号对照（架上参照图多）时不再只说
   「没找到参照图行」，而是把候选摊开（`KF_01-02（@图片25）、KF_01-05（@图片31）…`）
   并告诉用户在文案台加一行「将 @图片N 定义为本段的空间关系参照图」。
**改动**：`js/csglide_rack_sort.js`（sortSlots 诊断去噪 + reportOf 加「认出」行 + toast 重组）、
`js/csglide_tailref.js`（contrastItems 抽出 + 歧义提示）。
**已验证**：用真实源码切出 sortSlots/reportOf 跑三组（参照图有别名 / 无别名 / 一号两素材）：
认出的落位全对；无别名时不再误报认不出；真冲突仍报「编号重复：@图片25」。两个文件 `node --check` 通过。

## 2026-10-22 🔗 视频合并：图片输出模式画面不贴节点下边框

**现象**：输出视频时前端贴合正常；输出图片（PNG/JPG/WEBP）时画面底边距节点下边框留一段，
表现为画面上下被 `object-fit:contain` 补出黑边。

**根因**：高度模型把底部控制条写成常量。`previewWantH()` / `wantHeight()` /
`computeLayoutSize.minHeight` 三处一律 `+ CONTROLS_HEIGHT(44)`，但图片分支
（`isImage` 里 `bar.style.display = "none"`）根本不渲染这排控制条 → 节点凭空高 44px，
多出来的高度被 `flex:1 1 auto` 的画面吃掉，等比居中后变成上下黑边。
`refit` 的 `contentBottom` 读的是官方权威底边，widget 高度已含这 44px，所以永远收不回去。

**与既有同类 bug 同源**：「仅画面模式折叠后底部留一大片空白」——都是模型假设某一行一定
存在。详情面板那次已改为动态的 `_painter_info_h`（隐藏归零），控制条漏改，因为它是
预览容器的 DOM 子元素、不在 widgets 数组里，没被那次改动覆盖到。

**修法**：新增 `controlsH(widget)` —— 控制条 `display === "none"` 算 0、否则算 44、
尚未创建时按 44（建成后 refit 校正）。三处常数全部换成它。
`minHeight` 也必须一起换：否则极扁的图（10:1 全景）会出现 min > max，同一毛病换素材复发。

**改动**：仅 `js/painter_video.js`（`controlsH` 新增 + 3 个调用点），备份 `.bak_ctrlh_20261022`。
`node --check` 通过。前端改动，Ctrl+F5 生效（无需重启）。

## 验证入口

- Python：`.\python_embeded\python.exe -m py_compile <文件>`
- JS：`cp <文件> /tmp/x.mjs && node --check /tmp/x.mjs`（ES module 必须 .mjs）
- **前端自测全跑**：`node tests/run_all.mjs`（23 个用例，约 3 秒）
  - 单跑一类：`node tests/run_all.mjs rack`（文件名含 rack）
  - 只列清单：`node tests/run_all.mjs --list`
  - 用例是 `tests/js/_selftest_*.mjs`，独立可跑，退出码表达成败；新增用例不用改 runner
- 前端改动：完全重启 ComfyUI + Ctrl+F5

## 2026-10-22 ⏱ 参照图替换：抽帧性能专项（代理片 + 落盘缓存 + 前端去抖）

**症状**：拖胶片条 / 切帧时 CPU 打满、内存飙（ComfyUI 2.3GB，抽帧瞬时 +484MB）。

**四个真根因（均有实测）**
1. **PyAV 18 的 `seek()` 只收 int（单位 `stream.time_base`）**，代码传 float 秒 →
   `TypeError` 被 `except` 吞掉 → 回退 `c.seek(0)` → **每次都从第 0 帧解到目标帧**
   （取第 357 帧解 358 帧 / 618ms）。
2. **全尺寸 `to_image()`**：3072×1728 RGB = 15.9MB/帧、45~96ms/帧；sprite 一次存 9 张
   → 实测进程 RSS 41MB → 525MB。
3. **零缓存**：每次请求重解；窗口移出缓冲就重发 sprite（每次 ~2.2s）。
4. **前端每帧写 widget**：`writeState` → `graph._version++` → 官方
   `clone(app.graph.serialize())` 整图序列化（拖动时每帧一次）。

**做法（对齐 `csglide_join_panel` 的雪碧图缓存，补它没做的两条）**
- **代理片**：ffmpeg 把母片转成 512px 小副本（全片 719 帧 ~1.5s / 395KB），
  胶片条与预览只解代理片（像素量 1/36）；**落盘那一帧仍解母片全尺寸**（不能糊）。
- **解码管线内缩放**：`frame.reformat(width, height, format='rgb24')` 后再转 PIL，
  绝不落地全尺寸 RGB。
- **落盘缓存** `<temp>/h3_tailref_cache`：内存 → 磁盘两级，原子写；**key 带
  mtime+size**（片源会被取最新成片反复覆盖，Join 的 key 没带，照搬会命中旧画面）。
- `asyncio.Semaphore(2)` 限并发解码（实测 5 并发 sprite 从 8.7s 降下来）。
- 前端：`setFrame` 拖动中只改内存、**不写 widget**；`endDrag` 松手落盘一次。

**实测（719 帧 / 3072×1728 / 48fps）**

| 项 | 改前 | 改后 |
|---|---|---|
| 胶片条 sprite | 2200 ms | **125 ms**（缓存命中 0 ms） |
| 单帧预览 | 1300 ms | **26 ms**（缓存命中 0 ms） |
| 落盘帧（母片全尺寸） | 1300 ms | 333 ms，仍 3072×1728 |
| 单次内存尖峰 | +484 MB | 无全尺寸 RGB 落地 |
| 首次建代理片 | — | 1.5 s / 395 KB（一次性，落 temp） |

**改动**：`csglide_tailref.py`（+代理片/缓存/seek 修复/缩放，`_grab` 加
`width`/`need_full` 参数）、`js/csglide_tailref.js`（`setFrame` 拖动不写状态、
`endDrag` 落盘）。
**备份**：`csglide_tailref.py.bak_perf_20261022`、`js/csglide_tailref.js.bak_perf_20261022`。
**已验证**：`py_compile` + `node --check` 通过；单进程实测上表全部数字（含磁盘缓存
命中 0ms、落盘帧仍 3072×1728）。**待真机确认**：重启后拖胶片条的观感与内存曲线。

**已知取舍**：代理片第一次要 1.5s（可后续做整片预热）；老代理片文件名带 mtime，
片源更新后会留下旧文件（temp 目录，暂不清理）；ffmpeg 缺失时自动退回母片（功能不受影响）。

## 2026-10-22 导演台：监视器 + 段块缩略图 性能专项（同一套代理片）

**新建设施**：`core/csglide_proxy.py`（AGENTS.md：core/ 放共用）—— 代理片生成/复用、
文件签名（mtime+size）、原子写、PyAV 18 正确 seek、解码内缩放 `scaled()`。
**两个节点共用一份**：⏱ 参照图替换、视频合并/Join。

**① 监视器播代理片**
- `csglide_film.js` `vurl()` / `playUrlOf()` 加 `&proxy=auto`；
  `csglide_join_panel.py` `/video` 新增 proxy 分支：**母片宽 >1600 才转代理**，窄片原样返回。
- 恢复的是 20261010 被删的"低清代理"（当时成片多是 1080p，删得对），现在成片可以是
  3072×1728（530 万像素），浏览器软解扛不住 → 按**分辨率阈值**恢复，不搞一刀切。
- ⚠ 左上角尺寸标签读的是 **`/info` 的元数据（母片真实尺寸）**，与播放源无关 ——
  `csglide_film.js` L1594 用的是 `info.width/height`，播代理片**不会**把标签变成 512。
  实现时必须保证 `/info` 仍传母片路径。

**② 段块缩略图 `/thumb` 对齐 `/sprite`**
- 旧 `/thumb`：只有内存缓存、**无落盘、无并发限流、解母片**。
- 现在：落盘缓存（`<temp>/h3_thumb_cache`）+ 复用 `_sprite_sem` + `frame_jpeg` 走代理片
  + 解码内缩放。key 版本升到 `th2`（口径变了，避免命中旧图）。

**③ `<video>` 卸载补 `load()`**
- 只 `removeAttribute("src")` 浏览器**不一定**释放解码缓冲（PROJECT.md 2026-10-18 记过：
  `preload=metadata` 挡不住）。补 `pause() → removeAttribute("src") → load()` 三步，
  `clearView()` 与 `destroy()` 两处都补。

**改动**：`core/csglide_proxy.py`(新) / `core/__init__.py`(新) / `csglide_join_panel.py`
（`frame_jpeg`+`_width_of`+`/thumb`+`/video`）/`csglide_film.js`（vurl、playUrlOf、卸载×2）
/`csglide_tailref.py`（改为引用 core，行为不变）。

**已验证**：`py_compile`×3 + `node --check`；**整包 `load_custom_node` 返回 True**（节点注册
正常）；Tail Ref 重构后重跑实测（sprite 154ms / 预览 161ms / 落盘 889ms，仍远好于改前
2200/1300ms）。
**待真机确认**：`/thumb` 与 `/video?proxy=auto`（依赖 `PromptServer.instance`，独立进程
加载不了，只能重启后验）；监视器内存曲线。

**还原**：`.gitignore` 忽略 `/custom_nodes/`，git 不覆盖插件文件。
`csglide_tailref.py.bak_perf_20261022` / `js/csglide_tailref.js.bak_perf_20261022` 是**改前**版；
`csglide_join_panel.py.bak_perf_20261022` / `js/csglide_film.js.bak_perf_20261022` 是**改后**版
（这两个改前漏备份 —— 要回退找我逐处反向改，改动点均已标 `20261022`）。

**踩坑**：`from .core.xxx import` 在**单文件加载**路径下会
`ImportError: attempted relative import with no known parent package`。
ComfyUI 对本插件走的是**目录加载**（有 `__init__.py`）→ 相对导入可用，实测 True。
别用"单文件 load_custom_node"来判断节点能不能起来 —— 那条路径不是真实启动路径。

---

## 2026-10-22 🔗 视频合并：拖底边拉高 → 画面不跟随 → 松手才回弹

**现象**：拖节点底边拉长，画面（DOM 面板）不跟着变，底部先空一片；松手瞬间节点高度
被拉回贴合面板。

**根因（查官方 sourcemap 确认，不是猜）**：节点高度有**两条**改写路径，代码只守了一条。
- litegraph 路径：`#processNodeResize` → `node.setSize(size)` → `setSize` 内部
  `this.size = size2; this.onResize?.(this.size)` —— 我们挂在 `onResize` 上当帧钳高度 ✔
- **Vue 路径**：`GraphView` 的 `useNodeLayout().resize()` → `mutations.resizeNode(id, size)`
  → 写 layoutStore → `useLayoutSync.startSync` 拿 `layout.size` **单向覆盖** `liteNode.size`
  （不是取大）。**全程不经过 setSize / onResize** → 我们的当帧拦截完全不触发。
- 于是：拖拽中 liteNode 被 Vue 写成鼠标值（拉长）；DOM 画面受 `maxHeight` 限制撑不动
  （不跟随）；松手后 Vue 一 arrange（或我们的 200ms 节流 refit）把高度收回内容底边 → 回弹。
- 放大问题的旧代码：`heal()` 里 `if (dragging) return`，而 `dragging` 只认
  `app.canvas.resizing_node === node`（Vue 路径下恒为 null）→ 拖拽中彻底让路。

**修法（不再只守一条路）**
- `heal()` 拖拽判定放宽：`hardDrag = resizing_node === node`；
  `liveDrag = hardDrag || (指针按下 && 本节点高度本帧变过)`。
  判定精确到「这次交互的目标对象」：指针没按下绝不实时贴合，避免与官方布局拉扯。
- 指针按下状态只能从 DOM 事件层补（`window` 捕获阶段 pointerdown/up/cancel）——
  Vue 那条路径 litegraph 侧无任何信号。
- 贴合时 `node.arrange()`（画面高度跟着宽度走）→ 直接改 `node.size[1] = want`
  （**不调 setSize**：官方 setSize 会再触发 arrange，每帧重入、高度来回跳）。
- `bzResizing()` 也认 `node._bz_live_drag`：否则 Vue 路径拖宽度时每帧读
  `offsetHeight` = 强制同步布局（就是「拖节点卡」的来源）。
- 松手收口（`syncDragState` 的 refit）仍只认 `hardDrag`，拖到一半停手不会被误判松手。

**改动**：仅 `js/painter_video.js`（`bzResizing` / `heal` 两处 + 指针监听）。
**备份**：`js/painter_video.js.bak_draghug_20261022`。
**已验证**：`node --check` 通过。
**待真机确认**：① 拖底边拉高时高度纹丝不动（当帧被顶回，不再"先变长后弹"）
② 拖宽度/右下角时画面与节点同步跟随，无卡顿 ③ 松手后无二次跳动。

**后续（用户拍板 A）**：上面这套仍是「面板贴合节点」，补丁只会越加越多。
已按用户要求**照 VHS「视频合成」重写**（见下条），本条仅作历史留档。

---

## 2026-10-22 🔗 视频合并：照 VHS 重写高度机制（方案 A）

**为什么**：旧版是「面板贴合节点」——弹性分支 + 拖拽中每帧钳 `node.size`，
必须跟 Vue 的 layout 单向覆盖抢高度 → 补丁叠补丁（heal / 200ms 节流 /
指针监听 / 宽度外推缓存 / 拖拽钳制）。VHS 反过来：**节点贴合面板**，
且只在内容变化时对齐一次，冲突源直接不存在。

**照搬的两招**（`ComfyUI-VideoHelperSuite/web/js/VHS.core.js`）
| VHS | 本节点 |
|---|---|
| `previewWidget.computeSize = (w)=>[w, 高度]`（2493 行，定高分支） | `attachPreviewLayout` 同款，高度 = 画面 + 控制条 + 详情 + DOM 边距 |
| `fitHeight(node) = setSize([w, node.computeSize()[1]])`（434 行） | `fitHeight` 同款，只在内容变化时调 |
| fitHeight 时机：loadedmetadata / img.onload / 菜单切换 | 同：metadata 到位、图片 onload、详情面板更新、折叠切换、预览诞生 |

**删掉的（整套）**：`heal()` / `onDrawBackground` / 500ms 巡逻 / 200ms 节流 /
`bzInZoom` / window 指针监听 / `wantHeight` / `syncDragState` / `onResize` 钳制 /
`contentBottom` / `refit` 循环 / 宽度外推缓存（`_bzWInset`/`_bz_wmap`）/ `bzResizing` /
`previewWidgetOf` / `MIN_VIDEO_H`。约 250 行 → 40 行。

**配套改动**
- 隐藏 widget 改定高分支：`computeSize = () => [0,-4]`（官方 `if (w.computeSize)` 优先，
  弹性分支那套在定高下不再生效）。
- `previewContentW` 不再读 `clientWidth`：改用 `node.size[0] - domChrome`（VHS 的
  `(node.size[0]-20)`）。DOM 未挂载时 clientWidth 是 0，且每帧读它 = 强制同步布局
  （拖节点卡顿的直接来源）→ 顺带解决卡顿。
- `domChrome` 补回容器 1px 边框（容器是 border-box，不补画面差 2px 就出黑边），
  量一次缓存。

**改动**：仅 `js/painter_video.js`。**备份**：`.bak_draghug_20261022`（重写前）、
`.bak_ctrlh_20261022`（更早）。
**已验证**：`node --check` 通过。
**待真机确认**：① 拖底边拉高 → 保持拉高、不再回弹 ② 拖宽 → 画面与节点同步变大
③ 刷新/执行后 → 节点自动收到画面底边、无上下黑边 ④ 图片模式与视频模式都无黑边。

**真机第一版的问题（已修）**：照 VHS 写死 `contentW = node.size[0] - 2×margin` 是错的。
VHS 的容器是它自己造的；我们用官方 `.dom-widget`，左右另有一层读不到常量的内缩
（实测节点 668 → 容器 clientWidth 只有 547，差 121，远超 20）。
宽度估大 → 画面高估大 → **节点比面板高一截（底部空白）+ 图片左右黑边**，两个症状同源。
改为：宽度实测 `clientWidth`，以 `node.size[0]` 作缓存键（宽度没变零回流，变了一次），
未挂载或 v-show 隐藏时沿用上次实测值。

**八修（2026-10-22 下午，文案台：提示词文档直接拖进来）**：
需求：每个提示词文档里有包裹符，不用再「打开 txt → 找块 → 复制 → 切回粘贴」。
文档格式（实测 `祖龙锁/第1集/SEG_6_prompt.txt`）：
`<<<核心帧提示词>>> … <<<核心帧提示词_END>>>`、`<<<视频提示词>>> … <<<视频提示词_END>>>`。
用户定案：**拖拽**进面板 / 只认 `<<<视频提示词>>>` / **替换**本段 / **支持批量**。

**改动**：`js/csglide_desk.js`（一个文件）
1. 面板加 `.d-toast` 提示条；拖入时面板描虚线（`.bzdesk.dropping`）。
2. `pickVideoBlock()` 取块，**没有包裹符就整篇当提示词**（老文档不至于读不进）。
3. `segNoOfFile()`：`SEG_6_prompt.txt` → 6。
4. `clipOfSeg(no)`：段号 → clip id，取导演台 `gcast_project.shots[no-1].clip`。
   ⚠ 后端 `clips[].index` 实测返回 2,2,3,4…（前两段重复），**不能当段号**。
5. 单文档 → 直接写当前段；多文档 → 提示条列清单 +「确认写入 N 段」按钮
   （覆盖多段不可撤销，不闷头写）。
6. `writeSeg()`：写 `st.segs[cid]` + `pushSegText` 落库 + `commit()`。

**已验证**（headless，真实拖放 + 真实文档）：
- 单文档：段内文字 2901（与块等长）、不含 `<<<`、提示条正确 ✅
- 批量 3 个：清单 + 确认按钮 + 写入后三段都是 2901 ✅
**改动**：`js/csglide_desk.js`。备份 `.bak_doc_20261022`，修复版 `.fix_doc_20261022`。
**待办**：测试残留目录 `output/h3_chain/bz测试用工程_勿用/`，关掉 ComfyUI 后可删。

## 2026-10-23 媒体架 P0 性能专项（重绘/广播合帧 + 视口外卡片虚拟渲染）

**背景**：素材上量（尤其 100+ 张）后媒体架滚动、拖入、排序、切段明显卡顿。
20261020 的批量导入优化（beginBatch）只解决「导入那一下」；本次解决日常路径
里**每次操作**的三块结构成本。节点高度是手工拖拽模式（`.gcast overflow:auto`，
槽位增删不改节点高度），本轮不动任何高度机制。

| # | 瓶颈 | 修法 | 文件 |
|---|---|---|---|
| P0-2 | 每次 commit 同步 `setDirtyCanvas(true,true)` 全画布重绘 | 新增 `schedulePaint()`：rAF 帧级合并，一帧内 N 次 commit 只重绘 1 次；参数恒为 `(true,true)` 只合次数不降级（铁律）；50ms setTimeout 兜底后台标签页。**数据写入（snapshot + widget.value）仍同步**，点「运行」必读最新架面 | `js/csglide_media_rack.js` |
| P0-3 | 每次 commit 广播 `bz:rack-change`，导演台 `syncRack`、文案台 `renderChips` 两个大面板被反复全量重算 | `emitRackChange` 发送端 rAF 合帧：同帧 + 同节点 id 合 1 条（reason 取并集），不同节点各自保留；监听方本就按节点 id 过滤、数据签名去重，且事件只是「变了」的信号、监听方读最新值，合帧不丢语义 | `js/bz_rack.js` |
| P0-1 | 200 张卡片全量参与布局/绘制（renderImages 已 keyed 增量，但 DOM 全量常驻） | 图片卡加 `content-visibility:auto` + `contain-intrinsic-size:auto 100px 108px`：浏览器原生虚拟渲染，视口外卡片跳过布局/绘制/图片解码，占位尺寸首次渲染后自动记忆、滚动条不跳。DOM/事件/拖拽/keyed 缓存/IO 懒加载全部保留。视频/音频卡各上限 3 张，不做 | `js/csglide_rack_css.js` |

**为什么 P0-1 没用 JS 窗口化（translateY 撑高/卸载挂载）**：content-visibility
是浏览器级虚拟列表，性能等价（视口外不耗布局帧）、零逻辑风险；JS 窗口化要重写
renderImages 的挂载/拖拽/落点校正，风险大。真机若仍不够再上 JS 窗口化。

**自测**：新增 `_selftest_rack_framecoalesce.mjs`（从 bz_rack.js 真实抠源码 +
window/rAF/timer 桩）**12 项**：同帧同节点 3 次合 1、不同节点不互吞、跨帧不合并、
reason 合并、全局事件、rAF 暂停时 setTimeout 兜底且不重复。全过。
3 个文件 `node --check` 过。备份 6 个文件 `.bak_p0perf_20261023`。
**待真机确认**（重启 ComfyUI + Ctrl+F5）：
1. 架上放 100 张图：滚动跟手、卡片缩略图/编号/别名正常，滚动条不跳；
2. 批量拖入/排序/删除/手动换位：画面跟手、无丢图；
3. 导演台槽位区、文案台素材 chip 随媒体架操作即时更新（合帧后联动正常）；
4. 切段、刷新页面：素材与别名不丢；
5. 折叠/展开媒体架、节点高度：与改动前一致（本轮未动高度）。

## 2026-10-23 媒体架 P1 性能专项（视频/音频卡延迟挂载 + 参考图后端缓存）

P0 之后的两块剩余成本：①切到含多个视频的段时，所有视频卡立刻建媒体元素、
idle 回调同时 fetch 整个视频文件做 WebAudio 波形解码（10MB+ ×N）抢 IO；
②改文案重跑 / 多分段 / 二采三采时，参考图每轮重复 PIL 解码 + lanczos 缩放 +
视频 VAE 编码，VAE 编码是重跑白等的主要 GPU 时间。

| # | 瓶颈 | 修法 | 文件 |
|---|---|---|---|
| P1-1 | 视频/音频卡一 paint 就建 `<video>`（拉元数据/首帧）+ buildTrim（波形 canvas/RO + idle 全量 fetch 解码） | 重内容（媒体元素 + 修剪条 + 音轨勾选）包进 `.gcast-heavy`，模块级共享 IntersectionObserver（rootMargin 300px 预挂）：进视口才挂载一次，不卸载（媒体元素有 32 上限池化、波形 wavCache 已缓存）；不支持 IO 时直接挂载。卡销毁链 `card.__gcastDestroy` 改为链式（trim 的 RO 注销 + heavyObs.unobserve）；未挂载占位 min-height 200/88px，挂载后归零由内容定高，滚动条不跳 | `js/csglide_rack_cards.js`、`js/csglide_rack_css.js` |
| P1-2 | 参考图每轮重复 PIL+缩放+VAE 编码 | 仿 `_ref_audio_cache` 加 `_REF_IMAGE_CACHE`（OrderedDict LRU，上限 24，单条约 8MB）：key=resolve 后绝对路径 + mtime_ns + size + 编码 tw/th，缓存缩放后像素张量（ref_items data，喂 Qwen 视觉）与视频 VAE 潜空间（ref_blocks latent，下游 model.py:547 自行 `.to(device)`），一律 CPU 副本不占显存。命中时 pixels clone（防下游就地写污染缓存）、latent 只读共用（与音频缓存同口径）。画布尺寸变/match 档位变/文件被替换 → key 自动变化；首尾帧的 VAE 编码在官方 encode_from_tokens_scheduled 内部，节点侧缓存不到，本轮不动 | `csglide_cast.py` |

**注意**：probeDuration/tagChroma 的结果（dur/chroma/codec）本就写进 slot 并
commit 持久化，重复 paint 不重复探测；本轮无需再动。

**自测**：新增 `_selftest_ref_image_cache.py`（AST 从 csglide_cast.py 真实抠
缓存三件套）**11 项**：键生成/缺失文件/命中/CPU 副本/尺寸不同键不同/LRU 淘汰/
条数上限/文件变更键变/None 键不写入，全过。`node --check`（cards/css）、
`py_compile`（cast）过。备份 `*.bak_p1perf_20261023`（P0 备份保留）。
**待真机确认**：
- 前端（重启 ComfyUI + Ctrl+F5）：架上放 5~10 个视频后切段，切段瞬间应明显
  变快（视口外卡片不显示视频画面、不出波形，滚到面前约一帧内才出现）；
  滚到后悬停预览、播放修剪区间、双柄修剪、快速帧档、音轨勾选全部正常；
  排序换位/删除/改名后卡片内容正常；控制台无报错。
- 后端（**完全重启** ComfyUI，改了 .py）：同一批参考图先跑一次，再只改文案
  重跑，日志里图片行应出现「复用缓存（跳过缩放与 VAE 编码）」，出片正常；
  改画布分辨率/换参考图后不出现错误复用（日志回到正常编码行）。

## 2026-10-23 媒体架 P2 性能专项（广播携带原文，导演台/文案台零解析）

P0/P1 之后剩余的主线程成本：媒体架每次 commit 都把整份 rack_data（素材多、段数
多时可达 MB 量级，含 segs 全部段的快照）写进 widget.value（这一步是 ComfyUI
运行/保存所必需，不能延迟，铁律：用户直接操作写入实时）；紧接着导演台
syncRack、文案台 renderChips 收到广播后**各自把这份大字符串 JSON.parse 一遍**
——而媒体架手里就有刚序列化的原文，这两次解析是纯浪费。

| # | 瓶颈 | 修法 | 文件 |
|---|---|---|---|
| P2-1 | 每次广播后导演台/文案台各 parse 一遍整份 rack_data | ① 合帧事件 flush 派发前从节点读最新 rack_data 原文，挂进 detail.raw（一帧只读一次）；② bz_rack.js 模块级监听（无环基础模块，注册早于一切面板）收到事件后**只解析一次**，按媒体架节点 id 存 per-node 旁路 rackFeedCache（Map，上限 32 FIFO）；③ rackSlotsOf 三级查找：旁路 raw 与当前 widget.value 同字符串引用（=== 先判同指针，O(1)）→ 旧现场缓存（键加节点 id）→ 现场 parse。widget 被外部改（Ctrl+Z/加载/外部写入）时引用必变，=== 不命中自动回退现场解析，语义不丢。所有调用方（cast_meta/desk/conflict/shots）走同一 rackSlotsOf，零改动 | `js/bz_rack.js` |

**不做的**：媒体架自身 JSON.stringify 是 ComfyUI 排队/保存时序列化工作流的
数据来源，延迟它必须同时 hook queuePrompt/serialize/复制节点/保存多个入口，
风险大而单次仅 10ms 级；事件携带 raw 是字符串引用同页面传递，不克隆零成本。

**自测**：新增 `_selftest_rack_feedcache.mjs`（从 bz_rack.js 真实抠 rackNodeOf/
rackSlotsOf/合帧/旁路三段 + app/window/rAF/JSON 桩）**17 项**：首次现场解析、
缓存命中零 parse、同帧 3 广播只解析 1 次、事件后读新数据、外部改 widget 回退、
多节点互不串、旁路 32 上限 FIFO、未知节点不写旁路、滞后事件不命中旁路，全过。
`node --check` 过。备份 `js/bz_rack.js.bak_p2perf_20261023`。
**待真机确认**（重启 ComfyUI + Ctrl+F5）：
1. 架上放 50~100 张图后反复改素材（排序/勾选/拖入/删除）：导演台槽位区、
   文案台素材 chip 照常即时更新，手感不劣于 P0；
2. Ctrl+Z 回滚 rack_data / 加载老工作流：导演台/文案台显示的素材跟着回滚，
   不残留旁路旧数据（外部改值无事件，自动回退现场解析）；
3. 多媒体架节点（复制一份）各自素材不串；
4. 排队前缺引用自检、@标签提示与改动前一致。

**性能专项收尾**：P0/P1/P2 全部完成。再上量仍卡的话，最后一张牌是 JS 窗口化
虚拟列表（P0 时刻意没用，content-visibility 已等价覆盖视口外布局/绘制成本，
只有 DOM 本身到几千个时才需要），需重写 renderImages 挂载/拖拽/落点，风险大，
无真机数据不主动做。

## 2026-10-24 🎯 SelfLift 多级渐进：「省显存模式: 9」校验失败（控件位置错位）

**症状**（真机报错，节点 396）：
```
Failed to validate prompt for output 313:
* BanZhang_SelfLiftMultiStage 396:
  - Value not in list: 省显存模式: 9 not in ['spatial', 'global_stream', 'global', 'global_ram']
```

**根因**：ComfyUI 前端的 `widgets_values` 是**按位置**存的数组，不是按名字。
上一轮把 `省显存模式 / token分块大小 / 权重缓存预算` 插在
`满分辨率分块` 与 `彩色光点清理力度` **之间**，于是所有老存档整列右移一格：

| 存档数组 | 当时含义 | 错位后落到 |
|---|---|---|
| `['2,2','1.5',model,'自动',9]` | 第 5 位 = 彩色光点清理力度 9 | 省显存模式 = **9** |

已确认 `minimax h3-三采-1021.json` 的 node 396 正是 `[..., '自动（按显存智能规划）', 9]`，
第 5 位就是那个 9。`minimax h3-三采-1022.json`（在我改坏之后保存的）则是
`[..., '自动', 'spatial', 4096, 4, 9]`——两种错位形态都存在于用户桌面工作流里。

**修复（两层）**：
1. **把新控件挪到老控件后面**（治根）：optional 顺序改为
   `满分辨率分块 → 彩色光点清理力度 → 省显存模式 → token分块大小 → 权重缓存预算 → 高分辨率阶段模型`。
   `高分辨率阶段模型` 是 MODEL 插口，不占 `widgets_values` 位置。
   这样 1021 那种 5 元素数组 1:1 对得上，新三项走 default。
2. **入口容错**（治急）：新增模块级 `_coerce_tiling_mode / _coerce_int / _coerce_float`，
   `apply()` 先洗一遍再校验——认不出的值退回安全默认 + `log.warning`，
   不再整条工作流拒绝执行。`spatial` 就是加这三个控件之前的老行为，
   所以退回它不会改变画面结果。`💾 H3 显存优化` 的 `_resolve_mem_preset`
   同病同治（脏档位 → `① 关`，数值项走 `_coerce_int`）。

**为什么不再抛错**：老工作流已经落盘，用户不可能被强制重存；报错只会让人
没法出图。诊断信息用 warning 打到控制台，比堵住队列更有用。

**真机验证**：
1. 重启 ComfyUI + Ctrl+F5，**重新加载一次**工作流（让前端按新位置重建控件）；
2. 节点上应看到顺序：满分辨率分块 / 彩色光点清理力度 / 省显存模式 / token分块大小 / 权重缓存预算；
3. 若没重载就直接排队，控制台会出一条
   `「省显存模式」收到无法识别的值 9（多为老工作流的控件位置错位），本次已按 spatial 处理`
   ——能出图，属预期。

## 2026-10-25 🎨 图像编辑台：拖入 .md 批量读资产提示词（一个文档多个提示词）

**需求**：文案台能拖文档读提示词，图像编辑台也要能；但一份资产文档里有多个提示词
（祖龙锁三份合计 13 个：场景 2 / 道具 7 / 主体 4），不能按文案台「一文档 = 一段」那套。

**定案（用户选 A A A A）**：默认全选可勾掉 / 批量时清空参考图 / 画幅按正文自动设 / 输出按资产名分目录。

**为什么走前端派发、不新增后端节点**：ComfyUI 一次执行 = 一张图，13 个提示词只能拆成
13 个 job。项目里已有 `api.queuePrompt(0, {output, workflow})` 的成熟用法
（`csglide_cast_run.js:175`、`csglide_cast_review.js:563`），复用同一口径。

**文档格式**（纯文本规则即可切，不需要 AI）：
```
## @图片9 = 守缺斋前堂
<<<场景提示词>>>
…正文…
<<<场景提示词_END>>>
```
`## 变更记录` 这类非资产节按「不匹配 `## @图片N =` 就丢上下文」排除。

**改动**：
| 文件 | 说明 |
|---|---|
| `js/csglide_asset_batch.js` | 新建。`parseAssetDoc` / `canvasOf` / `stampSavePrefix` / `dispatchAll` / `installAssetBatch` |
| `js/csglide_qwen.js` | 加 import；`buildUI` 的返回值改为 `const ui` 并补 `locked()` / `longSide()` 两个钩子；末尾 `installAssetBatch(node, ui)`；`destroy` 里收批量条 |

**关键实现点**：
1. 每个 job 从 `graphToPrompt()` 的 output **深拷贝**再改。不深拷贝的话第二个 job 会带上
   第一个的提示词，文件名前缀也会一层层叠加成 `A/B/C`。
2. 批量改的是**提交对象**里的 `qwen_data`，不动画布上的 widget —— 跑完面板仍是原提示词，
   不覆盖用户手写内容。
3. 参考图显式清空 + `canvas_from_ref=false`：这批资产是新建的文生图，
   带参考图会污染画面；`canvas_from_ref` 留着的话后端会去找「图片1」。
   后端 `if not images_vl: log("…本次按纯文生图编码")` 是官方分支，空图不报错。
4. 画幅只定**长边**（沿用节点「最长边」习惯），另一维按比例下取整、按 32 对齐，
   避免 4:3 直接算出 4096 宽这种爆显存尺寸。

**修掉的坑**：保存节点 `filename_prefix` 为空时，`"" + "/" + 名字` 会变成以斜杠开头的
路径，落到 output 之外。改为空前缀直接用名字，非空才拼子目录。

**已自测**（Node 侧，非浏览器）：
- 三份真实文档解析 13 个，类型/字数全对，正文无 `<<<` 残留、无变更记录表格；
- 注入逻辑 11 项：提示词各自独立、参考图清空、画幅注入、其它配置原样保留、
  两 job 互不影响、原始骨架未污染；
- 前缀边界 5 项：有前缀 / 空前缀 / 末尾斜杠 / 非法字符 / 读不到画幅时不动画布。

**待真机验证（前端 UI，未测）**：
1. 重启 ComfyUI + Ctrl+F5（改的是 `js/`，只刷新网页不够）；
2. 把 `祖龙锁-资产提示词-主体.md` 拖进图像编辑台面板 → 底部出现过拖高亮 + 清单 4 项；
3. 勾掉 1 项 → 按钮上方计数变「已选 3 / 4」；点「批量生成」→ ComfyUI 队列出现 3 个任务；
4. 跑完看输出：保存目录下出现以资产名命名的子目录；
5. 若保存节点是 PreviewImage（没有 filename_prefix），提示条会说只能靠流水号对照。

**09:46 追加：去掉底部常驻提示语**。原「拖入 .md 批量读资产提示词」平时占着一行高度。
改为三态显隐：`.gqb` 默认 `display:none`，只在「拖入中 / 清单展开 / 有结果提示」任一成立时
出现；拖入时临时显示「松手读取 .md」当反馈（不能全删——没有反馈用户不知道拖对没拖对）。
去掉 `.gqb-head` 的 `min-height:26px`，否则隐身时仍留 32px 空白。

**09:50 修正：底部面板文字重叠（根因不是行高）**。真机截图表现为「拖入提示语」与
提示词框 placeholder 叠在同一行、按钮压在清单项上。根因是**布局**：
`.gcast` 是 `display:flex; flex-direction:column; height:100%`，批量条作为普通 flex 子项
插进去，展开后抢走提示词框（`flex:1 1 auto; min-height:190px`）的空间；框被压到比内容矮，
框内 placeholder 溢出自身盒子（`overflow` 非 hidden），于是与相邻元素视觉重叠——
不是两个元素定位到一起了。

修法：批量条改 `position:absolute; left/right/bottom:10px`（相对 `.gcast` 的 padding box，
10px 正好对齐内容边），完全不参与 flex 布局，从根上不挤压任何东西。
**同类问题不再犯的判断**：往「固定高 + flex column」容器里加**临时操作面板**时，
一律走覆盖式浮层，只有当面板是常驻内容时才让它参与布局。

**09:55 追加：适配「🎥 视频合并」保存节点**。用户实际出图走 `banzhangVideoCombine`
（`banzhang_video_tools.py:1082`），不是 SaveImage，所以上一版只打 `filename_prefix`
的适配落空、提示「没识别到保存节点」。

该节点保存图片的参数是 `🏷️ 文件前缀`，落盘名 = `_safe_name(前缀)_N{节点id}_{序号:04}.png`。
**不能沿用 SaveImage 的「加 `/` 分子目录」写法**——`_safe_name`（1024 行）会把
`/` 换成 `-`，子目录会退化成名字里的一道横线。改为拼在后缀：`班长作品` → `班长作品_陈墨白`。

`stampSavePrefix` 现在返回 `{dir, prefix}` 两路计数，提示语按命中的那一路说人话；
两种节点同时存在时两路都打标。已测 10 项：前缀拼接、不叠加、图像连线不动、
其它参数原样、PreviewImage 不误改、双节点共存。

## 2026-10-25 10:05 🎨 图像编辑台：片子级（LoRA 触发词），单张与批量共用一条注入路径

**需求**：像文案台的「片子级」那样，把一段触发词自动拼在提示词最前面。
用户明确要求「批量和单张运行通用，不用在两个地方设置」。

**为什么不在面板提示词框里拼**（这是本轮最关键的设计决定）：
提示词框是用户手写的内容，自动改写会被编辑器当成「自己打的」，撤销栈、切段、
`@引用` 高亮全都对不上；用户还得手动删。改为在**提交对象**上拼。

**唯一注入点**：单张点运行和批量派发最终都经过 `api.queuePrompt`，
在那一层包一次即可 —— 两条路径行为一致、不会拼两次、只设一处。
（`bz_queue_align.js` 已经用同一手法包过 `api.queuePrompt`，是项目既有口径。）

**口径照抄** `csglide_desk.compose_text`：片子级在前、正文在后，`\n` 连接；
先把 `\r\n` 归一、去行尾空白、trim。片子级为空则不拼。

**改动**：
| 文件 | 说明 |
|---|---|
| `js/csglide_asset_batch.js` | 新增 `composeGlobal` / `injectGlobals` / `patchQueue` / `PROVIDERS`；浮层加「片子级」输入框；`open()` 供标题行按钮调用 |
| `js/csglide_qwen.js` | 提示词标题行加「片子级」按钮；`let batch` 提到 `buildUI` 顶部（按钮 onclick 要提前引用） |

**持久化**：存 `node.properties.gqbGlobal`，随工作流保存；注入读的是输入框**实时值**，
不缓存快照 —— 改完立刻点运行就生效。

**防重复**：`INJECTED` 用 `WeakSet` 记住已拼过的提交对象。
ComfyUI 重试、或 `api.queuePrompt` 被多层包装时不会叠加成 `A\nA\n正文`。

**已自测 13 项**：拼接顺序、空白/CRLF、空片子级不拼、只影响本节点、不影响同图另一个
图像编辑台、不碰视频合并节点、损坏 JSON 不炸、空 output/null 不抛、provider 抛错不影响
提交、重复注入不叠加。

**待真机验证**：
1. 重启 ComfyUI + Ctrl+F5；
2. 点提示词标题行的「片子级」→ 浮层出现（没拖文档也能开）；
3. 填 `LORA_X, trigger_word` → 关掉浮层 → 直接点画布「运行」→ 出图应体现触发词；
4. 再拖文档批量跑 2 个 → 两个都该带触发词，且提示词框里的文字**没被改**；
5. 保存工作流、刷新页面 → 「片子级」内容还在。

**10:12 改版：去掉「片子级」按钮，改常驻输入框**（用户要求「像文案台那样直接给一个框」）。

- 位置：提示词标题行下方、参考图 chips 上方（`pWrap.append(pHead, gRow, chips, …)`），
  跟文案台「片子级在上、本段在下」的阅读顺序一致。
- **高度怎么不挤压**：`.gq .gcast-ed.prompt` 的 `min-height` 190 → 150，让出 40px 换这一行
  （input 26px + pWrap 的 6px gap），净变化 −8px，反而比原来宽松。
  这是上一轮「浮层挤压」教训的反向应用：常驻元素必须**先腾出对应空间**再插进去。
- 注入逻辑完全不变，仍然只在 `api.queuePrompt` 那一层拼；输入框只提供实时值
  （`hooks.globalInput`），不缓存。
- 键名 `node.properties.gqGlobal`（上一版是 `gqbGlobal`，功能当时未真机使用，无迁移负担）。
- 删掉：`btnGlobal`、`open()`、`forced` 状态、`.gq-globalbtn` / `.gqb-grow` / `.gqb-global` 样式。

## 2026-10-25 10:53 修 🎨 图像编辑台：片子级刷新后变空

**现象**（用户报）：「刷新网页之后片子级里面我输入的内容不见了」。

**根因：两个独立缺陷叠在一起，都不是「没保存」。**

1. **没有回填路径**（直接原因）。上一版只在 `gIn` 的 `input` 事件里写
   `node.properties.gqGlobal`，而负责恢复面板状态的 `load()` 只从 `qwen_data`
   反序列化，**从头到尾没读过 properties**。所以刷新后值其实还在 properties 里，
   只是没人把它送回输入框——表现成「空了」。
2. **写 properties 不标脏**（隐性原因）。`node.properties` 的改动不触发
   `graph.change()`，ComfyUI 既不会把工作流标记为「未保存」，自动保存的
   防抖也不会跑。所以这数据能不能落盘，全看用户有没有手动 Ctrl+S——
   没保存就等于真的没了。

**修法：主路径换成 qwen_data，properties 降级为老存档兼容位。**

| 位置 | 改动 |
|---|---|
| `st` | 新增 `global: ""`，跟 prompt / canvas 一样参与 `commit()` |
| 输入框 `input` | `st.global = gIn.value` → **双写** properties → `commit()`（写进 qwen_data） |
| `load()` | 从 `d.global` 恢复；存档里没这项时回退 `properties.gqGlobal`；回填 `gIn.value` |
| `ui.syncGlobal` | 新增，`onConfigure` 末尾调用，补 `onNodeCreated` 时 properties 尚未应用的时序空档 |
| `onConfigure` | `load()` 之后追一句 `this.gq?.syncGlobal?.()` |

**关键细节：用 `null` 而不是 `""` 区分两种情况。**
```js
const gSaved = typeof d.global === "string" ? d.global : null;  // null = 存档里没这项
st.global = gSaved == null ? gLegacy : gSaved;                  // "" = 用户故意清空
```
写成 `gSaved || gLegacy` 的话，用户清空输入框后刷新会被 properties 里的旧值顶回来，
清空操作等于无效。`syncGlobal` 同理，`st.global` 有值就直接 return，绝不覆盖。

**自测 13 项全过**（用 `new Function` 直接执行源码里抠出来的三段，不是重写逻辑）：
新存档恢复、老存档回退、两者并存时 qwen_data 优先、都空、清空不回退、
输入双写 + commit、清空双写、syncGlobal 不覆盖 / 走迁移、
完整往返（输入 → commit → 刷新 → load）、两处并存不冲突。
另 9 项注入回归：global 进 qwen_data 后注入仍只拼一次、同对象/跨次都不叠加、
批量派发正文也带触发词、框清空则不拼、老存档注入不破 canvas。

**待真机**：刷新后值回填、Ctrl+S 后重开工作流、以及「输入即标脏」（窗口标题应出现未保存标记）。

## 2026-10-25 13:56 🎨 图像编辑台：日志端口补全提示词全文

**背景**：用户报「图跟提示词有关但被带偏」，删掉片子级也无效。原日志只打模型/别名/画布/参考图，
**从来没打过一句提示词**，所以三种完全不同的故障（字被别名吃掉 / @ 转译动了内容 / 压根没送进来）
在日志里长得一模一样，无法定位。

**改动**（`csglide_qwen.py`）：

| 位置 | 内容 |
|---|---|
| `parse_qwen_data` | 新增 `"global"` 键（只给日志分段显示用，不参与编码） |
| `_build` 转译段 | 把 `expand_aliases` / `transcribe_prompt` 的中间态拆成变量，逐段入日志 |
| `_build` 改写段 | 改写成功打全文 + 前后字数；没改动也说明一句 |

**新日志形状**：
```
【片子级】（空，不拼）  /  实际内容
【提示词·面板原文】128 字
<全文>
【提示词·别名展开后】135 字          ← 只在真的变了时出现
<全文>
【提示词·送编码】135 字（含 @ 转译）
<全文>
【负面·面板原文】/【负面·送编码】同上
【提示词·改写后】210 字（原文 135 字） ← 只在真改写了时出现
<全文>
```
外接提示词（`prompt_text` 接线）时首行标签自动改成「外部文本」，避免把外部文本误标成面板原文。

**自测 8 项**：global 解析、prompt/canvas 不受影响、老存档无此键不炸、坏 JSON 不炸、
普通中文转译后逐字不变、不含 @ 时不产生多余日志、未知 @ 不吞内容。

**为什么这么改能定位**：字数对照是第一道筛子——「面板 128 字 / 送编码 128 字」说明文字没被动过，
问题在参考图或采样；字数变了就顺着上一段日志看是哪一步动的。

## 2026-10-25 13:59 修 🎨 批量派发：多条资产共用同一批参考图（"串了、分不开"）

**现象**（用户报）：单张写同样提示词正常，拖 `.md` 批量就不正常，
「好像多个提示词串了，没有区分开」。

**排查顺序（前两步排除干净，才轮到第三步）**：
1. 解析：拿三份真实文档跑 `parseAssetDoc` → 10 条、正文零交叉包含。**不是切分问题**。
2. 派发：`dispatchAll` 每条都 `JSON.parse(JSON.stringify(p.output))` 深拷贝后
   `cfg.prompt = it.body` 覆盖，`IS_CHANGED` 也带了 `qwen_data`，不会被缓存复用。**不是串写**。
3. 后端：`_build` 第一句 `merge_rack_refs(cfg, refs)` —— **这里把它塞回来了**。

**根因：一个字段背了两种语义。**
前端批量时写 `cfg.images = []`，意思是「本次不要参考图」；
后端 `merge_rack_refs` 看到空 list，理解成「面板没填，去媒体架兜底」，于是
把媒体架那套图整个填回去。结果 10 条资产**每条都套着同一批参考图**，
Qwen 的 `reference_latents` 压过文字，画面互相像、分不开。
单张不走批量派发，媒体架按接线来，所以正常。

**修法：拆出显式声明，不靠「清空集合」表达「不要」。**

| 文件 | 改动 |
|---|---|
| `csglide_assets.py` | `merge_rack_refs` 开头判 `cfg.get("no_refs")` → 清空 images 并直接 return |
| `csglide_qwen.py` | `parse_qwen_data` 解析 `"no_refs"`（缺省 False） |
| `js/csglide_asset_batch.js` | `dispatchAll` 写 `cfg.no_refs = true` |

`csglide_cast.py` / `csglide_cast_legacy.py` 的 cfg 没有这个键，`cfg.get` 返回 None，
走原分支，行为零变化。

**为什么这次不会再犯**：以后凡是要表达「本次不要某个默认会兜底的东西」，
一律用显式布尔字段，不再用清空集合——集合为空在兜底逻辑里天然等于「没填」。

**自测 11 项**：无声明时照旧兜底、声明后不回填、声明时连残留一起清、
`no_refs=False/缺省` 行为不变、无媒体架不炸、parse 能解析、缺省 False、
端到端（批量 payload → parse → merge → images 为空、画幅与提示词保留）。

**副作用（必须告知）**：批量现在是纯文生图，**不继承媒体架的参考图**。
需要参考图的资产请单张跑。若将来要「批量也带图」，得另加显式选项，
不能退回「清空 images」那条路。

## 2026-10-25 15:22 批量派发改为「面板画布优先」（用户选 B）

**问题**：批量生成时面板上设的画布尺寸不生效。

**根因**：批量这条路压根不用面板的宽高，只取**长边**再按文档「画幅：16:9」重算另一边，
面板填的高被丢弃（1024x1024 + 文档 16:9 → 1024x576）。另外换算在**拖入文档那一刻**
就做完存成快照，之后再改画布也不会重算——两个原因叠在一起，看起来就是「设了没用」。

**决策**：用户选 B —— 面板画布说了算，文档「画幅」不再参与尺寸计算。
理由：面板是用户亲手设的，文档那行字原来是给资产定版式的辅助信息，
让它反过来覆盖用户明示的设置，优先级就颠倒了。

| 文件 | 改动 |
|---|---|
| `js/csglide_asset_batch.js` | `dispatchAll` 去掉 `cfg.canvas = it.canvas`；拖入时不再预算画布；删掉孤儿 `canvasOf` / `RATIO` / `MULTIPLE` / `CANVAS_MAX` |
| `js/csglide_qwen.js` | 删掉只为 `canvasOf` 存在、现已无人调用的 `ui.longSide` |

**副作用**：文档里的「画幅：16:9」现在只是提示词正文的一行字（对模型仍有文字引导，
但不再决定输出像素）；批量 N 条的尺寸全部一致，等于面板那一个。

**仍然存在的硬约束**：画布会被对齐到 32 的倍数，1080 → 1088、720 → 736。
前后端同口径（`snap` / `_side` 都是 `round(n/32)*32`），改不了，改了会糊或报错。

**回归 6 项**：删代码后三份文档仍解析出 10 条、条目不再带 canvas 字段、正文完整、
面板画布原样穿过注入层、片子级为空不拼、注入不改画布。

## 2026-10-25 16:30 方案A：中央库成为段数据唯一权威（修「段词串台」整族）

**现场**：文案台切段后各段提示词互相错位（段3 的词出现在段1、新段覆盖前段）；
「全部渲染」跑完后各段不切换/变空。用户拍板走方案A（单一真相源），不留旧兼容。

**根因（一个时序 bug 引出全部症状）**：20261024 加的「乐观首跳」把编辑器画面
先换成目标段的词，但 `curKey` 要等 `await syncFromCast()` 之后才更新；夹在中间
的「切段前把编辑框内容存进旧段」（`csglide_desk.js` switchSeg）于是把**新段**的
词按**旧段**身份写进 `st.segs` 并 `pushSegText` 进中央库——画面与记账分家多久，
错写就飞多远。渲染逐段切换 = 每段犯一次，整片搅乱。实证：工程10 库里
clip_0001 与 clip_0006 逐字相同（clip_0001 原文已丢，快照/归档均无可恢复副本）。

**改动**（备份 `*.bak_centralauth_20261025_163016`）：

| 文件 | 改动 |
|---|---|
| `js/csglide_desk.js` | 新增 `edSegKey`（编辑器画面绑定段）与 `reconciledKey`；乐观首跳改为「先存旧段→账与画面同瞬间切→本地没词也照样切」；`onSegChange` 写回按 `edSegKey`；正式流程的存旧段加 `curKey!==k` 护栏；去重条件升级为「同段且已对账」；hydrate/读档/换代际处同步作废两个新变量 |
| `csglide_desk.py` | compose 执行时按 chain{name,clip} 读中央库 desk.segs/global，**库为准**（含空串=真删空）；库没这个键才退回面板镜像 |
| `csglide_media_rack.py` | emit 执行时按 chain 读 `load_rack(d,cid)` 覆盖 slots（fps/audio_out 不覆盖：库里是工程级一份） |
| `csglide_media_rack.js` | commit 把 `chain{name,clip}` 写进 rack_data 镜像，供后端认段 |
| `csglide_cast.py` | `_do_build` 执行时按 chain 读 `load_clip_doc().state` 整份覆盖 cfg（外接 h3_override=制片中枢程序化整包除外）；对账日志措辞改为「按库渲染」，rev_drift 回执 used=store |

**不变量**：面板 widget 从此只是**镜像缓存**；执行与对账只认中央库。写回身份由
编辑器绑定的段决定，不再存在「画面已切、账没切」窗口。

**验证**：py_compile×3 ✓；node --check×2 ✓；producer_selftest PASS=46 FAIL=0 ✓；
只读脚本对真实库跑通：6 段各自独立段词/state/架面均能按段读出，compose 优先级
正确（库词盖镜像词）。待真机：切段来回×10 不错位 + 两段全部渲染后各段正确。

**遗留（非本次引入）**：
- `templates\validate_templates.py` 报 `producer_video_h3.json` 节点36
  `BanZhang_SelfLiftMultiStage` 没有「视频VAE」输入口——模板与节点定义不符，
  与本次改动无关（未动 selflift/模板），待用户定夺。
- 工程10 的 clip_0001 库里是 clip_0006 的副本（旧 bug 污染，原文不可恢复）：
  重启后切到段1 全选删除、重写，删除会正常推空进库。
- 未做（本次刻意不做，收益低风险高）：widget 瘦成纯指针、bz_prompt_build/
  bz_queue_align 删除、段级修订号乐观锁。库权威已在执行端兜底，镜像漂了也
  送不出去；要彻底删编译层需另开一轮真机回归。

---

## 2026-10-25 建立本地版本控制（替代散落的 .bak）

**背景**：项目此前零版本控制 —— ComfyUI 主仓库 `.gitignore` 第 8 行整行忽略
`/custom_nodes/`，本目录也无独立 `.git`，46 个 `.bak` 是唯一还原点（删了就真的回不去）。
另外 `WEB_DIRECTORY="./js"` 经 `server.py:1340 web.static` 把整个 `js/` 目录静态暴露，
放在 `js/` 下的 `.bak` 任何人访问 8188 都能下载；但 `server.py:423` 的
`glob('**/*.js')` 严格匹配 `.js` 结尾，**不会执行**，所以只是源码外泄风险、不是 bug 源。

**已做**：
- 项目内 `git init`。`.gitignore` 排除 `wheels/`(634MB) `tools/`(392MB ffmpeg)
  `Fonts/`(18MB) `semantic_bridge/`(58.7MB 模型) `caches/`(253 张缓存图)
  `ui-preview/`(设计原型) `__pycache__/`。纳管 461 个文件 12.93MB，`.git` 占 5.2MB。
- 提交 `58bfdd7` = 清理前完整快照（含全部 46 个 `.bak`）；
  提交 `0dd67e9` = 删除 38 个过期备份（A 类零价值 12 + B 类同文件多世代 26），`.bak` 46→8。

**约定（以后照此执行）**：
- 改代码前不再手工留 `.bak`，改完直接提交。回滚单个文件：
  `git checkout <提交号> -- <路径>`。看某次改了什么：`git log --oneline` + `git show <提交号>`。
- 保留的 8 个诊断用 `.bak`（真机验证通过后可删）：`csglide_desk.js.bak_centralauth_*`、
  `csglide_media_rack.js.bak_centralauth_*`、`minimax_h3_preview.js.bak_trscrub`、
  `csglide_cast_settings.js.bak_segnum`、`csglide_cast.css.js.bak_segnum`、
  `js/_archive/banzhang_visual_loader.full.js.bak`、`_flashvsr/mp4.py.bak_ffshared_20261015`、
  `banzhang_translator/__init__.py.bak_llamadep_20261013`。
- **不在 git 范围内，删了真没**：`ComfyUI-DD-Nodes/`（含 8.9MB
  `_Intelligent_Layout.bak_deleted_20261025`）、`K:/ComfyUI_windows_portable/新建文本文档.bat.bak_deleted_20261025`。

---

## 2026-10-25 段块右键菜单精简 + 「跳过」可视化（用户选 A1/B2/方案1）

**两件事**

1. 段块右键菜单删掉「✎ 改名…」和「🔒 锁定这一段」。
2. 「跳过这一段」点完在时间轴上毫无痕迹 —— 补一个显性标记。

**为什么跳过没标记（根因，不是没写样式）**

- 跳过的真值是**工程侧** `p.shots[].off`（`csglide_cast_conflict.js` 的 `toggleSkip`）。
- 时间轴段块的数据来自后端 `film_summary`（`bz_store.js`），`clips` 里**没有 `off`**。
- 所以 `paintSeg` 只能看 `playable / pending / locked / has_latent` 四种。
- 结果：点完唯一反馈是菜单项文字变成「◉ 恢复参与渲染」，菜单一关就没痕迹。

**改名 / 锁定怎么删的（A1 / B2）**

| 文件 | 改动 |
|---|---|
| `csglide_cast_sync.js` | 删两个菜单项；`const anchor = ui.menuAnchorFor(i)` 随之成孤儿一并删；`renameShot` 保留（双击改名仍走它） |
| `csglide_cast_monitor.js` | 删 `setSegLock` / `toggleSegLock`（含 `/cglide/chain/lock` 调用）与导出；`onPick` 去掉 `ui.segLocked` 同步与两处 `clip.locked` 早退；`canResize` 改成恒真的 `() => true` |
| `csglide_film.js` | 删 `.bzf-locked` 紫环、段号 `🔒`、签名位 `\|locked`、`el.frames.disabled` 的锁定闸门、`onResize` 的 `row.locked` 早退、5 处 meta 文案里的「· 🔒 已锁定」 |
| `csglide_cast_meta.js` | `updateSegChip` 去掉 `ui.segLocked` 三处（`<span class="mlock">🔒</span>` / `classList.toggle("locked")` / title 双分支） |
| `csglide_cast_cmdbar.js` | 删 `ui.segLocked = false;` 声明 |
| `csglide_desk.js` | `refreshSegChip` 去掉文案台的 `🔒` 前缀与 `locked` 类 |
| `csglide_cast.css.js` | 删 `.mlock` 样式 |
| `csglide_cast_review.js` | `menuAnchorFor` 失去唯一调用方，删函数 + 删导出 |

**锁定的后端数据不动（刻意）**

`csglide_store.py` 的 `locked` 列、`set_locked`、`csglide_chain.py` 的 `/cglide/chain/lock`
路由全部保留。理由：后端**没有任何渲染逻辑读 `locked`**（`csglide_chain.py:823` 注释写明
「锁定 = 钉住编辑目标，不是这段不许改」），它只是个存取字段。删了要重启 ComfyUI、
又牵动 `store_selftest.py` 的 4 条断言，收益为零。档案里可能残留 `locked=1`，**无任何行为效果**。

⚠ `csglide_chain.py:51` 的 `chainlocked` 是**文件并发写锁装饰器**（8 处 `@chainlocked`），
和段锁定毫无关系，任何清理都别碰它。

**跳过的标记怎么接的（通路甲：纯前端，不用重启）**

- `csglide_film.js` 新增 `st.skipIds`（Set 或 null）+ `isSkipped(c)`；
  新增对外接口 `setSkipIds(ids)`：集合没变直接 return，变了才 `renderSegs()`。
- `csglide_cast_conflict.js` 的 `paintSegTools()`（唯一通用重绘入口）末尾把
  `shots.filter(sh => sh.off && sh.clip).map(sh => sh.clip)` 推给 `ui.monitor.setSkipIds`。
  `toggleSkip` 本来就调 `paintSegTools()`，所以点完立刻生效。
- 签名里用 `isSkipped(c)` 取代原来的 `c.locked` 位 —— 标记变化才会触发重画，不额外掉帧。

**视觉（方案 1）**

`.bzf-seg.bzf-skip`：右上角「已跳过」角标（10px 文字、`::before`）+ 色头与画面压到 34% 并去饱和。
**压暗只压 `.bzf-seg-hd` / `.bzf-seg-bd` 两个子块，不压 `.bzf-seg` 本体** ——
`opacity`/`filter` 加在块上会把 `::before` 角标一起变淡，角标就白写了（已踩过一次）。
选中态让开一半（62% / 灰度 .5）：选中比"它被跳过"更要紧，但也不能丢这条信息。
`.bzf-skip.bzf-pend::after` 隐藏 —— 待办琥珀圆点与角标抢同一个右上角。

**验证**：node --check ×9 全 OK；`locked` 在 `csglide_film.js` 已零残留；
全项目 grep `segLocked / toggleSegLock / setSegLock / menuAnchorFor / mlock / bzf-locked` 全部无匹配。
**待真机**：重启后 Ctrl+F5 —— ① 右键段块只剩「跳过 / 复制 / 版本 / 清除颜色」；
② 点跳过立刻变灰并出现「已跳过」角标；③ 双击段块仍能改名；④ 拖段块边缘仍能改时长。

---

## 2026-10-25 6 段渲染完变 10 段（方案一 + 三：砍反向通道 + 库级硬约束）

**症状**：时间轴设 6 段，渲染完刷新网页变成 10 段。持久化在库里，重启也不回去。

**铁证（`events` 流水，同一秒内）**

```
17:58:14  desk_save  clip_0001  {"segs": 6}    ← 前端此刻明确知道只有 6 段
17:58:14  clip_add   clip_0007  shot=1myflik  ┐
17:58:14  clip_add   clip_0008  shot=dosexg9  │ 同一秒凭空建 4 段
17:58:14  clip_add   clip_0009  shot=31f2gxz  │
17:58:14  clip_add   clip_0010  shot=830a5u8  ┘
17:58:14  reorder    order = 10 个 cid        ← 固化进档案
```

随后 `shots` 10 行 / `shot_state` 6 行 / `segment_bindings` 7 行；`clip_0010.ord=5`
与 `clip_0006` 撞号。

**根因：有一条「渲染结果 → 工程副本 → 覆盖权威」的反向通道**

`csglide_cast_monitor.js` 原来的 `scheduleSelfHeal` 里这一行是祸首：

```js
if (!have.has(sh.clip || "")) sh.clip = "";     // == 旧 191 行
```

- `have` 来自**这一轮** `film_summary` 的返回。`film_summary` 有 0.8s TTL 缓存，
  日志里同期有 `[状态库] project 拉取超时(8s)` —— 清单偶尔是**空/不全**的。
- 于是「这次没画出来」被当成「档案里不存在」，先把 `sh.clip` 清空，再调
  `registerShot` 重新登记。
- 而后端 `add_clip` 的**幂等键就是 `shot.id`**（落库为 `shots.shot_uid`）。
  调用方把 `sh.clip` 清空 = 把幂等键弄丢 = 幂等彻底失效 → 后端老老实实
  新建记录，一段变两段。**不可逆**。
- `reorder_clips` 不是元凶：`csglide_chain.py:719-724` 只接受档案里已存在的 cid。

一句话：**「不知道」被当成了「不存在」，然后拿这个错误结论去写权威数据。**

### 方案一｜拆掉自愈，切断反向通道

| 位置 | 改动 |
|---|---|
| `js/csglide_cast_monitor.js` | 删掉整套 `scheduleSelfHeal`（原 174-204 行），替换为 `reconcileShotsWithOrder(rows)`：**只同步工程副本，绝不新建档案记录**，方向改为「档案 → 工程」单向 |
| `js/csglide_cast_sync.js` | `registerShot` 原有护栏 `if (!shot \|\| shot.clip) return;` 补上血案注释，写明「让档案跟上工程」只能走 `film_summary` 对账，不许在这里补登记 |

`reconcileShotsWithOrder` 的护栏（缺一道就会重演，**外加一条判据**）：

1. **档案这一轮一段都没画出来 → 直接 return。** 分不清「真空片」和「没加载完」，那就什么都不做。
2. **会摘到一段不剩 → 直接 return。** 清单一定不全，宁可不做。
3. **判据只认「既往某轮亲眼见过、这一轮却不见了」的段**（`seenCids`，按工程存 Set）。

第 3 条是实施时才发现的坑：最初按「这一轮有没有」判，护栏 2 只挡得住「全摘」。
TTL 竞态下 `rows` 只回 2 段、工程 6 段时，`drop=4`，`4 >= 6` 不成立 → **照样摘掉 4 段**
—— 事故从「6 段变 10 段」变成「6 段变 2 段」，同一个病换了张脸。
所以改成：某个 cid 必须在**任何一轮**里真的出现过才算「确认存在过」，没见过的
一律不动。代价是「加载前就已删掉的段」会在工程里留个空引用 —— 无害（画个空块），
**宁可留空块也不误删，方向必须是这一边。**

（原来的「每个工程只对账一次」也一并去掉了：它会让第二次真删的段永远对不上账，
而 `seenCids` 已经承担了「不误删」的职责，反复进来时 `drop` 自然为空。）

真要做的时候先 `ui.snapProject('对账前…')` 留还原点，再倒序 `splice` → `commit` →
`paintSegTools` + `lanesFlash`。

`sweepGhostShots` 保留 —— 它只摘工程副本、不碰档案，与反向通道无关。

### 方案三｜数据库硬约束（`csglide_store.py`）

```python
# v3（20261025）：shots.shot_uid 唯一 —— 一段的 uid 全局只能登记一次。
SCHEMA_VERSION = 3

def _migrate_v3(conn):
    ...
    conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS uq_shots_uid "
                 "ON shots(shot_uid) WHERE shot_uid <> ''")
```

- `_create_schema(conn)` 末尾插 `_migrate(conn)`（建表之后、写 `PRAGMA user_version` 之前）。
- `_migrate` 幂等、**零破坏**：不删用户段；失败只打日志，库继续可用。
- **`ord` 刻意不加唯一约束**：`ord = index - 1`（`csglide_store.py:617`），
  两段同 index 是**合法业务状态**，加了会让保存直接抛错。历史撞号按 `meta.order` 重排一次。
- `shot_uid` 唯一索引若因历史重复建不上 → 写 `meta.migrate_v3_warn` 告警，**不静默删段**。

### 诊断工具｜`templates/project_db_doctor.py`（长期保留）

```
python templates/project_db_doctor.py "<工程名>"          # 只读体检
python templates/project_db_doctor.py "<工程名>" --apply  # 修，且先自动备份整库
```

判据的关键：**「谁是谁」有两个声明处，两处都要看** ——

- `shots.shot_uid` —— 登记表说这个 cid 的 uid 是 X
- `shot_state.chain.shot` —— 段内容自己说「我是 X」

20261025 那次事故里，空壳 `clip_0007` 的 uid（`1myflik`）**只**出现在
`clip_0003` 的 `state.chain.shot` 里。只查 `shots` 表 = 看不见它（第一版就漏报了）。
`--apply` 的顺序：备份 → `BEGIN IMMEDIATE` → 删 8 张子表里空壳的行 → 重排 `ord`
→ **还原被污染的 `state.chain.shot`** → 写 `meta.order` / `meta.current` → 建唯一索引。

### 已做的数据修复（`未命名工程 13`）

```
备份 → output\h3_chain\未命名工程 13\_dbbackup_20261025_181327\project.db
摘掉 4 个空壳：clip_0007 / 0008 / 0009 / 0010
真身映射：clip_0003←clip_0007  clip_0004←clip_0008  clip_0005←clip_0009  clip_0006←clip_0010
还原 chain.shot：1myflik→3qa59g0  dosexg9→u2bfwqy  31f2gxz→tir6ber  830a5u8→ncwgzq
新顺序（6 段）：clip_0001 … clip_0006
shot_uid 唯一索引已建立
```

复检结果：
```
shots 表 6 行 · shot_state 6 行 · meta.order 6 个
✓ 没有重复登记的空壳     ✓ 三处段数一致，库是干净的
```

### 验证

- `py_compile` 两个 py 全过；`node --check` 四个 js 全过。
- `store_selftest.py`：**PASS=53 FAIL=6，与改动前逐项一致**（已用 `git stash` 做过
  HEAD 对照，diff 只有时间戳/PID）。这 6 个是**测试脚本过时，产品代码是对的**：

  | 失败项 | 真实原因 |
  |---|---|
  | `旧目录已移走` / `新目录有 db` / `改名后 rack 还在` / `改名后 desk 还在` | 20261020「方案 G」把 `rename_chain` 改成**只改索引、目录一个字节都不动**（`moved: False`），测试还在断言「目录已搬」 |
  | `health 段数=3` | 跟着上一条，`S.health(dnew)` 传的是新名拼出来的**不存在**路径 |
  | `无 latent 加长拒绝 no_latent` | 20261013 主动**移除**了 `no_latent` 硬拒（误判使中间段永远加不了时长），改为标 `redo`；测试还在等 `refused` |

**待真机**：重启 ComfyUI（`user_version` 2→3）→ Ctrl+F5 → 时间轴应回到 6 段。

---

## 2026-10-25 方案A 暗病根治：段字段权威契约（SEG_KEY_OWNER）

**起因**：外部核查报告列出方案A（「中央库成为段数据唯一权威」）带来的 6 条暗病。
逐条核实后**全部成立**，且实测比报告更彻底。

### 为什么这是第 3 次

| 时间 | 症状 | 当时怎么修的 |
|---|---|---|
| 20261015 | 每段提示词全没了 | `desk_text` 为空时不覆盖 `state.prompt` |
| 20261023 | 别名开关关了却恒按开 | 把 `alias` 加进 `parse_h3_data` 白名单 |
| 20261025 | 别名开关**又**恒按开 | 方案A 整份替换把它抹掉 |

三次是**同一个病**：一个字段要在多处同步维护，漏一处就静默退化到默认值，
不报错、不打印、没人知道。前两次修的是「那一处」，所以第三次必然来。
**修字段没用，得修「让人漏不掉」。**

### 根因

方案A 用的是 `cfg = parse_h3_data(_state)` **整份替换**。库里只存「段内容」，
而 `alias` / `segFps` 是**提交侧独有**的字段 —— 整份替换等于把它们删掉，
删完再按「缺失 = 旧行为」兜底：

- `alias` 被删 → `None → True` → 别名恒按「开」处理（暗病 1）
- `seg_fps` 被删 → `_audit_seg_fps` 开头 `if not claim.get("word")` 早退 →
  对账**静默失效**，日志里再无 `rev_drift`（暗病 2）

实测佐证（扫描 `output/h3_chain/*/project.db` 全部工程）：

```
有 state 的段共 61 个
  缺 alias 键    ：61 / 61
  缺 segFps 键   ：61 / 61
  prompt 长度 0  ：61 / 61
  slots.images 长度一律 9，其中**有真实 file 的段数 = 0**
```

最后一条是本轮最关键的发现 —— 它否掉了「槽位归库权威」这个想当然的设计：
库里的槽位全是空槽，归 `db` 会把提交侧的真实参考图**全部清空**，比串台还糟。

### 根治：三层

**① 契约表 `csglide_cast.SEG_KEY_OWNER`（设计层）**

23 个返回键全部显式归类，三档：

| 档位 | 含义 | 字段 |
|---|---|---|
| `db` | 库里有**这个键**库就赢 | 几何/采样参数：mode、width、height、length、ref_*、bridge_* |
| `db_nonempty` | 库里**有值**才赢，空一律不覆盖 | 段内容：prompt、first、last、images、videos、audios、cont |
| `submit` | 库里根本没有，只认提交那份 | alias、seg_fps、producer、push_whole、chain |

**默认方向是反过来的**：以前「库里整份赢，漏的丢掉」；现在「提交默认赢，只有
表里写了 db 的才让库赢」。漏归类最坏退化成旧行为，**不会丢数据**。

配套两个细节：
- `_db_has_key()`：`db` 档位靠它判断。库里没这个键时 `parse_h3_data` 会填默认值
  （width 默认 1344），拿**默认值**覆盖提交侧真值 = 凭空改参数。键在，库才有发言权。
- `_is_set()`：槽位/续写类 dict 只看有没有 `file` / `latent_video`。
  光有 `{'mode':'latent'}` 这种元数据不算有值 —— 拿它覆盖会清掉提交侧的续写源。

**② 导入期校验 `_audit_field_contract()`**

模块加载时跑一次：`parse_h3_data({})` 的返回键必须与契约表**完全对齐**。
少一个、多一个都打印醒目告警。只打印**不拦出图**（契约违规是开发期的错，
不该让用户出不了图）；测试里是对它**硬断言**，跑测试必红。

**③ 字段矩阵回归 `templates/seg_field_matrix.py`（保障层）**

用例**从契约表自动生成**：每个字段 × (库有值 / 库为空 / 库无键)。加字段不归表 →
契约校验先炸；归了表 → 用例自动就有，不会漏测。

```
【1】契约完整性               3 条
【2】库为空 → 提交值全保住    23 条   ← 三次事故的共同断言
【3】库有值 → 按契约判谁赢    22 条
【4】暗病 1/2/3 硬回归         5 条
【5】身份 chain                5 条
【6】库空槽不清参考图          2 条
【7】媒体架接线高位清空        4 条
【8】真实工程库端到端          2 条
【9】负向：漏归类必须被抓到    3 条
PASS=68 FAIL=0
```

第【9】节是整套机制的**存在意义** —— 它证明了「忘了归表会被当场抓住」：

```
[H3 导演台] ⚠ 字段契约违规（段参数可能在某条路径上被静默丢弃）：
         未归类，必须补进 SEG_KEY_OWNER：['some_new_field']
```

### 其余三条

- **暗病 3（库里空词盖掉面板词）**：`prompt` 归 `db_nonempty`，库里空串不覆盖。
- **暗病 4（槽位高位残留）**：`merge_rack_refs` 接线范围外的高位清空。
  界线写进 docstring：已接线**范围内**的空槽由面板兜底，范围**之外**一律清空 ——
  原来那两句注释互相打架，现在不打架了。
- **暗病 5（原则注释对打）**：`_audit_seg_fps` 的 docstring 补全与方案A 的关系 ——
  段内容库赢、`seg_fps` 本身归提交，两者因此**不再矛盾**。
- **暗病 6（共用模式空转）**：⚠ **当时判为"仅注释、无害"，这个判断是错的**，
  20261025 晚已推翻并修复 —— 见下一节。后端退回镜像确实无害，但**提交层**
  （`bz_prompt_build.js`）在共用模式下会按「空素材」编译，参考图直接丢失。

### 验证

- `py_compile` / `node --check` 全过。
- 新增 `seg_field_matrix.py`：**PASS=68 FAIL=0**。
- `store_selftest.py`：**与改动前逐项一致**（PASS=53 FAIL=6，仍是那 6 个过时断言）。
- 未采纳「前端把 alias 落库」：A+C 已能保证「无论库里有不有，取值都对」，
  落库的收益只剩「库能自解释」，而它要改 3 个 js + 回填历史 + 引入跨模块耦合。
- **待真机**：重启 ComfyUI → 文案台关掉别名模式 → 裸写角色名应**不再**被换成
  `@图片N`；日志里应重新出现 `rev_drift` 对账行。

---

## 2026-10-25 修正「存档节点后面没有直接接 VAE 解码节点」报错文案

**起因**：别的用户报错「中断于第 1 段 · 已完成 0 段（存档节点后面没有直接接
VAE 解码节点…）」。核实后发现**渲染是成功的，失败的是收片**（`classify_run_media`
认不出本段成片），而文案本身有两处毛病：

1. **说「直接接」，实际不要求紧贴** —— `csglide_chain.py:610` 注释（20261021）
   明写「存档与解码之间常串『系统净化』这类透传节点，硬认直连会当场判定落空」。
   文案按"直接"理解，会让人把必要的透传节点拆掉，反而更坏。
2. **只喊"没接解码"，不说"实际接到了什么"** —— 用户还得反推是哪根线错了。

**改法（`csglide_chain.py` 的 `seg_err`）**

- 正确接法写成 `采样 → 存档 → 解码 → 视频合并`，并点明**存档必须在解码之前**
  （接在解码后面就没有解码可找了）—— 这是最常见的一种错法。
- 补一句「中间串『系统净化』这类透传节点不影响」，与代码实际行为对齐。
- **报出存档之后实际接到的节点**（按深度取前 6 个）：
  `存档之后实际接到：#343 系统净化。这些都不是解码节点，往上补一个 VAE 解码即可。`
- 输出口**完全悬空**时单独一句话（最常见的原因）：
  `存档节点的「潜空间」输出口没有任何连线 —— 把它接到 VAEDecode 的 samples 输入`
- 补上漏掉的 `H3 VAE 快速解码`（`DECODE_TYPES` 里本来就有 `BanZhang_H3VAEDecodeFast`，
  老文案没列）。

**顺带对齐同一链路上另两条文案**（原来也用「直连」，口径不一致）：
- `存档节点下游的 VAE 解码之后接了多个视频合并节点，无法盲收哪一个才是本段成片：…`
- `存档节点下游的 VAE 解码之后没找到视频合并节点 —— 本段成片还没有出口…`

**踩点**：报错文案里**不能写 markdown `**粗体**`** —— 结果行是纯文本，星号会原样显示。

**验证**：三种拓扑实测（`classify_run_media` 直接调用）：

| 拓扑 | 文案尾巴 |
|---|---|
| 存档下游悬空 | 「输出口没有任何连线 —— 把它接到 VAEDecode 的 samples 输入」 |
| 存档 → 放大节点 | 「存档之后实际接到：#3 BanZhang_MMH3_Upscale。这些都不是解码节点…」 |
| 存档 → 系统净化 → 解码 → 合并 | `segment_error` 为空（不误报） |

---

## 2026-10-25 修：媒体架「全片共用」模式下参考图全丢（暗病 6 反转）

**症状**（用户截图现场）：媒体架分区标题写着「参考图片 · **本段用 3**」，
导演台底部却同时报

> ⚠ 第 1 段引用的 @图片1、@图片2、@图片3 没有对应素材（本段媒体架槽位为空）；
> 第 1 段（clip_0001）…但工程里查不到这一段的媒体架记录 —— 已按空素材提交

**两边打架**：媒体架认为用了 3 张，提交层认为一张都没有。出图结果是没有参考图。

### 根因链（`js/csglide_cast_shots.js:410` 的 `rackSnapshot(cid)`）

```
媒体架「全片共用」(st.shared=true)
   → st.cur 是空串（共用模式没有"当前段"这个身份）
   → rackSnapshot 判 String(st.cur) !== keyCid  →  "" !== "clip_0001" 成立
   → 误判成"架面停在别的段"，只信段记忆 segMemSnap(rn, cid)
   → 共用模式没有按段的记忆（csglide_media_rack.js:158 写回时遍历
      Object.keys(st.segs)，那个表是空的时候一条都写不进去）
   → 返回 null
   → bz_prompt_build.js:568  rackSrc = "空" → rack = emptyRack()
   → sig 全空 → gaps 非空（两处警告）+ sent 的文件全空（参考图不发送）
```

**与「暗病 6」的关系**：上一轮把「共用模式下方案A 空转」判成「仅认知问题、无害」。
后端那段确实无害（退回镜像）；但**提交层不这么看** —— `rackSrc === "空"` 时它按
空素材编译，后端的"镜像"本身就是空的。判断只看了后端，没看提交层，是漏判。

**为什么媒体架自己显示"本段用 3"**：它走 `csglide_rack_refs.js` → `mergedSlots()`
直接读**当前架面 widget**，与提交层走的 `rackSnapshot(cid)` 是两条路。
两条路口径不一致，才出现"显示有、提交没有"。

### 修法

`rackSnapshot(cid)` 加两条：

```js
/* 全片共用：整片就一副架面，不存在"停在哪一段"，也没有按段记忆 ——
   架面此刻的 widget 就是所有段的权威，直接读它。 */
if (mst && mst.shared) return widgetSnap(rn) || segMemSnap(rn, keyCid);
/* cur 为空 = "还没停在任何段"，不是"停在别的段"，不存在串段风险 */
if (mst && mst.cur && String(mst.cur) !== keyCid) return segMemSnap(rn, keyCid);
```

第二行的 `mst.cur &&` 顺带修了另一处：**分段模式下媒体架还没切过段**
（`st.cur` 空、刚搭好工作流就渲染）时，原来也返回 null → 参考图丢。

20261013 那个串段修复（"架面停在别的段时只信段记忆"）**原样保留** ——
它的前提是 cur 有值且不等于目标段，这两条改动没有削弱它。

顺带：`bz_prompt_build.js:619` 的 `**空素材**` 去掉 markdown 星号（结果行是纯文本）。

### 验证

- `node --check` 两个文件通过。
- **待真机**（JS 改动，Ctrl+F5 即可，不用重启）：媒体架开「全片共用」→ 摆几张图
  → 点渲染 → ① 导演台底部**不再**出现「本段媒体架槽位为空 / 查不到媒体架记录」；
  ② 出图里能看到参考图。
- 回归：媒体架开**分段记忆**（关共用）→ 切段 → 每段仍只用自己的图（串段修复没被破坏）。

---

## 2026-10-25 19:20 🧹 前端自测收进 tests/（根目录 27 个 .mjs 清零）

### 起因

有人问「项目里一堆 `.mjs` 是不是备份文件、要不要删」。查下来**不是备份** ——
`.mjs` 只是让 node 按 ESM 解析的后缀，这 27 个全都被 git 正常跟踪，是自测脚本。
但堆在项目根确实是有问题的：跟 `csglide_*.py` 这些节点入口混在一起，分不清
哪些是运行时要加载的、哪些只是自测；而且每个脚本自己算临时文件路径，
跑完的中间产物也落在根目录。

### 体检：27 个里 3 个已经永久跑不动

逐个 `node` 跑，24 过 3 挂。挂的三个是**「改前 vs 改后对照」型**脚本，
靠 `.bak_*` 旧源码快照做基线，快照清理掉之后就再也跑不了（除非把旧源码挖回来）：

| 脚本 | 依赖的基线 |
|---|---|
| `_selftest_audvae.mjs` | `js/csglide_cast_meta.js.bak_audvae_20261021` |
| `_selftest_zone_rebuild.mjs` | `js/csglide_rack_cards.js.bak_zoneanchor_20261019` |
| `_bench_feeds.mjs` | `js/bz_rack.js.bak_feeds_20261020`（还要传 workflow.json 参数） |

这三个的价值在当时已经兑现（证明重构没改坏），基线没了就没有再跑的可能，删。

### 纠正一个误判：`_selftest_tmp_send_refs.mjs` 不是「调试变体」

45K 的 `_selftest_tmp_send_refs.mjs` 曾被我判断成「`_selftest_send_refs.mjs`
的调试用副本」，实际是**后者每次运行时生成、且从不清理的临时模块**：

```js
// tests/js/_selftest_send_refs.mjs:47 —— 把源码剥掉 import 落盘，再动态 import
const tmp = path.join(HERE, "_selftest_tmp_send_refs.mjs");
fs.writeFileSync(tmp, s, "utf8");
return import("file://" + tmp.replace(/\\/g, "/") + "?t=" + Date.now());
```

它就是这么被误提交进库的。已补 `process.on("exit")` 清理，并在 `.gitignore`
里加了 `tests/js/_selftest_tmp_*` 等规则 —— 同类产物不会再进版本库。

### 搬移：路径写法三套混杂，必须分组处理

脚本原来住项目根，定位源码有三种写法，搬进 `tests/js/` 后各自坏法不同：

| 组 | 数量 | 原写法 | 搬走后 | 修法 |
|---|---|---|---|---|
| A | 9 | `path.join(HERE, "js", ...)` | 指向 `tests/js/js` | 另立 `ROOT` 指向项目根，只把**读源码**的路径改走 ROOT；`HERE` 留给临时文件（顺手让中间产物跟着落到 `tests/js/`） |
| B | 10 | `readFileSync("js/xxx")`（CWD 相对） | CWD 不再必然是项目根 | `process.chdir(ROOT)` 钉住，**一条路径都不用改** |
| C | 3 | `import "./js/xxx.js"` | 按模块位置解析，必坏 | 改成 `"../../js/xxx.js"` |

- A 组注意 `HERE` 是双用途（读源码 + 写临时文件），不能整体替换
- B 组里 `_selftest_dirname_cross.mjs` 连 Python 侧的 `open("csglide_store.py")`
  和 `"../../../python_embeded/python.exe"` 都依赖 CWD，chdir 是唯一省事的解法
- 改完的验收标准不是「能跑」，而是**从任意 CWD 跑结果都一样**（已验证：从 `K:/` 跑 23/23）

### 新增 `tests/run_all.mjs`

- `node tests/run_all.mjs` 跑全部；带参数按文件名过滤；`--list` 只列清单
- 用例约定 `tests/js/_selftest_*.mjs`，靠退出码表达成败，**加用例不用改 runner**
- `_selftest_tmp_*` 是中间产物不是用例，显式排除（异常中断可能残留）
- 统一命名：`test_mount_rack.mjs` → `_selftest_mount_rack.mjs`（原来唯一不带前缀的）

### 顺带修的真实缺陷：清理失败会拖垮整个用例

`_selftest_modules.mjs:178` 的 `fs.rmSync(TMP, {recursive:true})` 是**裸调用**。
清理一旦失败（文件被占用、回收站策略、沙箱拦截），进程就崩在最后一行，
退出码变 1，**前面 24 项通过的断言全被埋掉**，看起来像"测试挂了"。
已包 try/catch 降级为警告 —— 清理是收尾，不该有否决权。

### 验证

- `node tests/run_all.mjs` → **23 通过 / 0 失败，2.7s**
- 从无关 CWD（`K:/`）再跑一遍 → 23 通过 / 0 失败
- 跑完 `tests/js/` 无残留（非 `.mjs` 文件数 = 0），项目根无新增垃圾

### 踩点

- **别把「运行时生成的临时文件」当成源码资产**：看到奇怪的 `_tmp_*` / `_selftest_tmp_*`，
  先 grep 谁 `writeFileSync` 了它，再判断能不能删
- `git rm` 遇到 `local modifications` 要先看 diff —— 那可能是自己上次的修复（本次
  就是昨天去 `**空素材**` 星号时同步改到了这个副本上），确认主文件已含该修复才 `-f`
- 搬脚本前必须查三件事：路径是 CWD 相对 / 模块相对 / 自己目录相对，三种修法完全不同

## 2026-10-25 🎯 SelfLift 多级渐进瘦身 + 💾 显存优化收敛到「无损」

### 为什么砍掉 global 系
「🧠 H3 SLA 注意力加速」用 `set_model_patch_replace(..., "dit", "double_block", i)`
把块级补丁写进 `model_options["transformer_options"]["patches_replace"]`
（`sla/patch.py:799`，落点见 `comfy/model_patcher.py:97-111`）。
官方 global 系在 `tiled_model()` 第一步就校验这些块补丁必须是
`nodes_sparse_attention.py` 里的 `make_h3_block_patch.<locals>.block_patch`
（`_selflift_avatar/h3_global_tiling.py:139-142, 382`），
而 SLA 的是 `sla/patch.py` 里的 `_make_h3_block_patch.<locals>.attention`（同文件 700-707）
→ 校验不过，`h3_global_tiling.py:176-177` 直接 `raise ValueError("unsupported H3 block patch")`。

本机 `comfy_kitchen` 可导入、`comfy/ldm/minimax/model.py:476` 有 `MiniMaxH3Model`
→ SLA 必然走块级替换 → **global / global_stream / global_ram 只要链上有 SLA 就报错**。

正面结论：注意力那层交 SLA，前馈那层交显存优化（`selflift/h3_mem.py:108` 有注释
说明它走 `optimized_attention`，`optimized_attention_override` 补丁照常生效），
两层各管一半、互不打架，效果接近 global，还不冲突。

### 多级渐进（`banzhang_selflift.py`）
- 删 4 个参数：`省显存模式` `token分块大小` `权重缓存预算` `高分辨率阶段模型`
- 删掉整段运行时 `guider.model_patcher` 替换逻辑（换模型 + global 包装都靠它），
  `_SelfLiftMultiStage.__init__` 同步去掉 `hires_model / tiling_mode / token_chunk /
  weight_cache_gb / _global_patcher / _global_cache`
- 分块条件从 `spatial 且 h>=H` 简化为 `h>=H`（只剩一条路线）
- 剩 5 个控件：`分段步数 / 级间倍率 / latent放大模型 / 满分辨率分块 / 彩色光点清理力度`

**关键收益**：这 5 个正好等于老工作流 `['2,2','1.5',model,'自动',9]` 的位置，
`minimax h3-三采-1021.json` 这类文件**不用重挑参数，重载即用**。

### 💾 H3 显存优化
档位从 6 档压到 4 档，只留无损路线（每项 = 前馈分块/分块触发长度/注意力头分组）：
```
① 关   (1, 4096, 1)
② 轻度 (2, 4096, 4)
③ 强力 (4, 4096, 8)     ← 原来是 global，改成把无损补丁调狠
④ 自定义
```
删掉 `省显存模式 / token分块大小 / 权重缓存预算` 三个控件和 `_MEM_MODES` 映射；
`_resolve_mem_preset` 签名改为 4 个参数、返回 3 元组，脏档位仍退回「① 关」+ 警告。
`js/banzhang_mem_optimizer.js` 同步：只隐藏 3 个细项，自定义项改名「④ 自定义」。

### 验证
- `python -m py_compile banzhang_selflift.py` 通过；`node --check js/banzhang_mem_optimizer.js` 通过
- 整包 import 成功（输出「所有节点已准备就绪」）
- 实际打印控件顺序：多级渐进 5 项、显存优化 4 项，与预期一致
- 档位解析实测：①②③ 各自返回预期三元组，脏值 `9` → `(1, 4096, 1)` + 警告
- **待真机**：重启 ComfyUI + Ctrl+F5，重载 `minimax h3-三采-1021.json` 直接出图；
  显存优化选 ①②③ 时下面 3 个细项应消失，选 ④ 才出现

## 2026-10-25 SelfLift 系列节点「说明文字」压到 50 字内

节点上那块说明（`DESCRIPTION`）原本最长 905 字，新人根本不会读。全部压成一句话，
干货（音频遮罩口径、分块要 keyframe 同网格、6G 启动参数）本来就在各参数 tooltip 里，没丢。

| 节点 | 原字数 | 现字数 |
|---|---|---|
| 🎯 SelfLift 渐进提升 | 647 | 39 |
| 🎯 SelfLift 多级渐进 | 905 | 38 |
| 🎯 H3 放大采样器 | 208 | 42 |
| 💾 H3 显存优化 | 492 | 35 |

顺带修掉「级间倍率」tooltip 里那句错的：原写「填 < 1 可以大网格定结构省算力」，
实际 `scales[i] = scales[i+1] / ratio[i]`，ratio<1 时首段比最终画布还大
（0.6 三段 = 2.78 倍面积 7.7 倍），纯烧显存。已改成明确的警告。

备份：`banzhang_selflift.py.bak_desc_20261025`（整轮说明文字改动前的状态）。

---

## 2026-10-26 07:25 📐 成片监视器：竖屏视频把预览框撑大

### 现象

导演台生成 9:16 竖屏成片后，监视器预览框被撑高，整个节点跟着往下长，
下方全宽时间轴被顶走。

### 根因：`aspect-ratio` 定高没有上限

`js/csglide_film.js` 的取景器规则（20261011 为消黑边而改成 aspect-ratio）：

```css
.bzf-view { width: 100%; aspect-ratio: var(--bzf-ar, 16 / 9); flex: 0 0 auto; }
```

- `--bzf-ar` 由 `loadedmetadata` 按真实分辨率写入（`csglide_film.js:4224`）
- 高度 = **宽度 × 高宽比**，而宽度恒为 100%
- 监视器容器 `.gcast-monitor { flex:0 0 auto; min-height:300px }`（`csglide_cast.css.js:56`）
  **只有下限没有上限**

于是：竖屏 9:16、监视器宽 360px → 取景器算 640px 高 → 顶穿 300px 下限 →
监视器、双栏、节点高度（推导值）依次被顶高。
横屏 16:9 算出来才 202px，永远碰不到这条线，所以一直没暴露。

20261011 那条改动的注释写着「监视器高度跟随视频」——**它默认视频是横屏的**。

### 修法（方案一：限高）

`js/csglide_film.js` `.bzf-view` 加一条 `max-height: 420px`。

**为什么是 420**：这是「只拦竖屏极端值」的量级。
横屏 16:9 要监视器宽到 750px 才够得着 420；常规节点宽（900 内 → 监视器约 440
→ 横屏 248）碰不到，横屏观感不变。竖屏 640 → 420，节点少长 220px。

超限后视频按 contain 居中，左右留黑边 —— 横长的框里放竖视频，黑边是必然的。

### 已知代价（方案一固有，不是 bug）

1. **`max-height` 是全局钳制，不区分朝向**。把节点拉到特别宽（监视器 > 750px）时，
   横屏视频也会被钳到 420 并出现上下黑边。要彻底避免只能走「竖屏单独走高度优先」
   （给 `loadedmetadata` 打 `bzf-portrait` 类，CSS 里只对竖屏生效），代价是多一条分支。
2. **浮窗模式没根治**：浮窗固定 660×520，竖屏取景器原来是 660×16/9=1173px，
   现在钳到 420，溢出大幅减少但仍可能顶到 520 边界。

### 验证

- `node --check`（按 .mjs 拷出来验，ES module）通过
- `node tests/run_all.mjs` → 23 通过 / 0 失败（含读 `csglide_film.js` 的 strip_geom 41 项）
- **待真机**（纯 CSS 改动，Ctrl+F5 即可，不用重启）：生成一段 9:16 → 节点不再往下长、
  时间轴没被顶走、取景器是居中的竖屏画面；再放一段 16:9 → 仍和原来一样贴边无黑边
- 还原：`cp js/csglide_film.js.bak_vportrait_20261026 js/csglide_film.js` + Ctrl+F5

---

## 2026-10-26 07:33 🔧 首帧图进画布：拉伸改居中裁切（与末帧同口径）

### 现象

首尾帧（fl2va）模式，画布设横版、首帧放竖图 → 首帧被**拉伸**成横版比例，
人脸/构图变形。同时面板上「图片参考 · 跟随画布」是灰的，用户以为是
「功能被锁住，所以只能被拉伸」。

### 根因：同一个函数、相邻两行，口径相反

`csglide_cast.py` 的 fl2va 分支：

```python
img = _resize(first[:1], width, height, "disabled")   # geometry anchor: stretch
...
img = _resize(last[:1], width, height, "center")      # follower: cover-crop
```

`comfy.utils.common_upscale` 的最后一个参数：`"disabled"` = 直接拉伸，
`"center"` = 等比缩放后中心裁切。

首帧用拉伸，注释给的理由是「首帧是几何锚点」。**这个理由不成立** ——
`center` 裁切输出的尺寸同样是 `width × height`，一样能当锚点。
原设计默认了「锚点必须保内容完整」，代价是变形，且与紧邻的末帧相反。

### 关于「跟随画布被锁」

`js/csglide_cast_view.js:199` 在 fl2va 下把「图片参考 / 视频参考」两行置灰
（`opacity .35` + `pointerEvents:none`）。这是对的 —— fl2va 只用 `@first`/`@last`，
没有 `@图片N`，那套「参考图编码长边」参数确实不生效。

**但它管的是参考素材编码，根本不管首帧图**。首帧走的是另一条路（直接 resize
到画布宽高）。所以解锁它也治不了拉伸 —— 这点必须写在界面上，否则必被误解。

### 改动

1. `csglide_cast.py`：首帧 `"disabled"` → `"center"`，与末帧统一
2. `csglide_cast.py`：日志文案「拉伸对齐画布」→「居中裁切，只保留画面中间部分」，
   提示语改成「想要保住完整构图，请把画布设成图片的比例」
   （原来提示「先把图裁成画布比例」—— 那是给拉伸场景写的，改成裁切后口径反了）
3. `js/csglide_cast_settings.js`：把 `field()` 里的 label 元素导出（`refLabel` / `vrefLabel`）
4. `js/csglide_cast_view.js`：fl2va 下 label 变成「图片参考 · 本模式不用」/
   「视频参考 · 本模式不用」，让「为什么灰」当场可见

### 代价（必须让用户知道）

竖图 1080×1920 放进横版画布 1344×768，裁切会保留原图约 **32% 的高度**（中间部分）。
想保住完整构图，正解是把画布设成图片的比例（9:16），而不是调适配方式。

### 验证

- `py_compile csglide_cast.py` 通过；`node --check` 两个 js 通过；`tests/run_all.mjs` 23/23
- **待真机**（改了 `.py` 必须完全重启 ComfyUI）：首尾帧模式放 1080×1920 竖图、
  画布横版 → 日志应是「按居中裁切」、人脸不变形；放 16:9 横图应与以前完全一致
- 还原：`cp csglide_cast.py.bak_firstcrop_20261026 csglide_cast.py` + 重启

---

## 2026-10-26 07:42 🔧 误报根治：@first 不该被当成媒体架引用

### 现象

首尾帧模式，首帧图从**导演台首帧端口**正常送入、提示词写 `@first`，
底部却报：

> 第 1 段（clip_0001）提示词引用了 @first，但工程里查不到这一段的媒体架记录
> —— 已按空素材提交（不再退回画布上别的段）

**这条是误报**，而且极具误导性：它会让人以为首帧根本没送进去（我自己就被
它带偏过一次，去查「首帧槽位是不是空的」，白跑一轮）。

### 根因：REF_RE 把 @first/@last 也算成"引用"

`js/bz_prompt_build.js`：

```js
const REF_RE = /@(first|last|图片\d+|视频音频\d+|视频\d+|音频\d+)/g;
...
const refs = refsOf(resolvedWords);          // refs 里含 "first"
if (rackSrc === "空" && refs.length) {       // ← 于是必然成立
  warnings.push(`...提示词引用了 @first，但工程里查不到这一段的媒体架记录...`);
}
```

`@first`/`@last` 走的是导演台的**首尾帧端口/槽位**，跟媒体架没有任何关系。
把它们和 `@图片N` 一起丢进"媒体架记录查不到"的判定，只要媒体架是空的
（fl2va 本来就不用媒体架）就必然误报。

### 修法

```js
/* @first / @last 走首尾帧端口，与媒体架无关 —— 不能拿它们触发这条判定 */
const rackRefs = refs.filter((r) => r !== "first" && r !== "last");
if (rackSrc === "空" && rackRefs.length) {
  // 首尾帧模式写了 @图片N 是模式用错，直接指向 @first；否则维持原说法
  warnings.push(state.mode === "fl2va" ? "...只认 @first 和 @last..." : "...查不到媒体架记录...");
}
```

顺带把 fl2va 下 `@图片N` 的文案改准：不是"媒体架里找不到记录"，而是
**「这个模式不认 @图片N，该写 @first」**——原来说法会让人去媒体架里白找。

### 不影响的地方（已核对）

- `refGaps()` 只按 `@图片N/@视频N/@音频N` 正则匹配，first/last 天然跳过 ✓
- `unresolvedRefsIn()` 开头就有 `BUILTIN_ALIAS.test(nm) → continue`，本来就不报 ✓

只有 `rackSrc === "空"` 这一处漏了。

### 测试：第一版断言是恒真的，靠负向验证才发现

新增 `tests/js/_selftest_prompt_build.mjs`【2b】两条用例。第一版断言写的是
「不含『查不到这一段的媒体架记录』」——**这条在修好之后恒真**，因为 fl2va
分支改走新文案、根本不会产生那句老话。把修复注回去（`rackRefs = refs`）
测试照样全绿，等于什么都没测。

改成「一条媒体架空警告都不该有」（`warnings.length === 0`）之后，
负向验证才真的变红，而且暴露出的误报文案自相矛盾：

> 提示词里写了 **@first**，但本段是「首/尾帧」模式 —— 这个模式只认 @first 和
> @last，**@first** 不会被当成参考图

**踩点**：负向测试（把 bug 注回去）是唯一能证明"断言真的在测东西"的手段。
正向全绿只能证明"现在没报错"，证明不了"它能抓到错"。另外造用例时要注意
`deskSegs` 必须给 —— 接了文案台时 effWords 取的是文案台的词，不给就是空串，
`refs` 为空会直接跳过告警分支，断言"空数组恒真"式假通过。

### 验证

- `node --check` 通过
- `node tests/js/_selftest_prompt_build.mjs` → **86 通过 / 0 失败**
- 负向：注入 `rackRefs = refs` → 【2b】第一条变红（85/1），确认断言有效
- `node tests/run_all.mjs` → 23 通过 / 0 失败
- 纯 JS 改动：Ctrl+F5 即可，不用重启

---

## 2026-10-26 07:54 🎯 SLA 注意力：三个默认值与 tooltip 全部错配（花屏嫌疑）

### 现象

首尾帧模式、480×832、15 秒 362 帧，生成结果每隔几秒崩一段花屏，
**有时出现有时不出现**。用户怀疑是显存优化引起的。

### 排查：先排除显存优化

1. `selflift/h3_mem.py` 逐个核对：
   - 前馈分块按 token 维切，每 token 独立 → 数学逐位等价
   - 注意力头分组按头切，头间独立 → 同样逐位等价
   - 特别核对了分组里的 `out = torch.empty(...)`（未初始化内存、靠循环填满）：
     各组 size 之和 = heads，切片覆盖完整，没有留空区域
2. 用户工作流里**没有**「💾 H3 显存优化」节点
3. `ComfyUI/user/default/comfy.settings.json` 共 78 项，**0 项**跟显存/分块相关
4. 启动脚本只用了 `--windows-standalone-build --max-upload-size 4096`，
   没开 `--lowvram` 之类

结论：显存优化这条线嫌疑明显低。

### 真正的嫌疑：SLA 稀疏注意力

工作流里挂了「🧠 H3 SLA 注意力加速」（截图能看到它的「计算块大小 64」）。
`banzhang_sla_attention.py` 里三个参数的**代码默认值与 tooltip 声称的默认值完全不同**：

| 参数 | 代码 default | tooltip 声称 |
|---|---|---|
| 省多少计算 | **95** | 「90（默认）：和 ComfyUI 官方节点的默认档一致」 |
| 开头几步不省 | **0** | 「1（默认）：第 1 步完整算」 |
| 最后几步精修 | **0** | 「1（默认）：最后一步完整算」 |

`省多少计算 = 95` → `sparsity_ratio = 0.95`，**只保留 5% 的注意力计算**；
开头结尾都是 0 表示**全程没有任何一步走完整计算**。它自己的 tooltip 里就写着
「95：最快，**只在赶时间时用**」。

两个特征吻合：
- **每几秒一次**：块大小 64，每块对应固定时间跨度 → 崩坏呈周期性
- **有时有有时没有**：稀疏选择是按注意力分数做 top-k、**依赖数据**，每次丢的块不同

更要紧的是用户只放首帧：tooltip 自己写着「开头这几步决定整个画面的构图和人物长相」，
`开头几步不省 = 0` 等于第一步就开始丢 95% 注意力，首帧锚点很可能没被正确看到。

### 修法

把三个 default 改成与 tooltip 一致（90 / 1 / 1），并同步 `apply_sla` 签名默认值
（这个文件里 `保住声音` 的注释就记着「曾出现界面 False / 签名 True 的错配」，
所以两处必须一起改）。同时在 `INPUT_TYPES` 上方写下「默认值必须与 tooltip 逐字一致」
的约束和本次根因，防止再被改回去。

**改默认值不影响已保存的工作流**（工作流存的是实际值），只影响新拖出来的节点。

### 状态：花屏尚未实测确认

本次只修了「默认值与文案错配」这个**确定存在**的缺陷。花屏的直接原因仍需实测：

- 把 SLA 的「省多少计算」改成 **0**（等于关掉它）重跑同一工程 →
  花屏消失则确认为 SLA；仍在则排除 SLA，从采样链路继续查
- 若确认，再按 0 → 90 → 85 上调，并给 `开头几步不省` 留 1~2

### 验证

- `py_compile banzhang_sla_attention.py` 通过
- 六处已核对一致：三个 `"default"` + 三个签名默认值
- 备份：`banzhang_sla_attention.py.bak_sladefault_20261026`
- 改了 `.py`：需完全重启 ComfyUI

## 2026-10-26 🎬 H3 终极放大：时间分块的两个帧数改成 17 步进 + 补吸附日志

**问题**：`每块帧数` / `重叠帧数` 是 `step:1` 的自由整数，但 H3 时间轴只认 `5+17k`
帧（`_h3_temporal_windows`，从 `_steps_for_frames` 推出来的硬约束）。
用户填 30，运行时被 `min(legal, key=abs)` 静默改成 22，**而且一行日志都没有**。

**改法**：
1. 两个 INT 控件 `"step": 1` → `"step": 17`（`min: 5` 不变）→ 箭头步进天然落在
   `5 / 22 / 39 / 56 / 73 / 90…` 上。默认值 73、22 本来合法，老存档不受影响。
2. `_h3_temporal_windows` 返回前打一行：
   `[H3时间分块] 块长 73 帧 / 重叠 22 帧 / 共 14 块`
   被吸附时追加 `（已吸附到 5+17k 合法档位：块长 30→22，重叠 18→5）`。

**实测**（`total_t=211`，对应 719 帧）：
- `73/22` → 14 块，overlap_t=7，无吸附提示
- `30/18` → 吸附成 `22/5`，42 块，提示正确列出两个改动
- `90/39` → 14 块，overlap_t=12

备份：`banzhang_mmh3_upscale.py.bak_snap_20261026`。

## 2026-10-26 🎬 H3 终极放大：时间分块的花屏 —— 音频没锁（借导演台方案）

### 根因
`_sample_temporal_windows` 只给**视频**造锁定掩码（`_temporal_clean_mask` →
`[1,1,T,1,1]`）。ComfyUI 收到单个 mask 时会给缺失的流补一张全 1
（`comfy/samplers.py:1297-1305`），于是**音频在重叠段被每块重新生成一遍**。
H3 是音视频联合注意力，音频不一致会反向拉扯画面 → 偶发花屏（"有时有有时没有"
= 取决于当次噪声）。

导演台早有同款解法：`banzhang_h3_pin.build_pin_mask(..., keep_audio=True)`
一次造两条 mask，并按 `round(i/T*at)` 把帧号比例映射到声音格。

### 改法（`banzhang_mmh3_upscale.py`）
1. 新增 `_temporal_lock_masks(video, audio, lock_steps, a_lock, device)`：
   视频 `[1,1,T,1,1]` + 音频 `[B,1,L]`，包成 `NestedTensor`。音频通道维必须 1
   （`banzhang_h3_pin.py:245`：给 C 会被 `reshape_mask` 的三线性插值平均掉）。
2. 新增 `_mask_to(mask, device)`：NestedTensor 没有 `.to`，逐流搬。
   `_sample_spatial_tiled` 原先的 `time_mask.to(device)` 换成它。
3. **自检**（`_temporal_lock_masks` 内）：零的个数必须正好等于锁定步数/格数，
   不等直接抛 —— 通道维一旦被改回 C，这里立刻翻倍报错，不用等真机跑完才发现。
4. **花屏的第二条防线**：`v_in[:, :, :lock] = prev_out[...]` 前加断言
   `prev_out.shape[2] >= lock`。钉住只是"别改这几步"，内容写不进去就会停在
   未采样 latent 上、解码成红褐编织纹（`csglide_cast.py:2418` 记的同款坑）。
5. 空间分块路径：只取视频那一路，并**明确打印**"音频锁定不生效"
   （音频不参与空间切块，要锁得改 `synchronized_euler` 的 model_conds 注入，未做）。
6. 每段日志加上音频锁格数：`（锁定 12 步 / 核心 15 步 / 音频锁 12 格）`。

### 离线实测
`v=[1,8,22,6,6] a=[1,4,40] lock=7 a_lock=12` →
视频掩码 `(1,1,22,1,1)` 零 7 步、音频掩码 `(1,1,40)` 零 12 格、`_mask_to` 后仍嵌套。

### 待真机
重启 + Ctrl+F5 → 跑带时间分块的工程 → 控制台看 `音频锁 N 格` 是否非 0；
花屏若消失即确认为此因。备份 `banzhang_mmh3_upscale.py.bak_audiolock_20261026`。

### 修正：自检判据写太死（2026-10-26 真机第一次跑就炸）

真机报：`视频锁了 12 步（应为 12）、音频锁了 130 格（应为 65）` —— 130 = 65×2。
说明**音频 latent 不是 [B,C,T]，多了一维**（最可能是立体声通道 / `[B,C,2,T]`）。
我按"零元素个数 == 锁定格数"写判据，只要音频多一维就必然翻倍，属于**判据错**，不是数据错。

改成语义判据 + 形状守卫：
- 通道维必须 = 1（这才是真正会被 `reshape_mask` 三线性插值平均掉的坑）
- 视频：前 n 步全 0、其余全 1
- 音频：尾轴前 n 格全 0、其余全 1（尾轴就是时间轴，`audio_total = audio.shape[-1]` 已证明）
- 另加一行 `[H3时间] 视频 latent (...) / 音频 latent (...)`，下次出问题直接看形状

三种候选形状离线验证全过：`(1,4,130)` / `(1,1,2,130)` / `(2,4,130)`。

## 2026-10-26 🎥 视频合并节点「方案1」修复（失败假绿 / 时长定格 / 格式失效 / 内存）

备份 `banzhang_video_tools.py.bak_方案1_20261026`。自测脚本 `_selftest_out/selftest_fangan1.py`（A~E 五例，可复跑）。

### 改了什么（单文件 8 处）
| 问题 | 改法 |
|---|---|
| 编码失败返回正常结构 → 节点绿、下游拿 None 继续跑 | 三条失败路径全部 `raise`（ffmpeg 全档失败 / PyAV 异常 / 最外层兜底），详情仍 print 到终端 |
| 音频比画面长时末帧定格 | 编码命令加 `-t 帧数/帧率` 硬锁输出时长（实测 48帧@24fps → 容器 2.000s、48 帧不丢） |
| 接「🎬 视频文件」时「📼 视频格式」被当空气 | 同族容器 mp4/mov/mkv 用流复制换壳（`-c copy`，零损）；跨族（GIF/WEBP/ProRes）保持源格式并在详情面板黄字说明 |
| GIF/WEBP 把所有帧堆成 PIL 对象（千帧 4K≈25GB） | 改生成器惰性喂帧，常驻只有原始张量 + 当前一帧 |
| GIF 延迟整数截断漂移（41ms 被吞成 40ms） | 按累计时间反推、以 10ms 为格量化，48 帧总时长精确 2.000s |
| 降级换档后进度条卡在半路 | 每档开始 `pbar.update(-pbar.value)` 归零重爬，且所有档位都推进度 |
| `IS_CHANGED` 里的调试 print | 删除（NaN 逻辑保留） |
| 编码器提前退出时报「Broken pipe」掩盖真因 | 先 kill+wait 子进程，再读 stderr 文件作为主错误（现能显示 `Unknown encoder`） |

### 未做（方案2/3 范围）
- `_combine_impl` 446 行、3 份编号 while 循环重复 → 待拆
- 「🎬 视频透传」端口声明 VIDEO 实际返回字符串，接原生 SaveVideo/PreviewVideo 会崩 → 需用户确认下游占用后再动端口
- 奇数宽高只裁不填、>2 声道只取前两路、`_strip_view_ds` 原地改 `extra_pnginfo`、自定义路径上报 `type:"output"`

### 行为变更（用户可感知）
1. 编码失败现在**红框报错并中断工作流**，不再假绿；详情面板停在上一版预览，看红框。
2. 接「🎬 视频文件」时选 MKV/MOV 会真的换容器；选 GIF/WEBP/ProRes 会得到源格式 + 黄字提示。
3. GIF 动图时长现在与详情面板一致。

## 2026-10-26 🎥 视频合并「方案2」拆分（447 行巨型函数 → 18 个职责函数）

备份 `banzhang_video_tools.py.bak_方案2前_20261026`。等价性验证：`_selftest_out/baseline_combine.py`
（record 采基线 / compare 比对，mp4·gif·png 字节级一致，mkv 容器 UID 随机故只比大小）。
行为验证：`_selftest_out/selftest_fangan1.py` A~I 九例。

### 拆分结果（`_combine_impl` 447 → 38 行）
| 函数 | 行数 | 职责 |
|---|---|---|
| `_combine_impl` | 38 | 只做 4 路分派：成品直采 / 单图存 PNG / 编码 / 无输入报错 |
| `_读参数` | 30 | 一次读全输入进 ctx，后续不再各自 kwargs.get |
| `_读尺寸` | 11 | 取 n_frames/h/w + 偶数化（VIDEO 分支不碰图像张量） |
| `_next_path` | 14 | 全节点唯一编号器（原 3 份 while 合一） |
| `_响提示音` | 4 | 原两处重复判断合一 |
| `_出口成品直采` | 10 | 视频采用 + 三路透传 |
| `_出口编码` | 27 | 编码唯一装配点 |
| `_准备输出` | 29 | 目录/文件名/进度条 |
| `_存动图首帧元数据` | 19 | GIF 首帧 PNG 载体 |
| `_准备音频` | 26 | PCM + 截断预警 |
| `_准备容器元数据` | 11 | prompt/workflow |
| `_编码前预检` | 22 | 清缓存 + 磁盘预检 |
| `_编码视频` | 65 | ffmpeg 主路径 |
| `_抢救碎片` | 19 | 全档失败时保留成品 |
| `_收尾容器` | 25 | remux + 嵌元数据 |
| `_编码视频回退` | 107 | PyAV 线性 API，不拆（拆开要传 6 个参数） |
| `_编码动图` | 33 | GIF/WEBP 生成器 |
| `_出片报告` | 25 | 详情面板文本 |

### 顺带消掉的
- `frames_written` / `error_occurred` 两个只写不读的变量
- 编码失败丢音频、异常保留音频的两套透传 → 统一 raise，透传不再有意义
- 3 份编号 while（`_adopt_existing` 闭包 `_pick` / `_save_images` / 编码分支）→ `_next_path`

### 保留的死代码（报告不删）
`_编码视频回退` 末尾的元数据嵌入段：守卫含 `HAS_VIDEO`，而该分支只在 `HAS_VIDEO=False` 时进入，永不执行。
保留是因为守卫条件对应「ffmpeg 检测逻辑若变更」的场景，已加注释说明。

### 等价性证据
重构前后同一输入（固定种子）跑 mp4+音频 / gif / png / 视频采用换壳四例：
- mp4、gif、png 输出 **md5 完全相同**
- mkv 因容器 Segment UID 随机，md5 不同但字节数完全相同
- 详情报告数值行完全一致

## 2026-10-26 🎥 视频合并「方案3」加一路兼容输出

**本次只加不删，无独立备份**（回退见文末）。前 3 路输出位置、类型、含义一律未动。

### 改动（4 处 + 1 个 import + 1 个工具方法）
| 位置 | 内容 |
|---|---|
| 模块顶部 | `from comfy_api.latest import VideoFromFile as _VideoFromFile`，失败置 None（老版本 ComfyUI 不影响启动） |
| 类属性 | `RETURN_TYPES` 末尾加 `"VIDEO"`、`RETURN_NAMES` 末尾加 `"📹 视频对象"` |
| `_包视频对象()` | 新工具：路径 → `VideoFromFile`，只存路径不解码；失败返回 None |
| `_出口编码` / `_出口成品直采` / `_save_images` | result 元组从 3 项扩到 4 项 |

### 两路的分工（关键认知）
- `🎬 视频透传`（第 2 路，VIDEO 类型但值其实是字符串）：**旧工作流全接在这**，本包下游
  （插帧 / 超分 / 视频合并）认「文件路径型」，保持不动。
- `📹 视频对象`（第 4 路，真 `VideoFromFile`）：给官方 `SaveVideo` / `PreviewVideo` 用。
  基类是 `VideoInput`，与 `io.Video.Input` 同源，官方节点收得了。

### 验证
- `J`：返回 4 路，第 2 路 `str` 保持、第 4 路 `VideoFromFile`；`get_dimensions()` 读到 (320,240)，
  `get_stream_source()` 指向真文件，MRO 第二层是 `VideoInput`。
- `J2`：图片模式第 4 路为 None（避免下游拿到上一轮对象）。
- `A~I` 九项行为、出片字节等价性（baseline compare）全部保持通过。
- 前端 `js/painter_video.js` 不引用 `outputs` 数组，多一路不影响面板高度与布局。

### 回退
删掉上表 3 处 return 的第 4 项、`RETURN_TYPES/NAMES` 的第 4 项、`_包视频对象` 方法与顶部 import 即可，
不影响方案 1/2 的任何修复。

### 2026-10-26 修正：第 4 路其实通吃，比第 2 路兼容面更广（原判断有误）

原以为「第 2 路给本包下游、第 4 路给官方节点」，实测推翻了这个分法。

| 下游节点 | 解析方式 | 接第 2 路(字符串) | 接第 4 路(对象) |
|---|---|---|---|
| 🎥 视频合并 `🎬 视频文件` | `_resolve_video_path` 认 `get_stream_source` | ✅ | ✅ |
| RIFE 插帧 | `resolve_video_path`（dlss5_fg_media 里的公共函数） | ✅ | ✅ |
| NVIDIA VFX | `resolve_video_path` + `get_components` 兜底 | ✅ | ✅ |
| DLSS5 补帧 | `video.get_components()` | ❌ `str` 没这方法，直接崩 | ✅ |
| 分辨率 `输入视频流` | `输入视频流.get_components()` | ❌ 同上 | ✅ |
| FlashVSR | 只有 VIDEO 输出，没有 VIDEO 输入 | — | — |

实测（自测 K）：`obj.get_components()` 拿到 `(6,240,320,3)` + 24fps；
`node._resolve_video_path(obj)` 拿到真路径；对照 `hasattr(第2路, "get_components") == False`。

**结论**：第 4 路能接全部下游；第 2 路存在的唯一理由是旧工作流的连线已经在上面。

**代价差异**：`get_components()` 会把整片解码成张量占内存（6 帧 320x240 → (6,240,320,3)）。
所以接路径型节点（合并/RIFE/VFX）用第 2 路更省；接组件型节点（DLSS5/分辨率）必须用第 4 路。

### 2026-10-26 单路化：删掉字符串版，对象顶上第 2 位

备份 `banzhang_video_tools.py.bak_单路输出前_20261026`（4 路并存那一版）。

**端口**：`("IMAGE","VIDEO","AUDIO")` / `("🖼️ 图像透传","📹 视频对象","🎵 音频透传")`。
第 2 位位置没变 —— 旧工作流连在 `🎬 视频透传` 上的线直接落到新的 `📹 视频对象` 上，不用重连。

**语义变更（要记住）**：第 2 路不再「透传上游原件」，而是指向**本次产出的成品**。
直采分支原来是 `ctx["video_src"]`（上游给什么回什么），现在是刚落盘的复制/换壳结果。
理由：这根线本来就该代表「本节点产出的片子」。

**兜底**：`_包视频对象` 在 `VideoFromFile` 缺失或构造失败时**退回文件路径字符串**（换型前的旧形态）。
路径型下游照常能用，比返回 None 让整条链断掉强。

**旧工作流风险评估**：
- 接本包路径型节点（视频合并 / RIFE / NVIDIA VFX）→ 对象走 `get_stream_source`，正常。
- 接本包组件型节点（DLSS5 / 分辨率）→ 原来接字符串会崩，现在反而好了。
- 接**本包之外**只认字符串的自定义节点 → 会崩，需要用户自行改连或让我加回字符串路。

**验证**：A~K 全过（J 第 2 路 `VideoFromFile`、J2 图片模式为 None、
K 路径型解析 True + 组件型拿到 `(6,240,320,3)`；H 第 2 路指向 `双接_N000_0001.mp4` 而非上游 src.mp4）；
出片字节等价性保持。

## 2026-10-26 🎥 Alt 复制节点缩小（第三次修复无效 → 停止猜测，抄真值）

**现象**：按住 Alt 拖拽复制「视频合并」节点，新节点突然缩小一半。

**三次无效的猜测（都在猜哪个分量被改小）**：
1. `info.size` 空 → 想按存档宽度写回 —— 日志证明 `info.size` 是 `Array(2)`，且宽度 496 从未被改小（rAF 时无写回日志）→ **宽度不是问题，缩的是高度**。
2. `properties.bz_node_w` 持久化宽度 —— 无效（宽度本来就对）。
3. 详情面板字段数被空文本清零 → 双写 properties —— 无效（用户反馈"还是不行"）。

**根因重定义**：不再定位"哪个分量坏"，改用事实约束——**复制不改变内容，内容相同尺寸就该相同**。
Alt 拖拽走 `LGraphCanvas.cloneNodes → node.clone() → configure()`；副本的实例状态
（`_painter_field_count` / `_painter_info_h` / `_bz_winset` 等）一律为 undefined，
推导高度用这些值算就必然偏小。

**改法（`js/painter_video.js`）**：
- hook `clone()`：把源节点的 5 个实例状态 + 真值尺寸 `(W,H)` 直接抄给副本；
- 副本记 `_bz_expectW/H`，`fitHeight` 里算出的高度若与期望差 >80px 就用期望值（内容没变不许算小）；
- 用户改宽度时 `onResize` 清掉期望值，恢复正常按宽度推导；
- 双 `requestAnimationFrame` 后写回尺寸（等 Vue 布局完，单帧不够）。

**根因为什么不会再犯**：以前修的是「推导链上的某一环」，环多就可能又漏一环；
现在改成「抄源节点真值」，推导链出不出错都不影响复制结果。宽度变化后仍走正常推导。

备份：`js/painter_video.js.bak_altclone_20261026`（第一次猜测前）。
诊断日志（`[BZ诊断]`）与 `__bzTraceFit` 开关待确认修复后删除。

### 2026-10-26 真凶定位（日志实锤，推翻"抄真值就够了"）

用户日志关键三行：
```
onConfigure  w=672  h=501        ← 尺寸正确
rAF          w=672  h=501        ← 还是对
fitHeight    节点宽:270  当前高:493  算出总高:275   ← 宽度被改成默认 270
```
栈：`processMouseUp → handleDragStateChange → handleDragEnd → updateSelectionBounds`。

**结论**：缩的是**宽度**，不是高度。Alt 复制后 Vue 在**拖拽结束**时用默认布局把副本宽度
覆盖成 270，高度公式以宽度为输入 → 493 被重算成 275 ≈ 一半。

**为什么"抄真值"那版无效**：写回发生在 rAF / 双 rAF，**早于** handleDragEnd，
写完立刻被下一次覆盖吃掉。时机不对，抄得再准也没用。

**这版改法**：
- 纠正改到 **`pointerup` 之后**（`setTimeout 0`，且必须用冒泡阶段——捕获会抢在
  GraphView 前面，同样被下一次覆盖）；
- 拖拽期间用 `_bz_expectW/H` 守住：`fitHeight` 开头先把被改回 270 的宽度拉回真值，
  高度偏差 >80px 时用期望值，避免中途闪一下矮半截；
- 2 秒 `setTimeout` 兜底（键盘复制等拿不到 pointerup 的场景）。

**教训**：这个节点"高度是推导值"没错，但**宽度的所有权不在我们手里**
（Vue 拖拽结束会覆盖）。以后凡是要纠正尺寸，必须先确认纠正时机晚于 Vue 的覆盖点。

### 2026-10-26 最终版：宽度守卫放在 onResize（不依赖事件时序）

参考 VHS 的结论：VHS 里**没有任何**尺寸记忆/纠正代码（`node.size =` 0 处、`properties`
存尺寸 0 处、`onResize` 0 处，`fitHeight` 只有一行 `setSize([w, computeSize()[1]])`）。
它的高度纯由 `node.size[0]` 推导，没人拉宽它，所以同样会被前端覆盖、只是不显眼。
**「参考 VHS」给不出根治方案 —— 它没解这个问题。**

最终实现（`js/painter_video.js`）：
- **宽度是唯一真值** `_bz_trueW`（双写 properties `bz_node_w`）；高度保持推导、不记忆。
- 守卫放在 `onResize` —— 尺寸被改写的那一刻，是唯一的写入口，不依赖 pointerup/rAF 时序。
- 判据 `app.canvas.resizing_node === this`（litegraph 在 `pointer.onDragStart` 设置）：
  是 → 用户亲手拖边角，记真值；否 → Vue 布局覆盖，立即 `setSize` 拉回。
- `_bz_fixingW` 防重入（`setSize` 会再触发 `onResize`，一层递归即收敛）。
- 删掉前面几版的 `_bz_expectW/H`、`待纠正副本` + pointerup、双 rAF 写回、全部 `[BZ诊断]` 日志
  与 `__bzTraceFit` 开关，只留一条「宽度被覆盖 X → 拉回 Y」。

**为什么这次比前几版接近根治**：前几版都在猜时机（rAF / 双 rAF / pointerup / 2s 兜底），
时机早于 Vue 的覆盖点就失效；`onResize` 不是时机选择，而是覆盖动作的必经入口 —— 谁改尺寸都得从这里过。

## 2026-10-26 🎬 H3 终极放大：时间分块段边界画面突变 → 改整条共享轨迹

**用户报**：接「时间分块参数」后接缝处画面突变；断开「时间分块参数」就完全没有 —— 定位到分块机制本身。

**根因（机制性，不是参数）**：原实现是「逐段接力」——段 N 一路收敛到 sigma=0 的成品，
段 N+1 再从同一去噪强度重新起噪，前若干帧锁定成段 N 的真值只当上下文。锁定只能对齐**数值**，
对不齐的是**两条轨迹的中间态**：边界一侧是终态画面、另一侧是从噪声重新长出来的画面，
内容/亮度/细节量必有落差，硬切处就是突变。步数=1 时落差最大。

**改法**：新增 `_sample_temporal_sync`（整条时间轴共享一条去噪轨迹）。
- 每个 sigma 步依次前向所有窗口，只把各窗口**核心区**写进同一份全局 denoised，再统一推进一次 Euler；
- 核心区 = 去掉头部重叠步（`lock = 上一窗口终点 - 本窗口起点`，按**实际边界**算，
  不能用设定重叠值 —— 末尾补的贴合窗口重叠远大于设定值，固定值会让重叠区被重复生成）；
- 无 denoise_mask、无干净上下文注入：所有窗口同 sigma、同轨迹，模型看到的是「一个整体处于该噪声水平的窗口」，
  这是滑窗采样的自洽语义，不是 inpainting 语义；
- 关键帧按窗口裁（`_slice_cond_time`）+ 每段切换 `model_conds["minimax_keyframes"]`，片头锚不注入后续窗口；
- 计算量不变（步数×段数 次前向，与逐段各跑一遍曲线相同）；代价是整条 latent 上卡（日志打出 MB 数）。

**分派条件**：`len(windows)>1` 且采样器是 euler 且 `n_tiles<=1`。
不是 euler 或同时开空间分块 → 退回逐段接力并打印警告（二维同步未做）。

**验证**：`_selftest_temporal_sync.py`（13 种 T × 6 种块长 × 3 种重叠，全组合核心区严格互补覆盖 + 段边界相邻）→ PASS。
真机待验：重启 ComfyUI（改 .py 必须完全重启）→ 跑原工程 → 看 `[H3时间] ⚡ 整条共享轨迹` 是否出现 → 接缝处是否还有跳变。

**还原**：`banzhang_mmh3_upscale.py.bak_tempsync_20261026`。

## 2026-10-26 导演台：重抽「保留动作」偷偷生效 → 视频每 0.7 秒闪一下

**用户报**：重抽的片子每隔约 0.7 秒（17 帧）闪一下；「新建工程就好」。
日志：`重抽本段（旧版第 2 版）· 保留动作（骨架间隔 22 · 锚点等间隔）`。
用户坚持：这个档位 UI 早就删了。

**根因**：删的只是 UI 下拉框，执行侧的**回退默认值**没删。
`csglide_cast.py` 同一字段四处取值默认值冲突：`:943` 声明 `"重画"`，`:959` 读档
`or "保留动作"` —— 而 `:946` 只要工程带 chain 就会重建 chain_ref，所以事实默认值是
「保留动作」，:943 根本轮不到。老档案里还显式存着该值，UI 已无处可改 → `REDO_STRIDE`
取 22 → `build_pin_mask` 每 22 帧把**整个 latent 步**标 0（原样贴旧版像素）。
落到 H3 周期首步（那一步只覆盖 1 帧）就是单帧孤立 → 视觉上"闪"。
「新建工程就好」不是档案干净，是新工程没有旧版可钉。

**定量证据**（`_selftest_pin_stride.py`，T=152 步 / 515 帧）：
stride=22 钉住 30/152 步（20%），骨架落点帧 0/22/43/64/86/107/132/154/175/196/217/239；
片子实测闪点 85/136/153/221/238 —— 逐一对应（误差 ≤4 帧 = 一个 latent 步）。
stride=7（只换画质）更狠：78/152 步（51%）。stride=0 只剩尾部 7 步（22 帧）。

**修法（归一化，不是改回退值）**：`csglide_cast.py` 读档处 `:968` 与消费处 `:2668`
把 `redo_mode` 归一成两种语义 —— `"完整重拍"`（整段不钉）或 `"重画"`（只钉头尾）。
老档案里的 `保留动作 / 只换画质` 在导演台侧**彻底作废**（UI 已无入口，留值只会作恶）。
另外三处 `or "保留动作"` 同步改 `or "重画"`（:2521/:2530/:2546）。
注意：`banzhang_h3_pin.py` 独立节点（🧷 钉帧）下拉框仍保留完整档位，那是另一条路径，未动。

**验证**：py_compile 通过。真机：重启 ComfyUI → 同段重抽 → 日志应是
`档位「重画」（骨架间隔 0…）`，不再是「保留动作 / 骨架间隔 22」→ 用
`_probe_flicker.py` 跑新片，孤立帧应为 0。

**副作用**：重抽不再保留旧版骨架，动作会变（这是「重画」本义）。若日后要"动作不变
只换画质"，得把骨架遮挡从 mask=0（硬贴旧像素）改成软值做引导，不能直接恢复 22。

**还原**：`csglide_cast.py.bak_redomode_20261026`。

## 2026-10-26（续）三件套「永久删除」—— 归一化不够，代码一起删

**用户指令**：「这些功能早就已经删除了，为啥还会影响现在？给我永久的删干净这几个参数和相关代码」。

上面那轮归一化只改了**回退值**，执行侧 `or "保留动作"` 还在、老工程档案里的值也还在 ——
UI 删了 ≠ 功能下线，它以「幽灵开关」形式继续生效。这一轮把三件套从代码里连根拔掉。

**删除清单**

| 位置 | 删了什么 |
| --- | --- |
| `banzhang_h3_pin.py` | `_step_at_frame` / `_motion_energy` / `_pick_motion_anchors` / `REDO_STRIDE` / `FULL_RESHOOT` / `FOLLOW` / `_chain()` / `resolve_redo()`；`build_pin_mask` 签名收成 `(latent, head=0, tail=22, keep_audio=False)`；节点输入只剩「保留头部 / 保留尾部 / 保留声音」；`pin()` 加 `**_legacy` 吞掉老连线传来的废弃参数并显式提示 |
| `csglide_cast.py` | 读档 `:939`、写档 `:2502/:2515`、下一段重抽判定 `:2530` 三处的 `redo_mode` / `redo_anchor`；`mode` 归一化块与「完整重拍」早退分支；钉帧主体改为「头尾都 ≤0 就不钉」 |
| `banzhang_producer.py` | `:644` 默认 state 里的两行 |
| `js/csglide_cast_core.js` | `REDO_MODES` / `REDO_ANCHORS` / `REDO_MODE_VALUES` / `REDO_ANCHOR_VALUES` / `REDO_GROUPS` / `redoGroupOf` / `redoDefaultOf` 整块；`blankState()` 不再播种 `redo_mode`；`parseInitial` 不再读这两个键 |
| `js/csglide_cast.js` | 上面那批符号的 import |
| `js/csglide_cast_settings.js` | `mkPinInp` 里「钉帧要生效必须把档位写成重画」的补丁（幽灵复活的路径之一）；改为一次性 `delete` 老值 |
| `js/csglide_cast_run.js` | 多段渲染时统一写 `redo_mode`；改为 `delete` |
| `templates/producer_video_h3.json` / `.base.json` / `MiniMax-H3 (4).json` | 内嵌 `h3_data` 里的 `"redo_mode":"保留动作","redo_anchor":"等间隔"` |

**踩到的坑（值得记住）**：删 `core.js` 常量后，`parseInitial` **函数体内**还引用着
`REDO_MODE_VALUES` —— `node --check` 过、模块加载也过，只有面板真去解析存档时才
`ReferenceError`。所以补了两道闸：

1. `tests/js/_selftest_modules.mjs` 的加载链加上 `csglide_cast.js`（导演台本体原来**不在链上**）；
2. 新增【3】段：真的调一遍 `blankState()` 与 `parseInitial(老存档脏值)`，断言输出里
   没有 `redo_*`、且 `pin_head/pin_tail` 照收。
   已反向验证：把旧引用塞回去 → 29 通过变 26 通过 / 3 失败（`REDO_MODE_VALUES is not defined`）。

**自检**：
- `python_embeded/python.exe -m py_compile` 四个改动文件 → 通过
- `_selftest_pin_stride.py` 改造为回归守卫 → **PASS**：签名无 stride/anchor；
  `head/tail` 四种组合下被钉的步只落在头/尾段，中间段零钉帧
- `node tests/js/_selftest_modules.mjs` → **29 通过 / 0 失败**

**还原**：`banzhang_h3_pin.py.bak_redodel_20261026`、`csglide_cast.py.bak_redomode_20261026`。

## 2026-10-26（再续）时间轴撤销按钮 + 撤销/还原点整套删除

**用户指令**：「删除时间轴上面的撤销按钮和功能」→ 选 **C（彻底删）**。

**为什么不是"只删按钮"**：撤销按钮只是入口，背后是一整套还原点机制 ——
`snapProject()` 在 8 个文件里有 20 处调用（新建 / 打开 / 删段 / 拆分 / 渲染全部 / 改名 /
切工程 / 清理残留段 之前都会存点）。只删入口 = 还原点只进不出，白占 `node.properties`
撑大工作流 JSON，且界面上所有"可撤销"提示全变成假话 —— 那是最差的"半死"状态。

**删除清单**

| 位置 | 删了什么 |
| --- | --- |
| `js/csglide_cast_monitor.js` | 轴头 `↶ 撤销` 按钮、`paintUndoBtns`（含 title 状态机）、`Ctrl+Alt+Z` / `Ctrl+Alt+Shift+Z` 监听、`castActive`/`onCastPointer`/`onCastFocus`（只服务撤销的判定）、`ui.undoKeyTeardown`、`Object.assign` 里的 `btnUndo` |
| `js/csglide_cast_shots.js` | 还原点栈整块（-266 行）：`HIST_MAX` / `REDO_MARK` / `isRedoMark` / `markRedo` / `unmarkRedo` / `projSnapshot` / `histBag` / `snapProject` / 中央镜像 `mirrorSnapshotCentral` + `hydrateHistFromCentral`（B2 回填）/ `prevProject` / `redoProjectItem` / `agoText` / `prevWhen` / `restoreHistoryEntry` / `undoProject` / `redoProject` / `undoInfo` / `refreshUndoUi`；导出清单同步收窄 |
| `js/csglide_cast_review.js` | 右键菜单「↶ 撤销一步 / ↷ 重做」两项 |
| `js/csglide_cast.js` | `onRemoved` 里的 `ui.undoKeyTeardown?.()`、渲染前的 `snapProject("渲染前")` |
| 8 个文件 20 处 | 所有 `ui.snapProject(...)` 调用（cmdbar 1 / conflict 4 / monitor 2 / run 2 / shots 4 / sync 1 / cast 1 / project_sync 1） |
| `js/bz_project_sync.js` | `saveSnapshot` / `listSnapshots` / `getSnapshot` / `deleteSnapshot` 四个通道（唯一使用者是撤销栈） |

**没删的（有意保留，别当漏删）**

- 后端 `csglide_store.py:1917-1974` 的 5 条 `/cglide/store/snapshot*` 路由 +
  `templates/store_route_smoke.py` —— 那是**通用存储 API**，不属于撤销功能的行为面，
  删它只会让老前端 404 而没有收益。
- `csglide_rack_vacate.js` 的 `ui.vacateUndo()`（槽位纠错回退）、
  `csglide_prompt_editor.js` 的编辑器撤销栈 —— 名字里有 undo，但**是另外的功能**。

**连带改的文案（否则界面说假话）**：新建工程 / 打开工程 / 删段 / 清理残留段 /
拆分 / 切换工程 / 全片渲染 / 项目名 → 全部从「可用「撤销」退回」改成「不可恢复」。
新增的 button title 明确写「想留后路请先「另存工程文件」」。

**代价（用户已知并接受）**：新建工程、打开工程、删段、拆分、渲染全部 之前不再存还原点，
这些操作从此**不可逆**。裸 `Ctrl+Z` 在导演台里按下去仍是 ComfyUI 画布撤销（会整张工作流
回滚），导演台不再接管任何撤销快捷键。

**验证**：11 个文件 `node --check` 全过；`node tests/js/_selftest_modules.mjs` 29 通过 / 0 失败；
撤销相关 17 个符号全库复扫 **零可执行残留**（只剩删除说明注释）。

**还原**：同目录 `*.bak_undodel_20261026`（10 个文件）。

## 2026-10-26（再再续）段块右键精简：跳过搬去悬停工具条，版本行内联删除

**用户诉求**：「时间轴右键过于杂乱」→ 给出 4 个方案 → 用户定制了第 5 种：

1. 「跳过」搬到段块悬停工具条
2. 「复制」从右键删掉（工具条已有 ⧉）
3. 「版本」保留，但删掉独立的「删除版本」组 —— 改成每个历史版本名后面挂一个 🗑 图标

**杂乱的真凶**：菜单项本身不多，是 `paintTakeGroup()` 动态铺开的 ——
重抽 5 次的段 = 版本标题 + 5 个切换 + 「删除版本（释放磁盘）」标题 + 4 个删除 = **10 行版本**，
加上其它项共 15 行。真正的高频动作只有「跳过 / 复制」两个。

**改动**

| 文件 | 改了什么 |
| --- | --- |
| `js/csglide_film.js` | 悬停工具条按钮表插入 `{ k: "skip", t: "○" }`（排第一）；`paintSeg()` 按 `isSkipped(c)` 把图标刷成 ◉ 并加 `.on` 高亮；新增 `.bzf-seg-act[data-act="skip"].on` 样式 |
| `js/csglide_cast_monitor.js` | `onSegAction` 新增 `kind === "skip"` 分支 → `ui.toggleSkip(j)`；孤儿段（j<0）提示先认领 |
| `js/csglide_cast_sync.js` | 右键删掉「跳过」「复制」两项及其分隔线；菜单只剩 版本区 + 清色；分隔线挪进 `if (s.colour)` 内避免顶部孤线 |
| `js/csglide_cast_takes.js` | 版本区从「清单 + 独立删除组」改为「一行一版」：左边切换按钮 + 右边 🗑（`stopPropagation` 防止误触切换）；当前版不给删 |
| `js/csglide_cast.css.js` | `.gcast-take-row` 一行两按钮的 flex 布局 + 删除图标 hover 变红 |

**额外补的兜底（重要）**：菜单只剩「版本 + 清色」后，两种常见情况会让它变成**空壳** ——
从没重抽过（只有 1 条版本）、也没手动设过颜色。那样点右键"像坏了"。做法：
`paintTakeGroup` 返回 Promise，落定后若菜单里没有一个可用 button，就收掉菜单并在反馈条说明
「跳过 / 复制在段块上方图标里，接缝与钉帧在右侧卡里」。

**验证**：5 文件 `node --check` 全过；`_selftest_modules.mjs` 29 通过 / 0 失败。
前端布局改动**必须真机验收**（见交付说明）。

**还原**：同目录 `*.bak_segmenu_20261026`（5 个文件）。

## 2026-10-26（再再再续）删掉「班长 · 提交对齐」右下角弹窗

**用户诉求**：「删除点击画布运行后的弹窗提醒，提交到对齐这个提示」。

**位置**：`js/bz_queue_align.js` —— 它包装了 `api.queuePrompt`，画布运行（▶ / Ctrl+Enter）
提交前会把三个 `*_data` 编译成本段数据。原来编译成功/退回对齐后会在右下角弹一条
`severity:"info", summary:"班长 · 提交对齐"` 的 toast，4 秒消失。

**改法**：删掉 `toast()` 函数（含 `app.extensionManager.toast` 调用）+ 唯一调用点，
改为只 `console.log("[班长] " + msg)`。文件头补一段「不弹窗（20261026 用户定）」说明，
防止以后有人又加回去。

**为什么只删弹窗不删对齐**：对齐/编译本身是必需的（不然画布运行会提交空提示词、空素材，
空 clip 还会被当成新建一段）。用户要的是别每次都弹，不是别对齐。

**验证**：`node --check` 通过；`bz_queue_align.js` 已加入 `tests/js/_selftest_modules.mjs`
加载链（原来不在链上），自测 **31 通过 / 0 失败**。

**还原**：`js/bz_queue_align.js.bak_toastdel_20261026`。

## 2026-10-26（第五批）删掉「按提示词排序」后的底部提示条

**用户诉求**：「删除媒体架点击按提示词排序后底部出现的弹窗提示」。

**位置**：`js/csglide_rack_sort.js` 的 `sortByPrompt()`。底部那条是 `ui.toast`
（`csglide_media_rack.js:62` 的 `.gmr-toast`，挂在媒体架面板底部，默认 3.6s 淡出，
排序这条传 9000ms 甚至 12000ms）。

原来每次点都会弹一条长条，内容形如
`已按提示词重排 ｜ 段2 clip_0002 ｜ 8 个编号 ｜ 图片：陈墨白→1 …`，素材一多横跨半屏。

**改法**

| 分支 | 原来 | 现在 |
| --- | --- | --- |
| 成功排动（`r.total > 0`） | 弹汇总长条（12000ms） | **不弹**，只留 `flashBtn` 按钮上那行短字「已排 8 · 纠位 2」 |
| 什么都没动（`!r.total && !vacN`） | 无条件弹（含「顺序已对齐」这种正常情况） | 只在 `bad || vacWarn.length` 时弹（读不到编号 / 认不出名字 / 缺素材 / 纠错搬不动） |
| 没接节点（`!texts.length`） | 弹 | **不变**（不说就真的没反应了） |

明细（谁落到第几栏、纠了哪两格、缺哪些素材）仍完整打进
`console.log("[媒体架] 按提示词排序诊断", {...})`，排障不受影响。

**没动的**：「排全部段」按钮（`bSortAll`）的两条 toast 保留 —— 它是另一个入口，
用户这次只点了单段那个。

**验证**：`node --check` 通过；`_selftest_modules.mjs` **31 通过 / 0 失败**。

**还原**：`js/csglide_rack_sort.js.bak_toastdel_20261026`。

## 2026-10-26（第六批）修「卡片 391 帧 / 轴 430 帧 / 成片 430 帧」三处分叉

**用户报**：「导演台上对应的段的卡片设置的是 16 秒 391 帧，但是时间轴上显示是
17.9s / 430 帧，生成的视频也是 17 秒 430 帧」。选方案 C（A + B）。

**根因：同一条账有两个真值**

| 谁 | 用什么算「这一段开头有几帧是上一段的」 | 结果 |
| --- | --- | --- |
| 导演台卡片 `headOverlapFrames()` | 档案 `trim_frames`（不问位置） | 430 − 39 = **391** |
| 时间轴 `film_summary()` / `_span_of()` | `... if i > 0 else 0`（**只看它排第几**） | **430** |

`clip_0002` 是 Alt 复制 `clip_0001` 出来的，出厂就带 `cont.frames = 39`；后来
`clip_0001` 被删，`order = ["clip_0002"]` —— 位置变成「第 1 段」，`trim_frames = 39`
没跟着变。于是轴上按位置算 430，卡片按事实算 391。

下游还有第二处：`_compute_film_head()` 用 `ff >= clip_to` 判「累积片」。首段
`clip_from == 0` 时累积长度恰好等于净长，430 ≥ 391 成立 → 判成累积片 → `head = 0`
→ 导出从第 0 帧开始，把 39 帧旧画面留下、末尾少 39 帧真画面。

**改法（`csglide_chain.py`，4 处）**

1. 新增 `_head_trim_of(c, n)`：只认 `trim_frames`，**位置不参与算账**。
2. `film_summary()`：改用它；并清**残留旧账** —— 一段成了首段、盘上**没有成片**
   却还揣着承接窗口（复制段/拆分段出厂带的 39），那几帧不是"文件里的旧内容"，
   清成 0（`update_clip` 写回，幂等）。**有成片的一律不动**：那 39 帧真在 mp4 里。
3. `_span_of()`：改用它（导出/播放同口径），同时删掉不再使用的 `i`。
4. `_compute_film_head()`：`clip_from == 0` 且 `ff >= 净长 + 承接头` 时判单段片
   （`head = trim`）；`film_summary` 里那道重复判形态的 `_single` 闸门删掉，形态
   判定只留这一处。

**没改 `cont.frames`**：那 39 帧真实存在于 `clip_0002` 的成片里，清掉等于把用户
想要的 391 丢回 430。清账只针对**从没拍过成片**的段。

**实测**（`未命名工程 22`）：`total_frames` 430 → **391**、`seconds` 17.9 → **16.292**、
`film_head` 0 → **39**、导出裁切 `skip=39 / net=391`。

**注意**：该段现存成片 `clip_0002.t8.mp4` 实测 **515 帧**，与档案 `frames=430`
本来就不一致（旧时长的残留）。**这一段必须重跑一次**，轴/卡片/成片才真的对齐；
重跑后单段 mp4 = 430 帧（39 承接头 + 391 新画面），导出成片 = 391 帧 / 16.3s。

**验证**：`py_compile` 通过；新回归守卫 `_selftest_netfix.py` **23 通过 / 0 失败**；
`tests/js/_selftest_modules.mjs` **31 通过 / 0 失败**。

**还原**：`csglide_chain.py.bak_netfix_20261026`。

## 2026-10-27 时间分块：核心区独占 → 重叠区羽化融合

**现象**：二采（时间分块 6 块、共享轨迹已启用）"同一场景里画面轻微像被 0.5 强度重绘了一下"。

**排查过并排除的**（都有量化数据，别再重复查）：
- 每段独立噪波 —— 否，整条 `noise_v` 只生成一次，每块切 `[:, :, s:e]`
- 段边界硬切 —— 否，5 个边界帧的帧差/邻域比 1.29~1.79（对照 95 分位 2.57）
- 清晰度突变 —— 否，窗口起点锐度连续滑移无台阶，全片孤立突变仅 2 处
- SLA 稀疏注意力 —— 否（真机 A/B 排除）
- 预显影 —— 否，`pre_steps=0` 未启用，且它整条整幅一次做完

**根因**：共享轨迹只统一了「x 怎么演化」，没统一「每帧能看到多少上下文」。
`_sample_temporal_sync` 的写回是**核心区独占**（`v_den[:, :, s+lock:e] = pred[:, :, lock:]`）——
每帧只由唯一一个窗口负责，落在窗口边缘的帧在模型前向时看不到窗口外内容，预测比中心帧弱。
成片就是「同一场景里画面轻微被重绘了一下」。

**改法**（借鉴 Gen-L-Video 的 Temporal Co-Denoising，`G-U-N/Gen-L-Video`，Apache-2.0，只借算法不引入依赖）：
每个窗口的**整个窗口输出**都参与，重叠区按三角羽化权重累加，最后除以权重和。

| 位置 | 改动 |
| --- | --- |
| `banzhang_mmh3_upscale.py:2115-2120` | 新增 `_feather(n)`：三角窗，端点用 `i+0.5` 保证权重永远 >0（否则片头尾单窗口覆盖处 0/0 变黑段） |
| `:2179-2207` | 写回从「核心区赋值」改为「全窗口加权累加 + 归一化」；新增 `v_wsum` / `a_wsum` |
| `:2060-2070` | 覆盖自检从 `cover[s+lock:e]` 改为 `cover[s:e]`（融合下每个位置都要有权重） |

**代价**：模型前向次数/显存完全不变（重叠区本来就送进了模型，原来只是丢弃输出），
只多一次累加。重叠区约占单窗口 37%，融合后细节略微更「平均」。

**自检**：
- `_selftest_temporal_sync.py`（几何）→ PASS
- 新增 `_selftest_feather.py`（数值）→ PASS：常数预测融合后**逐位不变**（证明是加权平均不是叠加）、
  权重和处处 >0、片头片尾等于单窗口值、单窗口权重 ∈ (0.031, 0.969]

**待真机确认**：同一段重跑，看「被 0.5 重绘」的感觉是否消失。

**还原**：`banzhang_mmh3_upscale.py.bak_feather_20261027`。

## 2026-10-27 续接交界：羽化 + 修掉「帧当步」的双倍回填

用户问「时间轴续接是不是同一个机制」——**不是**，但症状同源（都是硬边界）。

| | 时间分块 | 时间轴续接 |
| --- | --- | --- |
| 位置 | 同一段内部 | 段与段之间 |
| 采样 | 一次采样、共享轨迹 | 每段各一次独立采样 |
| 衔接 | 重叠区羽化融合 | 钉帧遮罩（硬 0/1）+ 采样后回填 |
| 能否共享轨迹 | 能 | **不能**（段 N+1 开始时 N 早已收敛成片） |

**两个回填端**（以前各写一份，正是错能活下来的原因）：
- 节点 `🧷 H3 尾帧回填` → `banzhang_h3_pin.py` `BanZhangH3TailRestore.restore`
- 导演台重抽 → `banzhang_ksampler_patch.py` `_copy_pinned`（`bz_pin` 元数据）

**查出来的真 bug**：`bz_pin` 里的 `head` / `tail` 是**帧**（来自面板 `pin_head` / `pin_tail`），
但 `_copy_pinned` 直接当**步**用（`h = min(head, total)`）。H3 一格步 ≈ 3.4 帧，
**填 22 帧实际回填 22 步 = 73 帧** —— 重抽成果被旧版盖掉一半，交界位置整个后移 3 倍。
节点那条路早就在 `pin_extent`（原 `_counts`）里换算过，导演台这条路漏了。

**改法（单一真值，两处共用）**：

| 位置 | 改动 |
| --- | --- |
| `banzhang_h3_pin.py:81-150` | 新增模块级 `PIN_FEATHER=3` / `pin_extent()` / `pin_feather_weights()` / `blend_edge()` |
| `banzhang_h3_pin.py` 类内 | `_counts = staticmethod(pin_extent)`、`_blend_edge = staticmethod(blend_edge)`（原实现删除，不保留两份） |
| `restore` 尾部 | 回填后交界各 3 格线性过渡；缝比羽化窗窄时整块放弃 |
| `banzhang_ksampler_patch.py` `_copy_pinned` | 用 `pin_extent` 换算帧→步 + 同样羽化；返回值加 `feathered` |
| `_restore_pinned_tail` 日志 | 改成「回填 N 格（头 X 帧/尾 Y 帧换算而来）＋交界羽化 N 格」 |

羽化权重：头部 `0.75 / 0.5 / 0.25`（越靠后越像新版），尾部反向。

**自检**：`_selftest_featherpin.py` → **PASS**
- 节点端：头 0~6 全旧版、7/8/9 为 0.25/0.5/0.75、之后全新版；尾部对称；缝=0 时羽化自动放弃不稀释回填
- 导演台端：T=127 步下回填 **24 格**（画面 7+7、声音 5+5），而不是错的 88；羽化 12 格

**预期变化**：修好帧→步后，重抽段会有**更多画面是重新生成的**（以前被旧版盖掉一大截）。
这不是副作用，是修复本身。「下一段引导头 = 本段尾 22 帧」的保证不变。

**还原**：`banzhang_h3_pin.py.bak_featherpin_20261027`、`banzhang_ksampler_patch.py.bak_featherpin_20261027`。


---

## 2026-10-27 12:55 🧷 最后几帧花屏：钉住 ≠ 有内容（方案 A' 先写后钉）

### 现象

A2（续接交界羽化）交付后用户报：「现在最后几帧又开始变得花屏了」。

### 第一条事实：A2 当时根本没在跑

- ComfyUI 进程 PID 35224 启动于 **12:24:29**
- `banzhang_h3_pin.py` 改于 **12:32:09**、`banzhang_ksampler_patch.py` 改于 **12:32:27**

Python 模块在进程启动时 import 一次，之后改文件不会重载 —— 所以那次花屏
**不可能是 A2 造成的**，跑的是 A2 之前的代码。教训照旧：改完必须整进程重启。

### 第二条事实：钉帧与回填逐格一致，没有真空档

新建 `_selftest_pincover.py`，把「遮罩钉住哪些格」和「回填覆盖哪些格」分别
算出来逐格比对（画面 5 组 + 声音 5 组）。画面**恒等**；声音当时差 2 格。

### 根因链：花屏只有一个成因

`comfy/samplers.py:642` —— `out = out * denoise_mask + self.latent_image * latent_mask`。
遮罩为 0 的位置，输出**逐位等于喂进采样器的输入潜空间**。所以「钉住」只是
「别改这几步」，**内容得自己先写进去**。以前这件事 100% 交给采样后的回填
（`_restore_pinned_tail`），而回填有三道会**静默不跑**的关：

| 关 | 触发条件 | 后果 |
|---|---|---|
| ① 绕过补丁 | 采样走自定义 / 放大采样器，不是被补丁包住的 KSampler | 回填那行代码没机会执行 |
| ② 网格变了 | SelfLift / 多级提升中途把 latent 放大 1.5× | 回填发现形状不符，整条流跳过 |
| ③ 读不到旧档 | 刚重开工程 / 档号被清 | 直接 return |

任何一道没过，被钉住的那几步就停在**没采样过的 latent** 上 → VAE 解码成
红褐编织纹 = 花屏。**而且它必出现在片尾**（钉的就是尾），正是「最后几帧花屏」。

### 修法：方案 A' —— 先写，再钉

新增 `banzhang_h3_pin.seed_pinned_streams(dst, src, head, tail, keep_audio=False)`，
在 `csglide_cast.py::_attach_pin` 里、**挂遮罩之前**把旧版的头 / 尾格直接写进
输入潜空间。采样器自己就会把它原样留在钉住的位置 —— 与采样器型号无关、与网格
有没有中途变化无关、与回填跑没跑无关。回填保留为第二道保险（内容相同，白写一遍）。

配套三条：

1. **写不进就不挂遮罩**：`seed_pinned_streams` 返回 False（形状不符 / 旧档为空）时
   丢弃 noise_mask，只靠回填。宁可接缝跳（看得见、能补），也不出废品。
2. **声音遮罩与换算统一**：`build_pin_mask` 的声音分支原来按「每个画面步摊一格」
   自己算一套，比 `pin_extent` 多 2 格 —— 那 2 格被钉住却没有旧内容可钉，声音
   带噪声（轻微破音）。抽出 `pin_extent_T(T, is_video, ...)`，先写 / 遮罩 / 回填
   三处共用同一把尺子，缺口归零。
3. **内部调用不打误导提示**：调 `CSGlideClipLoadCS().load` 时传 `顺序锚=-1`，
   免得日志里冒出「没接顺序锚」（那是给节点用户看的）。

### 自检

- `_selftest_seedpin.py` **PASS**：模拟 `out*遮罩 + latent_image*(1-遮罩)`，
  遮罩为 0 的每一格都逐位等于旧版内容；对照组（不先写）全部等于垃圾值 ——
  花屏被**复现**后再被修掉。含只钉头 / 只钉尾 / 大钉尾 / 连声音一起钉 / 网格不符 / 旧档为空。
- `_selftest_pincover.py` **PASS**：画面遮罩 ≡ 回填（5 组）；声音缺口 2/2/1/1 → **0/0/0/0/0**。
  声音那半边改为**取真遮罩**（`build_pin_mask`）而不是自己复现映射 —— 复现就是第二真值，
  改实现不改它，自检会继续「通过」。
- 既有四个自检全 PASS：`_selftest_feather` / `_selftest_featherpin` /
  `_selftest_temporal_sync` / `_selftest_pin_stride`。
- `py_compile` 三个源文件 + 两个自检通过；`csglide_cast.py` 保持 CRLF（3520 行，0 个裸 LF）。

### 代价

重抽一段时多一次旧档读取（几十 MB，CPU）；画面结果不变 —— 先写的内容与
回填的内容本来就是同一份。

## 2026-10-27 16:10 提示词元信息分层：图不再被画上标题文字

**问题**：资产图/核心帧图作为 `@图片N` 喂给视频模型时，图上的标题栏、视图名、尺寸框会被一起
继承进成片。而技能产的资产提示词本身就写着「画面文字：顶部标题栏居中标注『陈墨白』…」——
不是解析错，是提示词明确要求画字。

**方案：包裹符内加一层 `<<<元信息>>>`，元信息与正文分开。**

```
<<<主体提示词>>>
<<<元信息>>>
主体标题名称：陈墨白
尺寸信息：总高度 1.78 米；总宽度 0.42 米
画幅：16:9
<<<元信息_END>>>
画面内容：（纯视觉描述，不含任何画字指令）
<<<主体提示词_END>>>
```

**为什么不用「清空列表 / 正则剥壳」**：那是猜哪些行像元信息，脆弱；分层是结构上声明，
程序只需按标签切，语义无歧义。跟技能已有的九种标签同一套语法。

**改动**

| 位置 | 内容 |
|---|---|
| `js/csglide_asset_batch.js` | `parseAssetDoc` 识别 `<<<元信息>>>`，正文与 meta 分开返回；派发时负面追加「文字、水印、字幕、标注、标题、签名、数字」 |
| 技能 `03-主体参考.md` | 主体/服装/道具三块加元信息层；删 `画面文字`、`尺寸信息框`、四处 `下方标注"…"`；「与尺寸信息框一致」→「一致」 |
| 技能 `04-场景蓝图.md` | 场景块加元信息层；删 `画面文字`；改掉「标题栏标注不受此限」的旧口径 |
| 技能 `05-段核心帧图.md` | 核心帧块加元信息层（标题名称/画幅）；正文删掉裸的标题行 |
| 存量 10 个文件 | `祖龙锁-资产提示词-主体.md` + 两个 `第N集/SEG_*.txt`，脚本重排并备份 `.bak_meta_*` |

**关键细节：内层必须先判。** `元信息_END` 也以 `_END` 结尾，落到通用收尾分支会把外层
`<<<X提示词_END>>>` 提前闭合，正文从此截断——所以 `parseAssetDoc` 里 `META_END` 判断
写在 `t.endsWith("_END")` 之前。

**兼容**：老文件没有元信息层 → `meta` 为空、`body` 为全文，行为与改动前完全一致。

**未受影响的解析方**（已逐一核实）：文案台 `pickVideoBlock` 只切 `<<<视频提示词>>>`，迁移
未触碰视频块；`banzhang_sp_cards.js` 里「核心帧提示词」只出现在界面提示文案，无解析逻辑。

**自测 14 项**：新格式剥离、正文无标题/画幅、meta 正确、外层不被内层 `_END` 截断、
同文档混合格式互不影响、老格式整块当正文、元信息放正文之后也能剥。
真实文件端到端：4 条资产正文零污染，meta 完整。

**未做（待定）**：`第N集/SEG_N_prompt.txt` 没有 `## @图片N` 标题，`parseAssetDoc` 仍解析
出 0 条，核心帧图还不能拖进去批量生成（正文已干净，只是入口没开）。

## 2026-10-27 16:35 📈 活动监视器：阶段色带 + 两行节点名（方案 A）

**需求**：曲线上要能直接看到「这段曲线是哪个节点」，从而知道每个阶段的显存/内存占用。

**改前事实**（两条，都是根因）：
1. `addStage()` 只存 `{t, name, kind}`，**段没有终点** → 无法表达区间，只能画成竖线。
2. 顶部标签轨只有一行（`labelY = padT - 13 - 2`），判据 `if (tx >= lastLabelEnd)`，
   **重叠即静默丢弃** → 节点一多标签大半消失。

| 位置 | 改动 |
|---|---|
| `js/banzhang_mem_graph.js` `padT` | `22 → 37`，腾出两行标签轨（曲线区矮 15px，面板高度 312 不变） |
| `addStage()` / 新增 `closeLastStage()` | 段补 `end`：下一段开始时收尾上一段；`executing(null)` / `execution_interrupted` / success / error 都会收尾 |
| 新增 `buildBands()` | `stages → [{t0,t1,name,i}]`，`i` 供相邻段交替配色 |
| `_drawChart()` 色带段 | 曲线之前铺交替色带（`.028` / `.060`），段左边界 1px 线，悬停段提亮到 `.105` |
| `_drawChart()` 标签段 | 节点段不再画竖线（色带边界即竖线），标签改两行交替；单标签限宽 104px 超宽裁 `…` |
| `onRemoved` | 补 `execution_interrupted` 反注册 |

**设计约束（别再踩）**：
- 末段延伸终点只用 `nowT`（曲线自己的时间轴），**不能混浏览器 `Date.now()`** ——
  远程访问时两钟不同源，色带会与曲线错开。
- 窄于 1px 的段不铺色，但**必须保留左边界线**；`continue` 写在画线前会让短节点彻底消失。
- 采样 1 秒 / 点：时长 < 1 秒的节点只有边界线、没有自己的采样点，色带高度差不可读。

**验证**：`node --check` 通过；`_selftest_out/selftest_stageband.js` 从源码抠函数真跑，
12 项全过（收尾时机、末段延伸、完成后不延长、中断收尾、零长段丢弃、配色序号递增）。
真机显示待用户验收。

**已知限制**：`st.stages`（前端时钟）与 `st.points`（后端采样时钟）在远程访问时可能有偏差，
色带与曲线峰值会对不齐；本地部署同机同钟，无影响。此问题改动前就存在。

### 16:45 追加：删掉悬停浮层（用户要求，遮挡曲线）

**症状**：鼠标划过曲线弹出一块毛玻璃浮层（16:40:35 / 显存 23.3GB 97% / 内存 28.1GB 88% /
GPU 100% · 68°C），把正在看的曲线整段盖住。

**删干净清单**（只删入口会留下孤儿）：CSS 9 条 `.bz-am-tip*`、`fmtTime()`、
`stageAt()`、`showTip()`、`_drawChart` 里的 `showTip()` 调用与 `else { st.tip.classList.remove("show") }`、
`const tip = el("div","bz-am-tip",chart)`、`node._am` 的 `tip` 字段。文件 785 → 717 行。
保留：悬停十字线、悬停点高亮圆点、顶部统计胶囊（数值出口不变）。

**注释里写明「不做悬停浮层」**，避免以后被当缺失功能加回来。
**自检仍 12 项全过**。备份 `js/banzhang_mem_graph.js.bak_notip_20261027`。

### 17:00 🔴 真 bug：`rrPath` 只被调用、从未定义（标签全部画不出来）

**症状**：用户报「并没有显示明暗交替的竖条带」。进一步查：节点名标签也从来没有出现过。

**根因**：`rrPath` 全文件仅 1 处命中（调用处 `:378`），**没有任何定义**。
`_drawChart` 被 `try/catch` 包着 → 每次绘制走到标签胶囊那行抛 `ReferenceError`，
被静默吞掉 → 色带之后的标签、竖线、悬停圆点全部不执行。
**对比历史版本：`bak_apple_20261027`（11:24 苹果风重构前）rrPath 出现 0 次** ——
是那次重构引入的调用，漏了定义。也就是说这功能从 11:24 起一直是坏的，
用户所以才会问「能不能加节点名字」（他从未见过）。

**为什么四次检查都没抓到**：`node --check` 只看语法；模块加载也不执行函数体。
`drawChart` 的 `try/catch` 把运行时错误也吃了 —— 三处防线全是哑的。

**修复**：
1. 补 `rrPath(ctx,x,y,w,h,r)`：标准圆角矩形路径，`r` 收敛到不超过半宽/半高，自带 `beginPath`。
2. 色带对比度 `.028/.060 → .035/.085`（曲线自带 `.20` 渐变压在上面，3% 色差看不出来），悬停 `.105 → .16`。
3. 分段竖线从色带层（被渐变盖住）移到标签层（最上层），`STAGE_LINE.node` `.13 → .18`，坐标 `Math.round(x)+.5` 对齐像素。

**新增验证手段**：`_selftest_out/selftest_render.js` —— 伪造 window/document/canvas 跑**真实 `drawChart`**，
统计 `fillRect` / `fillText` / `stroke` 调用并捕获被 try/catch 吞掉的异常。5 项断言：
无异常、色带矩形 ≥3、两档明暗都在、节点名文字有画、节点竖线 3 条。
**以后凡改这个面板的绘制，必须跑它**（这是唯一能抓到"只在真调用时炸"的手段）。

### 17:10 标签发糊 + 容量天花板

**发糊四个原因，一起修**：
1. `10px` 中文在 Windows 上必糊 → 提到 `11px`。
2. 基线 `baseY + 9.6` 是**亚像素** → 中文抗锯齿发虚，改成 `Math.round(baseY + LABEL_H/2)` + `textBaseline="middle"`。
3. 字体栈以 `-apple-system` 打头，Windows 上无效 → 改 `'Microsoft YaHei','PingFang SC','Segoe UI'`。
4. `STAGE_BG.node` 是 `rgba(255,255,255,.10)` 白胶囊，**压在色带上和背景分不开** →
   改深底亮字 `rgba(24,24,26,.78)` + 文字 `.97`。标签高度 13→16，`padT` 37→43。

**分段线加强**：`STAGE_LINE.node` `.18 → .26`；色带两档拉开到 `.03 / .10`（差 7%）。

**容量天花板（物理限制，不是 bug）**：`plotW = 宽 - 68`。默认 380 宽 → 312px，
11px 中文 4 字标签约 53px → 每行 5 个、两行约 **10 个**。节点超过这个数，标签按出现顺序
贪心分配，放不下的**只留竖线不留名**。拉到 700 宽约能放 22 个。要「全部节点带数值」，
靠加宽解决不了，需要明细表（未做，待用户选）。

### 17:20 🔴 节点识别错：取了 `display_node` 而不是 `node`

**用户判断**：「不是物理限制，是没识别到运行的节点」—— 对。容量分析只是表象。

**根因**：`hExec` 里 `id = detail.display_node || detail.node`。`display_node` 指向
**子图/组的外层节点**，用它会把子图内所有节点压成同一个名字，观感就是「很多节点没识别到」。
对照 `js/banzhang_dev_utils.js:560` 的既有实现：
`const nodeId = (detail && typeof detail === "object") ? detail.node : detail;` —— **只用 `node`**。

**修复**：
1. `id = d.node ?? d.display_node`（node 优先）。
2. 图上查不到时**不再退化成「未知节点」**，显示 `#id` + 控制台打 `id → 名字 (图上找不到)`，
   能识别但查不到 和 完全没识别 必须区分开。
3. 子图内部节点在顶层图查不到时，才用 `display_node` 兜底拿外层名。

**自检新增断言**：`handlers.executing({detail:{node:"7", display_node:"99"}})` 必须解析到
节点 7（`KSampler` → `采样器`），解析到 99 即失败。6 项全过。

### 17:30 曲线延时：1 秒轮询 → 0.4 秒 + 增量拉取

**归因**：不是采样成本。后端 `pynvml`（NVML 驱动 API，微秒级）+ `psutil`，一次采样几乎免费。
延迟全在**前端 `POLL_MS = 1000`**：采样发生在请求到达后端那一刻，显示的是最多 1 秒前的数据。

| 文件 | 改动 |
|---|---|
| `banzhang_mem_graph.py` | `_历史` `maxlen 1800 → 4500`（0.4 秒一点仍覆盖 30 分钟）；接口支持 `?since=` 只回增量，返回体加 `full` 标记 |
| `js/banzhang_mem_graph.js` | `POLL_MS 1000 → 400`；轮询带 `since`（最后一点时间），按 `full` 决定整体替换还是追加；浏览器侧上限 4600 点 |

**为什么必须同时做增量**：0.4 秒问一次、每次回全量 = 每 0.4 秒搬 30 分钟历史（几千点），
JSON 序列化和传输都白烧，越跑越卡。只回新点是这个改动成立的前提。

**全量回退条件**：`since<=0`（首次）、`_历史` 为空、或最老点比 `since` 还新（后端重启/清空）
→ 自动回全量并让前端整体替换，不会出现曲线断裂。

**注意**：改了 `.py`，**必须完全重启 ComfyUI**（`Ctrl+F5` 不够）。

### 17:40 🔁 节点名改中文竖排：不再丢任何一个

**用户否掉了容量说法**：「不需要简化显示，把很多节点都过滤掉了」。对——把节点名丢掉是设计错误，
不是应该接受的限制。

**换布局**：横排的本质问题是**每个标签要 53px**（11px 中文 4 字 + padding），312px 两行最多
10 个；竖排（逐字正排，**字不旋转**）每个标签只要 **12px 宽**，26 个才 312px，字数只吃高度
（200px 够 15 字）。同一个空间能放 2.6 倍的节点，且不再需要 `fitText` 裁剪。

| 改动 | 说明 |
|---|---|
| 删 `fitText` / `rowY` / `rowEnd` / `LABEL_MAXW` | 裁剪与丢弃逻辑整体移除 |
| 新增竖排绘制 | 色带内逐字 `fillText`，`字距 12`，暗影 `shadowBlur 2` 把曲线推开保证可读 |
| 窄段处理 | `cx = max(cx, lastCx + 字距)` 依次右移，宁可偏离段中心也不让两个字重叠 |
| `padT` 43 → 22 | 节点名不再占顶部轨道，曲线区从 179 恢复到 **200px** |
| 顶部单行胶囊 | 只留给「净化/开始/完成/错误」这几个标记（数量少，不会挤） |

**密度测试（新增，最关键的一条）**：造 24 个节点段 → 断言**竖线 24 条 + 所有名字字符全部画出**。
横排方案在同样密度下只出 10 个。8 项全过。

**性能反而更好**：30 分钟窗口 4500 点，`2.51 ms → 1.70 ms/次`（去掉了 measureText 裁剪循环
和每个标签的圆角矩形路径，换成逐字 fillText）。

### 17:50 时间窗：分段按钮 → 对数无极滑块

**需求**：顶部时间范围要能无极调节。

| 位置 | 改动 |
|---|---|
| `banzhang_mem_graph.py` `INPUT_TYPES` | `时间窗` 从 4 档枚举 → `FLOAT`（30~1800 秒，默认 300） |
| `js` 常量 | `WIN_SEC` 表 → `WIN_MIN/WIN_MAX` + `滑到秒/秒到滑`（**对数映射**） |
| `js` 头部 | 删 `.bz-am-seg` 按钮组与时钟图标，换 `<input type=range>` + 读数；新增 `.bz-am-slider` / `.bz-am-win` 样式 |
| `js` `syncSeg` | → `syncSlider`（按秒数反推滑块位置） |

**为什么必须对数**：线性 30s~1800s 时，1~5 分钟只占轨道的 13%，最常用的短窗口段落拖不准；
对数下 5 分钟落在 56% 位置，两端都拖得动。滑块 0~1000 一格 ≈ 短端 0.34 秒 / 长端 3.4 秒。

**旧工作流兼容**（关键，不然会存进 NaN）：老档位存的是 `"5 分钟"` 字符串 →
`winSecOf()` 读时兜底换算，`onConfigure` 读档后**立刻写回秒数**（否则保存时又写回字符串）。

**拖动实时重绘**，不节流：4500 点时一次 1.7ms，人手拖拽根本压不满。

### 18:00 横排标签回归 + 零占用节点过滤

**需求**：字改回带色带的横排；自动过滤显存/内存没变化的节点。

**⚠️ 本次发现文件被另一处改动动过**：`平坦段()`（`:520`）、`下界()`（二分查找 `:509`）、
`buildBands(st, nowSec, pts)` 与「全滤空则退化为不过滤」的兜底（`:291-292`），
以及自检里的「过滤」和「竖排」两条断言 —— **都不是本会话写的**。已核对实现无冲突、并入本次结果。

| 改动 | 说明 |
|---|---|
| 标签 | 竖排 → 横排两行胶囊（11px / 深底亮字 / 整数基线），`padT` 回到 43 |
| 过滤 | 沿用既有 `平坦段()`：段内显存与内存的 min/max 差都 <16MB → 整段不画（色带+标签都不画） |
| 兜底 | 全被过滤时 `buildBands(st, nowT, null)` 退化为不过滤，避免空图 |

**过滤判据的边界**（重要）：它看的是**段内波动**，不是「段首 vs 段尾」。
KSampler 这类段内每一步都有激活张量波动，不会被误杀；真正的纯 CPU 路由/文本节点段内恒定 → 过滤。
如果将来发现「显存跳上去后整段持平」的节点被误杀，才需要改成「段内相对段前基线的偏移」。

**自检 9 项全过**，其中密度测试改为贴近真实：24 段里只有 6 段段内有 500MB 起伏 →
必须只剩 6 条竖线、且这 6 段全部出标签。

### 18:10 修「名字下面的竖线错位」

**根因**（`:411` 一行）：`if (tx + boxW > padL + plotW) tx = Math.round(x - 3 - boxW);`
——胶囊从竖线右侧起笔，若右边放不下就**整体翻到竖线左边**。截图里最右那两个节点
（H3 终极放大 / 视频合并）正是触发这条，名字被甩到前一段头上，看起来就是线错位。

**修法**：**永不翻边**。起点固定 `tx = x + 3`，右边空间不够就按剩余空间缩字
（`fitText(text, 可用)`），实在连一个字塞不下（`可用 < 12`）才不画。
允许胶囊轻微压进右侧刻度区（那里上方本来就是空的）。

**回归断言**：造一个贴右边界的长名字段（`H3 终极放大参数面板`），断言胶囊起点必须 > 竖线起点。
10 项全过。

### 18:58 修「零占用节点仍然显示名字」

**根因**：`平坦段()` 用「段内 min/max 波动」判定，且内存阈值只有 16MB。
`ram_used` 是**整机内存**，Windows 上永远在几十 MB 上下抖 → 几乎每一段都超过阈值 →
**这个过滤从上线起就没真正生效过**，所以零占用节点照样出名字。

**修法**：
| 指标 | 判据 | 阈值 | 理由 |
|---|---|---|---|
| 显存 | 段内**波动**（max-min） | 32 MB | NVML 读数稳定，有起伏就是真分配过（VAE 临时分配后释放也算） |
| 内存 | 段首尾**净变化** | 256 MB | 整机内存天然抖动，波动不可信；净变化才代表真占用 |

短段（比 0.4 秒采样间隔还快、段内不到 2 个点）改用「段前一点 vs 段后一点」估这期间的起伏。

**删掉兜底**：原来有「全部被过滤就退回不过滤」，会把零占用节点又塞回来，与需求直接冲突。
一个不剩就空着 —— 空图是真实结果，不是 bug。

**新增断言**：显存全平 + 内存抖 ±80MB 的段必须判定零占用（旧判据会误判成有占用）。11 项全过。

### 20:10 「延迟严重 + 占用非零的节点也不显示」

用户同时报两条：① 曲线延迟严重；② 内存和显存占用非零的节点也不显示。
这**同时解释了上一轮报的三个「节点没出现」**（🎞️ H3 导演台 / 🎬 H3 VAE 快速解码 /
VAE解码（音频））—— 不是注册 / object_info 的问题，是过滤判据把它们吃了。

#### ② 根因：拿「显存没变化」判「没占用」是错的

**PyTorch 缓存分配器只向驱动申请、用完不归还**，NVML 读到的 `used` 是一条
**只涨不跌的高水位线**。采样器把 9GB 占满时，读数恰好是最平的一段 ——
判据一看到「平」就把它当零占用滤掉了。用户眼里「我明明占着 9GB，你却不显示我」。

**修法**：四路信号全无动静才算空转，任意一路有动静就显示。

| # | 信号 | 判据 | 阈值 | 为什么必须有它 |
|---|---|---|---|---|
| ① | 显存 | 段内起伏 | 8 MB | 涨=真分配过，跌=真释放过 |
| ② | 内存 | 首尾**净变化** | 128 MB | 整机内存天然抖，只能看净变化 |
| ③ | GPU 利用率 | 段内峰值 | ≥5% | **关键**：跑在显卡上的活，利用率骗不了人；采样/VAE 60~100%，路由节点 0 |
| ④ | 段长 | 时长 | ≥0.5s | 够长的段再平也在干活；没信号的短段才可能是纯路由 |

另加一条硬规则：**`end == null`（正在跑的那一段）永远显示**。
刚起步还没采到样时四路信号全是零，按判据会被当空转 —— 用户看到就是「这节点又没出现」。

阈值方向提醒：`if (t1-t0 >= 空转_时长) return false` 里 **return false = 显示**，
所以**阈值越小越宽松**。从 0.8 调到 0.5 是往「多显示」方向走。

#### ① 根因：两个独立的放大器

- **A. 老后端 × 增量 concat = 点数爆炸**。`full` 字段缺失（没重启 ComfyUI，跑的还是
  不支持 `since` 的老 .py）时，旧代码走 `concat` 分支：老后端每次回全量 1800 点，
  0.4 秒叠一次 → 一分钟后画布上几十万点 → `all.filter()` 每帧扫几十万 → 整个界面被拖垮。
  这是「延迟严重」的头号成因。修：**`data.full == null` 一律按全量替换**。
- **B. mousemove 同步重画**。鼠标在面板上划一秒上百个 mousemove，每个都同步
  `drawChart` 几千个点。修：新增 `scheduleDraw()` 合帧（一帧最多真画一次）。

另：`POLL_MS` 400 → 250；请求加 2 秒 `AbortController` 硬超时（挂死会把 `inflight`
永久锁住、曲线直接冻住）；后端 deque 4500 → 7200（0.25s × 7200 = 30 分钟），
前端上限 4600 → 7400。

#### `scheduleDraw` 的一个坑

不能存 `requestAnimationFrame` 的返回值：某些环境（含单测）里 rAF 是同步回调，
`st._raf = rAF(cb)` 会先把 `_raf` 置 0、再把返回值 1 赋回去 → 永远是真值 →
第二次之后就再也画不动了。**用布尔标记，不存 id**。

#### 诊断出口

控制台跑 `bzAmDumpStages()`，逐段打印 时长 / 显存起伏 / 内存净变 / GPU 峰值 / 采样点数
和「显示还是过滤」。节点该不该显示这类问题先跑这个看数值，别靠推理。

#### 自检

- `selftest_render.js` 17 项：新增「显存全平但 GPU 满载的采样器必须显示」（本次回归）、
  「老后端无 full → 替换不叠加」「增量只收严格晚于末点的（重复时间戳不叠）」。
- `selftest_stageband.js` 14 项：新增「执行中的段不判空转」「已收尾的同类段照常过滤」；
  四个阈值用 `grabConst` 从源码抠，不在测试里另抄一份。
- 基准（7200 点 / 30 分钟窗口）：**2.66 ms/次**；4 次/秒 = 1.06% 单核；
  1 分钟窗口 0.13 ms/次 = 0.05% 单核。

### 20:10 回滚「零占用过滤」—— 指标过滤这个方向就是错的

用户：**「还是把很多节点都过滤掉了」**。连续第三次在阈值上调，方向本身错了，停下换思路。

**根本结论**：
1. **想过滤的「零占用节点」本来就不存在**。Note / Reroute / Primitive 这类纯展示/路由节点
   **根本不触发 `executing` 事件**（后端 API 里就没有它们，Reroute 是纯前端转发），
   所以它们从第一天起就没进过 `stages`。过滤一直在误杀真节点，却从没拦住该拦的。
2. **「显存/内存没变化 = 没占用」是结构性错判**：PyTorch 缓存分配器只向驱动申请、用完不归还，
   NVML `used` 只涨不跌 —— 采样器占满 9GB 时读数最平；而 0.25 秒采样粒度又抓不到
   <0.25s 节点的 GPU 峰值。**任何指标阈值都必然误杀**，调参救不了。

**修法（从根上）**：`buildBands` 移除全部指标过滤，**执行过的节点一律显示**。
删掉 `空转段` + 四个阈值常量；保留 `段内量` 供 `bzAmDumpStages` 诊断。

**教训**：连续三次（16MB→32/256→四路信号）都在"怎么判零占用"上打转，实际该问的是
"零占用节点到底进没进 stages"。**先确认过滤对象是否真实存在，再设计过滤** ——
对象不存在，任何过滤逻辑都是纯负收益。

自检：`selftest_render` 14 项 + `selftest_stageband` 14 项全过；新增
「24 段全部有竖线（不漏段）」「显存全平 + 空闲小段都显示」「已收尾的段也显示」。

### 21:45 「执行都完成了，曲线一直没更新」—— 采样不该绑在 HTTP 请求上

**两条代码事实拼出根因**：

1. **曲线右边界锚在「最后一个采样点」**：`bands` 循环 `if (x0 > padL + plotW) continue;`、
   标签 `if (x > padL + plotW + 2) continue;` → **任何时间晚于最后一个采样点的节点，
   整段裁到画布外，竖线和名字全不出现**。
2. **采样点是「前端问一次、后端采一个点」**，时间戳 = 请求到达时刻。请求一旦漏掉
   （ComfyUI 执行线程占 GIL、前端 2 秒 abort 砍掉慢请求），**那一刻永久没有采样点**。

两条一叠：请求受阻 → 采样点停在生成开始那刻 → 整个生成过程的节点时间全晚于它 →
**全部落在右边界外，一个都画不出来**。不是慢，是结构上画不到。

**修法**：

| 侧 | 改动 |
|---|---|
| 后端 | 采样挪进 daemon 线程，**0.25 秒定时采**，与请求频率无关；路由只取数据不再采样；`deque` 加锁（迭代期间被 append 会抛 `deque mutated`）；`since` 加 NaN 守卫（NaN 与任何数比较都是 False → 永远回空列表 → 曲线彻底冻住）；**5 分钟没人问才停采**（不取更短：切走标签页前端停轮询，停采太早会留无法补回的空洞） |
| 前端 | 右边界 `nowT = max(最后采样点, 最新阶段时间)`；`AbortController` 超时 2s → 5s（生成期误杀正常请求）；`inflight` 改时间戳兜底（纯布尔一旦没走到 finally 就永久锁死轮询，与「不更新」同症状） |
| 诊断 | `bzAmDumpStages()` 多打印 `since` 与 `inflight` |

**代价**：右边界可能超出最后采样点，曲线右端留一小段空白。这是真实情况，不藏。

**自检**：新增 `_selftest_out/selftest_ticksample.py`（4 项：惰性停采 / 连续采样 /
间隔≈0.25s 无空洞 / 并发读取不抛 deque mutated）；`selftest_render` 新增
「节点阶段晚于最后采样点也画得出来」（修前 1 条竖线、修后 2 条）。合计 33 项全过。

### 21:50 方案 2：拉宽 = 看更长历史 + 修拉宽错位

用户选了「拉宽 = 看更长历史」，同时报「拉宽后曲线和字错位」。

**方案 2 实现**：时间跨度的唯一真值改成**密度（秒/像素）**，存在 `properties._bz_am_density`。

| 动作 | 结果 |
|---|---|
| 拉宽 | 密度不变 → `跨度 = 绘图宽 × 密度` 变长 → 滑块读数跟着走 |
| 拖滑块 | 改密度 → 跨度变（宽度不动） |

两个入口共用**一个**真值。反过来（宽度和滑块各存一份时间范围）必然打架 —— 同帧账
「两个真值」那个教训。密度只在第一次确定（老工作流按当时的窗口和宽度换算并写死），
不写死的话每次兜底都会除以「当前」宽度，拉宽后跨度原地不动 = 等于没做联动。

**错位根因**：`_drawChart` 里 `winSecOf()` 会**再读一次 `canvas.clientWidth`**，
而横轴 `x2px` 用的是函数开头取的 `w`。一帧内两次取宽度，只要有一次拿到布局中途的值，
刻度/标签就和曲线错开（拉宽时最容易撞上，因为宽度正在变）。
修法：跨度和映射都用同一个 `plotW = w - PAD_L - PAD_R` 算，不再二次读宽度。

**自检**（`selftest_render` 19 项）新增：
- 「拉宽后时间跨度按比例变长」（420→1000 约 ×2.6）
- 「宽 420/700/1000：标签全部贴着自己的竖线」（逐宽度验对齐，修前没有这道防线）
- 测试里改窗口的入口从 `node.widgets[0].value` 换成 `设窗口()` helper（写密度），
  否则改 widget 不再生效

### 22:00 竖线/色带与曲线的变化时刻对不上 —— 时间基准不同，不是像素坐标

用户选了错位类型 2：「曲线开始涨的地方，竖线不在那儿」。

**根因**：曲线的 x 轴刻度来自**后端采样点**（采样线程 0.25 秒一个，时间戳 `time.time()`），
而阶段竖线来自**浏览器事件到达时刻**（`Date.now()`，在 `executing` 回调里取）。
事件时刻落在两个采样点之间，曲线在那里还是一条插值直线 → **竖线看着停在"还没涨"的位置**。
窗口越小、面板越宽，这个偏差被放大得越明显：30 秒窗口 / 1000 宽时，半个采样格 = 8px。

**修法**：`吸附(pts, t)` —— 把阶段起点吸到**最近的采样点**上。
我们只能在采样点上观察数据，标记就该落在采样点上；这样竖线跳过的是真实存在的数据点，
而不是"插值出来的一段直线"。吸附后段不会消失（`t1 = max(吸附后起点, t1)`）。

**验证**：`selftest_render` 18 项，新增「竖线踩在采样点上（不卡在两个点中间）」：
故意把采样网格放大到 0.5 秒、阶段起点卡在正中间，断言竖线落在采样点的 x ±1px 内，
且与"未吸附位置"相差 > 3px（证明修复真的生效，不是碰巧）。

**顺带纠正**：上一轮把对齐自检写成 420/700/1000 三个档位，被用户点出「节点宽度又不是这三个
档位」。已改为扫 300~1600（步长 25）+ 20 个伪随机宽度 × 4 档跨度 = 292 组，
共 1511 个标签，0 错位。

## 2026-10-28 ⏱ 参照图替换：替换记录绑段 + 空栏位可直接写入

**症状**（代码审查发现，非真机复现）
1. A 段替换后切到 B 段，圆按钮仍是 ↩；点一下把 A 段记下的原文件写进 B 段同号栏位。
2. 目标栏位为空时按钮禁用，必须先去媒体架塞一张图才能用。
3. 当前段没写参照图行时，`readCoreFrame` 扫全段兜底 —— 改的是别的段的栏位，
   界面却仍显示当前段名，看不出改错了。

**根因**：`replaced / index / origFile` 三个字段假设「用户不会在两段之间切换」，
缺「哪一段」这一维；空栏位被当成"不可替换"；跨段认栏没有来源标记。

**定调（用户 2026-10-28 明确）**：**跨段要自由，不许拦**。所以修法是「按记录段写回」，
不是「段不匹配就拒绝」——拦人等于把正确性成本丢给用户。

**改法**（`js/csglide_tailref.js` + `csglide_tailref.py`）

| 点 | 做法 |
|---|---|
| 绑段 | 状态记 `segWrite`（媒体架实际被写的段）/ `segName`（回执用）；还原**按记录段写回**：同段双写 slots+segs，跨段只写 `segs[segWrite]`，不碰全局 slots（那是当前段视图，改了眼前会变色）。跨段还原给 4.5 秒回执「已还原「X」第 N 栏（不在这一段，切回去才看得见）」 |
| 空栏位 | `paintTarget` 对「栏位存在但没文件」返回 true，右卡显示「空栏位 · 可直接写入源帧」；`hadOrig=false` 让还原＝清空，不当成记录丢失 |
| 认栏 | 当前段优先；认不出就跨段找，找到就用，`current=false` 让右卡标「（来自别段）」。只有**同段内多条编号对照**仍报错——猜错会把主角槽换成尾帧 |
| 还原解耦 | `restore()` 改读媒体架（`rackData()`），文案台被删 / 没选中段也能还原 |
| 按钮 | 已替换时不再要求「取过片」——还原与源片无关（旧写法刷新后会变成点不动且无原因） |
| 胶片条 | `/sprite` 请求宽度乘 DPR（夹 24~400），高分屏不再糊 |
| 磁盘缓存 | 每 200 次写盘清一次 `h3_tailref_cache`，保留 600 份；**不碰 h3_proxy**（共用代理片，删了别的节点要重转） |
| 注释 | `_grab` 无 PTS 时实际取首帧，注释原写「最后一帧」，按实现改正 |

**新增自测** `tests/js/_selftest_tailref_seg.mjs`（26 项，从源码抠 `readCoreFrame` 跑）：
当前段命中 / 当前段无行跨段认并标来源 / 当前段优先于扫段顺序 / 未选中段唯一命中 /
未选中段多命中取第一 / 同段多候选报错 / 定义式优先 + 7 条编译期残留断言
（跨段拦截不许回来、跨段只写快照、旧提示语不许回来）。

**已验证**：`node --check`、`py_compile`、`_selftest_pycompat.py`（23 通过 / 0 失败）、
新用例 26/26、全量 25 通过 / 1 失败。失败项 `_selftest_sort_vacate.mjs`「toast 明说了已腾空」
与本次无关：该用例不引用 tailref，被测的 `csglide_rack_sort.js` 是 10-26 改的。
**备份**：`js/csglide_tailref.js.bak_seg_20261028`、`csglide_tailref.py.bak_seg_20261028`。

## 2026-10-29 ⏱ 参照图替换：三条必做（端口栏位 / 选片列表 / 落盘带栏号）

**① 端口栏位替换是假成功**
媒体架与文案台共用 `st.slots`，文案台槽位带 `wired`（界面「🔗 端口」），
`csglide_cast_slots.js:434` 每次同步强写 `slot.file = 端口值`。原实现只在媒体架侧改
file → 界面显示「已替换」，一运行用的还是端口里那张图，全程无异常。
修法：**不改连线状态**（那是用户的意图），右卡角标改「端口」+ 状态行红字警告；
替换时同时写 `slot.manualFile`（拆线后落的是本次尾帧，不是更早那张手动图）；
成功回执说明「同步后会被覆盖」。还原时 `wired` 槽位同样回写 `manualFile`。

**② 只能取最新一部片**
后端 `/cglide/recent_outputs` 本来就支持 `limit=50`，前端写死 `limit=1`。
修法：点「选取成片」在标题行下弹最近 10 条（名称 + 时间），当前在用的高亮；
capture 阶段监听点外部收起（胶片条 `pointerdown` 会 stopPropagation，冒泡阶段收不到）。

**③ 一段两栏互相覆盖**
落盘固定 `tail_ref.png`，同段 `@图片25` 与 `@图片31` 都替换时写同一个文件，两栏永远同图。
修法：`_tail_name(slot)` → `tail_ref_<栏号>.png`；旧存档指向的 `tail_ref.png` 仍可读、可还原。

**已验证**：`node --check`、`py_compile`、`_selftest_tailref_seg.mjs` 35/35、
全量 25 通过 / 1 失败（`sort_vacate` 既有失败，与本节点无关）。
**备份**：`js/csglide_tailref.js.bak_need3_20261029`、`js/csglide_tailref.css.js.bak_need3_20261029`、
`csglide_tailref.py.bak_need3_20261029`。

## 2026-10-29 ⏱ 参照图替换：加第二路「开场构图参考」

**需求**：每段提示词独立 → 段间画面不连贯。除了给「空间关系参照图」换尾帧，还要再提一帧
给本段**开头**当参照（告诉模型上个镜头里主体在哪）。

**落点定为 `@图片M` 参照图槽，不是 `@first`**：`@first/@last` 走导演台面板、与媒体架无关，
且 **fl2va 之外不参与生成**（`csglide_cast_view.js:197`「多参考模式下不参与」）。

**设计**（用户选：命名「开场构图参考」+ 切标签自动建栏）
- 状态从一档变两档：`st.tg = { core, open }`，每路独立 `{frame,index,alias,file,origFile,
  replaced,hadOrig,segWrite,segName}`。时间轴只有一条，`st.frame` 是它的当前帧，
  切标签时存旧路、恢复新路（`setCur`）；选帧同时更新本路记录；换片两路帧号作废。
- UI：胶片条下方加两个标签（空间关系参照图 / 开场构图），复用同一套取片与选帧。
- 认栏：开场构图**只认自己的名词**，不走「定义为…图／帧」兜底、不认编号对照 ——
  那两条会把别人的参照图当成开场帧。**也不跨段**（建栏要落在明确的一段上）。
- 自动建栏：媒体架末尾 `push({})`（与手动「＋ 添加」同写法），栏号 = 追加后长度、
  **永不写死**；再把 `将 @图片N 定义为本段的开场构图参考（承接上一段的收尾画面）`
  插到核心帧那一行的**下一行**（找不到核心帧行就插段首）。

**两个必须知道的坑**
1. **文案台没有对外写段词的 API**（`deskUI` 只暴露读 `segWords` / 整段复制 `copySeg`）。
   只改 `desk_data` widget 无效 —— 它内部 `st.segs` 是闭包状态，下次收口会把新行盖掉。
   写完必须 `desk.onConfigure?.({})`：这正是刷新网页走的那条路，能让它从存档重载。
2. **建完要立刻复认，认不到就撤回**（`images.pop()`）并锁 `openFailed`。
   不撤的话「认不到」会被每次重绘当成「还没建」，空栏一栏一栏往上堆。

**已验证**：`node --check` ×2、新用例 55/55、全量 25 通过 / 1 失败（`sort_vacate` 既有）。
**备份**：`js/csglide_tailref.js.bak_open_20261029`、`js/csglide_tailref.css.js.bak_open_20261029`。
**未动 `.py`** → 只需 Ctrl+F5，不用重启。

### 修 bug：「媒体架第 undefined 栏不存在」

**现象**：点「开场构图」→ 点中间圆按钮 → 状态行报「媒体架第 undefined 栏不存在」。

**根因**：开场构图这一路把**定位绑在了文案行上**。`readCoreFrame("open")` 认不到
「开场构图参考」那一行时返回 `{missing:true}`（没有 index），而按钮点击路径没处理
`need` 分支，直接拿 `t.core.index` 拼提示 → undefined。认不到的原因不止一种：
段落同步把行冲掉、用户删了那行、或点按钮前文案台切了段。

**修法**（不拦操作，只修定位）
1. 建栏时把栏号记进 `st.tg.open.index`（随工作流存档）—— **行会丢，栏不会**。
2. `targetState("open")` 在 missing 时用记下的栏号继续，并标 `noLine`：
   替换/还原照常可用，状态行提示「文案里缺「开场构图参考」那一行 —— 模型看不到这张图」。
3. 点击路径先拦 `t.need`，给明确提示，不再拼出 undefined。
4. 回滚建栏时把 index 一起清零。

**判据**：凡是"自动生成一条说明 + 靠它反查对象"的功能，都要把**对象标识**单独存一份，
说明只当说明。否则说明一丢，功能整条断掉。

### 二修：文案台那一行写不进去 + 还原后不联动

**现象**：媒体架多了一栏也有图，但文案台没有「开场构图参考」那一行；点 ↩ 还原后
媒体架/文案台画面不跟着变。

**文案写不进去的真因（两层）**
1. 文案台的段词权威在闭包变量 `st.segs`，不是 `desk_data` widget。只改 widget 它看不见。
2. 更狠的是 `switchSeg` 第 911 行：`st.segs[curKey] = edSeg.getText()` —— 它拿**编辑框里的
   旧文本**反盖回 `st.segs` 并推中央。所以任何"只改数据不改编辑框"的写法，下一次切段/收口
   就被原样盖掉。这也解释了为什么先前的 `onConfigure({})` 无效。

**修法**：`writeDeskSeg` 改成两层都写 —— ① `desk_data` widget；② 段词编辑框
（`.gcast-ed.d-seg` 的 `textContent` + 派发 `input`），让文案台自己的 `onChange` 走完
「写 st → pushSegText 推中央 → commit」。编辑框显示的不是目标段就不动它，避免写错段。

**已建栏的补救**：`ensureOpenLine()` 在 `paintTarget` 发现 `noLine` 时补写一次，
去重键 = `段:栏`，同一处只补一次，不跟着重绘反复改文案。

**还原不联动的修法**：`rebuildMediaRackUI` 之外补 `app.graph.setDirtyCanvas(true,true)`
—— 只重建面板时，节点缩略图/画布缓存停在旧画面，看上去像没还原。

**已验证**：`node --check`、新用例 61/61、全量 25 通过 / 1 失败（既有）。

### 三修：替换/还原后媒体架不刷新（根因是调了个空函数）

**现象**：点替换 → 媒体架那格不变，刷新网页才出现；点 ↩ → 媒体架/文案台都不回退。

**根因**：`rebuildMediaRackUI()` 是**热重建（HMR）专用**，且新版 bag 直接
`if (node.gmr.BAG_VERSION === BZ_BAG_VERSION && node.gmr.st.segs) return true;`
—— 什么都不做。我一直在用它当"刷新"。
更底层的错：媒体架的真实状态在 `node.gmr.st`（活对象），`rack_data` 只是它的序列化镜像。
只改镜像 → 内部 `st` 还是旧的 → 面板不重绘、`commit` 也没被触发。

**修法**：`rackData()` 优先取 `rack.gmr.st`；所有写入改为「改活对象 → `gmr.commit()`」。
`commit` 一次做完：snapshot 到 `segs[cur]`、写回 `rack_data`、重渲染面板、广播事件。
没有 `gmr` 的老 bag 才退回写镜像 + 手动广播。

**顺带修的两处**
- **空槽复用**：架子里常堆着一串没用过的空位（实测 49 个槽、最后一格有图的才 33）。
  继续往后追加会让新栏飘到第 50 格，用户既找不到也像跳号。改为**优先复用第一个空槽**，
  没有空槽才追加。
- **滚动定位**：从"滚到最后一格"改成"滚到目标栏那一格"。

**判据**：对接别人的面板节点时，先分清「活状态」「序列化镜像」「重渲染入口」三者。
只改镜像，界面永远不会动；`rebuild*` 这类函数先看它有没有"已是新版就直接返回"的短路。

### 四修：commit 不重绘网格，renderImages 也没对外暴露

改完上一轮还是"还原没反应"。再读 `ui.commit()`（146-193 行）：它只做
① 写 `rack_data` 镜像 ② `schedulePaint()`（**画布**重绘）③ 广播 —— **不重绘图片网格**。
网格渲染是 `ui.renderImages`（installImages 挂的），而它**没在 `node.gmr` 返回对象上**，
外部拿不到（与 loadSeg/copySeg 当年"漏挂变静默失败"同一类）。

**修法**
1. `csglide_media_rack.js` 返回对象补 `renderImages: ui.renderImages`。
2. `commitRack()` 改成**先 `renderImages()` 再 `commit()`**（顺序固定：commit 会把 st 写进
   widget，画面得先跟上）。
3. `restore()` 开头加诊断日志：路 / 是否已替换 / 栏号 / 原文件 / 段。

### 五修：文案台还是没那一行（只改本地，被「段词对账」盖回）

用户给的日志证明了替换/还原都执行成功（`还原 open 路 第 20 栏：(空) → (空)`），
所以不是数据问题。日志里 `[B1] 段词对账: clip_0001 中央=1991字 本地=1991字` 是线索：
**文案台每次都拿中央档案跟本地对账**，只改本地的话，下一次对账就用中央的旧词把
这一行盖回去 —— 表现恰好是「媒体架有图、文案台没变」。

**修法**：写文案改成三处全写（少一处就被另一处盖掉）
1. `desk_data`（存档 / 运行 / 刷新后都读它）
2. 段词编辑框（内部 `st.segs` 是闭包，且 `switchSeg` 会拿编辑框旧文本反盖）
3. `pushSegText(片名, cid, 文本)` 推中央 —— 走文案台 `onSegChange` 用的那条通道；
   片名取 `castProject(desk).name || chain.name`，与它自己的 `projName()` 同口径。

推完打日志：`写入文案：段=clip_0001 中央=已更新（片名=xxx 编辑框=true）`。
`中央=未落库` 就说明工程没进中央模式（会退化成"只能手动加那一行"）。

---

## 2026-10-28 16:20 🧠 SLA：缺 triton 不该连官方内核一起废掉（其他用户的加速可用性）

**症状（来自其他用户，非本机）**：控制台 `ModuleNotFoundError: No module named 'triton'`，
SLA 节点静默降级成全程不加速。

**根因**：`sla/kernel.py` / `sla/block_map.py` 顶层 `import triton`，`sla/patch.py`
顶层 `from .block_map / .kernel import ...`，`sla/__init__.py` 顶层 `from .patch import`。
→ 缺 triton 时**整个 SLA 包 import 失败**，节点 `except Exception` 兜底后原样返回模型。
而真正快的两档（官方块级替换 / 官方注意力覆盖）用的是 `comfy-kitchen` 的编译内核
（`backends/cuda/_C.abi3.pyd`），**根本不需要 triton**，却一起被判死。
`triton` 只是第三档兜底。

**关键事实**：`comfy-kitchen==0.2.39` 是 ComfyUI 0.42.0 官方 `requirements.txt` 依赖；
`comfy_kitchen/backends/triton/__init__.py` 用 `try/except` 包着 → 缺 triton 时 ck 仍可导入、
`sol_attn_is_available()` 仍为 True（本机实测）。sol_attn 要求 sm_80+，3060(sm_86) 支持。

**改法**

| 文件 | 改动 |
|---|---|
| `sla/patch.py` | `block_map`/`kernel` 改 try/except 可选导入，`_TRITON_OK` 标记；**非 triton 的 ImportError 照旧抛出**（不吞自身 bug） |
| `sla/patch.py` | 覆写路 else 分支加 `block_sparse_attention is None` 判空 → `dense("没装 triton，且官方内核不可用")`，否则每次调用 TypeError 刷满"内核报错" |
| `sla/patch.py` | 块级替换挂载条件加 `hasattr(ck, "sol_attn_chunked")`（老 ck 退回覆写路，不在采样中途炸） |
| `sla/patch.py` | 新增 `engine_status()`：一句话报本机档位；`patch_h3_sla` 结尾日志按**实际引擎**命名（原来两条覆盖路都写"注意力覆盖"，看不出快慢） |
| `banzhang_sla_attention.py` | 挂载前打一行档位；失败时 `log.warning` 一句话 + 三条常见原因，完整堆栈降级到 debug（原来 `log.exception` 把用户吓成"节点坏了"） |

**新增自测** `_selftest_sla_notriton.py`：导入拦截器只让 triton 报"模块不存在"，
断言 `import sla` 成功 / `_TRITON_OK=False` / 两符号置空 / ck 可导入 / 档位非"无法加速"。

**已验证**：`py_compile`、`_selftest_pycompat.py`（23 通过 / 0 失败）、
无 triton 模拟 7/7 通过、有 triton 回归 `_TRITON_OK=True` 且 kernel 可调用。
**备份**：`sla/patch.py.bak_notriton_20261028`、`banzhang_sla_attention.py.bak_notriton_20261028`。
**待真机**：那台无 triton 的 3060 上重跑，日志应出现「已挂上加速：官方分片内核（N 个块…）」。

## 2026-10-28 🔌 万能包裹符解析器支持中文包裹符

**报障**：清单写 `<<<歌名>>>*<<<歌名结束>>>`（6 行）后点刷新，端口一个都不出。

**根因**：字段名与结束标记三处写死 ASCII ——
后端 `_WRAPPER_PATTERNS['triangle']` 名类 `[A-Za-z0-9_]+`、结束只认 `\1_END`；
`_FIELD_LINE_MARKERS` 与 `_FIELD_NAME_VALID`（`^[A-Z0-9]`）同样；前端 `js/banzhang_wrapper_parser.js`
里 `FIELD_MARKERS`/`FIELD_VALID` 是**另一套并行实现**，必须同步。中文行全判非法 →
`dropped=6`、`fields=[]` → `syncPorts` 无字段可渲染（只弹一条 toast）。

**改动**
- `banzhang_text_tools.py`：字段名类改 `[A-Za-z0-9_\u4e00-\u9fa5]`；三角结束标记
  `(?:_END|结束)`（英文老模板 `<<<NAME_VALUE>>>…<<<NAME_VALUE_END>>>` 照旧）；
  `_FIELD_NAME_VALID` 改双分支并限长（中文 ≤12 字），`_extract_wrapped_fields` 里对
  归一化后的名字同样校验 —— 否则中文长句被包进包裹符会长出乱端口。
- `js/banzhang_wrapper_parser.js`：同款正则（`FIELD_MARKERS` / `FIELD_VALID`）。

**已验证**：后端清单解析出 `['歌名','时长','速度','调式','语义蓝图','演绎脚本']`、中文正文解包
顺序正确、英文老模板仍出 `TITLE/DURATION`、16 字长句被拒；前端同款正则产出同样 6 个端口；
`py_compile` / `node --check` / `_selftest_pycompat`（23 通过 0 失败）。
**备份**：`banzhang_text_tools.py.bak_cnfield_20261028`、`js/banzhang_wrapper_parser.js.bak_cnfield_20261028`。
**注意**：改字段清单＝改端口名，旧连线按槽位保留，顺序一变就整排错位，必须逐根重接。
**待真机**：重启 ComfyUI + Ctrl+F5，点「刷新端口」应出现 6 个中文端口。

## 2026-10-29 ⏱ 参照图替换：还原时撤回「开场构图」文案行

**报障**：开场构图路替换后点 ↩ 还原，媒体架第 20 栏已清空，但文案台那行
「将 @图片20 定义为本段的开场构图参考（承接上一段的收尾画面）」还在 → 指向空槽的假声明
（提示词说有参考图，模型实际拿到空）。日志：`还原请求：路=open 已替换=true 第 20 栏 原=(空) 段=clip_0001`。

**根因**：`restore()` 只回退媒体架 `file`，从不碰文案台文字。删行也不是"加一行代码"就能收工 ——
`paintTarget()` 的自我修复是「open 路没有文案行 = 还没建栏 → 自动建栏 + 写行」，
删掉的行会在同一帧被补回来，表现仍是"点了还原，文案一动没动"。
所以缺的不是删行，而是**「已撤销」这个状态**：没有它，"没有行"和"从未建过"分不开。

**改动**（`js/csglide_tailref.js`）
- `TG_EMPTY` 加 `revoked`（存 `node.properties.bzt`，刷新后仍生效）。
- 新增 `removeOpenLine(text)`：只认 `OPEN_HINTS` 那一族措辞；**核心帧行（空间关系参照图）绝不误删**。
- `targetState("open")`：`core.missing && revoked` → 返回 `{idle:true}`，不再落到 `need`。
- `paintTarget()`：`t.idle` → 右卡「未启用 · 点上方「开场构图」标签重新启用」，按钮禁用，**不建栏**。
- `setCur()`：点标签清 `revoked` + 清 `lineFixKey`（不清去重键，补行会被挡掉）；清标志放在
  `if (next === st.cur) return;` **之前** —— 撤销后用户点的往往就是当前标签。
- `restore()`：`路=open && hadOrig===false` 时删行（替换段与文案台当前段都试一次）+ 标 `revoked`；
  `hadOrig===true`（原来真有图）保留该行，只回退文件。删不掉就不标 `revoked`，避免面板/文案两处说法打架。
- 替换入口加 `t.idle` 兜底，防止复现「第 undefined 栏」那类报错。

**语义定案**：还原 = **整路撤销**（栏清空 + 行删除 + 这一路下线）。重新启用只有一条路：
点「开场构图」标签，按建栏时记的栏号原格复用，不新占一格。

**已验证**：`node --check`、`_selftest_tailref_seg.mjs` 87/87（新增 11 条：删行只删那一行、
核心帧行不误删、无行返回 null、revoked 挡自动重建、清标志在早退之前、去重键作废、hadOrig 分支）；
全量 25 个前端自测仅 `_selftest_sort_vacate.mjs` 25/1（既有无关失败）。
**备份**：`js/csglide_tailref.js.bak_openrevoke_20261029`。
**待真机**：Ctrl+F5 → 开场构图替换 → 点 ↩，预期：媒体架该栏变空 + 文案台那一行消失 +
右卡显示「未启用」；再点「开场构图」标签，那一行按原栏号回来。

---

## 2026-10-29 顶栏「显存 / 内存」胶囊旁加两个净化按钮

**需求**：手动「卸载所有模型」与「清所有内存/缓存」，生成过程中点按钮**直接拦下**（不弹确认）。
**方案**：B —— 轻/重两档，语义不重叠。「清碎片」只回收显存碎片不动模型（零风险）；
「全卸载」卸模型 + 清碎片 + 裁工作集（下次生成要重读权重）。

**改动**
- 新增 `banzhang_purge_api.py`：`POST /banzhang/purge/{cache|all}`。
  只做外壳（模式校验 / 生成中拦截 / 前后读数），真正清理复用
  `banzhang_vram_cleaner.执行深度清理()`，**惰性导入**（cleaner 是本包最重模块之一，第一次点才付 import 代价）。
  清理必须 `asyncio.to_thread` —— 同步跑实测 5~6 秒，会把整个事件循环卡住（全站无响应）。
  生成中判据：`PromptServer.instance.prompt_queue.get_current_queue()` 的 running 非空 → 403 `{"busy": true}`。
  只认 running 不认排队：排队时模型还没加载，卸载是安全的。
- `__init__.py`：第 15.5 段单独 try 导入。**为什么不塞进 `banzhang_vram_reserved.py`** ——
  那个模块顶层没有 `if PromptServer:` 保护，路由注册一旦抛异常，监控线程 + 两个清理节点会一起静默消失
  （本包栽过一次：一行 f-string 让两个节点凭空不见）。单独文件最坏只丢两个按钮。
- `js/banzhang_vram_monitor.js`：胶囊外再包一层 `.bz-mon-wrap`（横向 flex），右侧竖排两个 9px 按钮。
  两个必须同步的细节：① 显示开关的作用对象从 `root` 改为 `shell`，否则关了监控按钮还杵在那；
  ② `addSetting` 的 `onChange` 不会为已存的旧值补发一次，重启后主动 `getSettingValue` 读一遍兜住。
  接口返回 `after` 读数，前端直接 `apply()` 刷新，不等 1.5 秒轮询。

**已验证**：`py_compile`、`node --check`、`_selftest_pycompat.py` 23 通过 / 0 失败、
新增 `_selftest_purge_api.py` 7 通过 / 0 失败（路由注册 / 快照四项 / 未知模式 400 / 生成中 403 / 空闲不误拦）。
**备份**：`__init__.py.bak_purge_20261029`、`js/banzhang_vram_monitor.js.bak_purge_20261029`。
**待真机**：**完全重启** ComfyUI（改了 .py，只刷网页没用）→ 顶栏胶囊右侧应出现「清碎片 / 全卸载」两行小按钮；
点「全卸载」预期胶囊数字立刻掉 + 终端打 `[净化]` 日志；跑图途中点 → 按钮显示「生成中」2 秒且数值不动。

---

## 2026-10-29 收成单个「全卸载」按钮（覆盖上一段的双按钮方案）

**变更**：删掉「清碎片」，只留「全卸载」；`/banzhang/purge/{mode}` → `POST /banzhang/purge`，
一次清到底：节点缓存 → 模型 → 显存碎片 → 进程内存。

**新增节点缓存清理**（`banzhang_vram_cleaner.py`）：`_节点缓存表`（13 项）+ `_release_node_caches()`，
在 `执行深度清理` 的「卸载模型」分支里、`_release_qwen_cache()` 之后调用。
登记项：FlashVSR `_PIPES` / RIFE / EMA / CLIP 编码器 / CLIP 投影 / 学生模型 / 参考图 / 参考音频×2 /
音频VAE尺寸 / 插帧网格 / NVENC / 视频元数据。以后新增带全局缓存的模块，往表里加一行就够。

**为什么必须单独做**：这些全是模块级字典，压根不在 `comfy.model_management` 里，
`unload_all_models()` 看不见它们 —— 这正是「点了净化只掉一点、之后就再也不动」的直接来源。

**两条硬约束（都是"静默失效"级别的坑）**
1. 只碰 `sys.modules` 里**已加载**的模块。没加载过的模块不可能有缓存，为了清它去 import，
   反而会把依赖和模型重新拉起来，纯亏。
2. 取模块用「前缀精确 + 后缀扫描」两层。包被改名或 `__package__` 为空时，光拼前缀会让整张表
   静默清不到，而且日志上一点异常都看不出来。

**已验证**：`py_compile`、`node --check`、`_selftest_pycompat.py` 23 通过 / 0 失败、
`_selftest_purge_api.py` 13 通过 / 0 失败（新增：路由已换名、缓存表里每个模块都有对应 .py、
`执行深度清理` 形参契约、调用处三项都传）；另用临时探针实测 —— 注入 5 条假 RIFE 缓存 →
全部清掉并返回「RIFE 插帧×5」。
**备份**：`banzhang_vram_cleaner.py.bak_nodecache_20261029`、`banzhang_purge_api.py.bak_twoBtn_20261029`、
`js/banzhang_vram_monitor.js.bak_oneBtn_20261029`（双按钮版另存 `.bak_purge_20261029`）。
**待真机**：完全重启 → 胶囊右侧只剩一个「全卸载」；点下去终端应出现
`[净化] 🧩 FlashVSR 管线×N、RIFE 插帧×N…`（真有缓存时才打这行），数值立刻掉。
**注意**：`_release_node_caches` 也进了「🧹 全能系统净化」节点 —— 节点现在同样会把本包缓存清干净。
这是有意的：两处共用一套实现，避免以后漂移。

---

## 2026-10-29 顶栏控件按方案 B 重做视觉（34px 同高 + 三档变色）

**问题**：按钮 16px 对胶囊 33px 不等高；字号 10px 偏小；底色 6% 白几乎看不见轮廓；
`linear-gradient` + `box-shadow` + 金色发光三层叠在一起，缩小后就是一坨糊的金块。

**改动**（只动 `js/banzhang_vram_monitor.js` 的样式与显示逻辑，后端一行没碰）
- 统一 34px 高 / 10px 圆角 / 11px 字号。胶囊 padding 收成 `0 12px`，两行靠 `justify-content:center` 居中。
- **显式 `box-sizing:border-box`**：原来 `min-height:26px + padding 4×2 + border 2` 实际总高 36px，
  新版 34px —— 比原来还矮 2px，顶栏高度风险为零。按钮从 16 → 34px 也不会把顶栏撑高，
  因为 `.bz-mon-wrap` 的高度由最高子元素决定（34 ≤ 36）。
- 进度条 28×4 → 44×5；数值 `min-width:62px + text-align:right`，两行小数点对齐。
- 去掉渐变 / 阴影 / 发光，只留 1px 描边；底色改纯色 `#1A1A1E`。
- 三档变色：<70% 金 `#E0B94F`、≥70% 橙 `#F5A524`、≥阈值（默认 85%）红 `#E5484D` + 轻微呼吸。
  橙档边界跟阈值联动（`阈值 - 15`，且下限 0），改阈值不会留下一个对不上的硬编码 70。
- 按钮 70×34，hover 直接变红底白字 —— 破坏性动作在按下之前就给颜色预警。
- 新增预览页 `_selftest_out/preview_vram_monitor.html`，由同目录 `gen_monitor_preview.py`
  从 JS 里**抽真实 CSS** 生成，8 种状态（正常/橙/红/hover/清理中/已清/折叠/离线）一屏看全。
  以后调样式不必靠脑补，也不必为了看效果重启 ComfyUI。

**已验证**：`node --check`；预览页里确认 CSS 注入完整（31 处 `bz-mon`、`.crit` 规则、hover 红都在）。
**备份**：`js/banzhang_vram_monitor.js.bak_oneBtn_20261029`（本次改动前的单按钮版）。
**待真机**：Ctrl+F5 后看顶栏 —— 胶囊与按钮齐平同高、两行小数点对齐、按钮 hover 变红。

## 2026-10-30 🎯 多级渐进：把 global 系省显存加回来（只给一采用）

用户指出：**「🧠 H3 SLA」没接在一采，而「多级渐进」在一采** —— 所以那条模型链上
没有 SLA 的块级补丁，global 系不会撞协议冲突。要求加回。

### 恢复的内容（`banzhang_selflift.py`）
- 常量：`_HIGHRES_TILING_MODES` / `_GLOBAL_TILING_MODES` / `_TILING_MODE_CHOICES`
- `_coerce_tiling_mode()`：脏值退回 spatial（老工作流错位兜底）
- `_global_tiled_model()`：**新增中文错误翻译** —— 上游只抛
  `ValueError("unsupported H3 block patch")`，现在翻成
  「要求模型链上没有别的块级注意力补丁，检测到 SLA…两个办法：① 改回 spatial ② 挪到没有 SLA 的路」
- `_SelfLiftMultiStage.__init__` 恢复 `tiling_mode / token_chunk / weight_cache_gb /
  _global_cache / _global_patcher()`
- 采样循环恢复运行时 `guider.model_patcher` 替换 + `finally` 还原
- 分块条件恢复 `tiling_mode == "spatial"` 前置（global 系与切块互斥）

### 控件顺序（关键）
```
分段步数 → 级间倍率 → latent放大模型 → 满分辨率分块 → 彩色光点清理力度
        → 省显存模式 → token分块大小 → 权重缓存预算
```
**新三项追加在最后**，老 5 元素存档 1:1 对齐，不用重挑。实测打印确认。

### 没做的事
`高分辨率阶段模型` 没有恢复（用户未要求）。

### 验证
- `py_compile` 通过；`_selftest_pycompat.py` 23 通过 / 0 失败（3.11 与 3.12 都编过 231 文件）
- 整包 import 成功，控件顺序与档位实际打印核对
- **待真机**：重启 + Ctrl+F5，节点尾部应出现三项；选 global_stream 跑一采，
  控制台应有 `[班长SelfLift·多级] 第 N 段：global_stream 省显存`；
  若那条链上其实有 SLA，会报中文错误而不是英文 `unsupported H3 block patch`

## 2026-10-30 13:16 文案台加「提示词改写」（方案一：整段重写 + 硬守门）

**需求**：像图像编辑台那样，用接入的编码器整段改写本段提示词；默认用 MOSS 的 9B CLIP，
用完自动回收显存；输出上限按模型能力自动定，界面不显示参数；系统提示词可自定义，
默认那段负责钉住 H3 的硬结构。

**改动**

| 文件 | 内容 |
|---|---|
| `csglide_cast.py` | 新增可选输入 `rewrite_clip`；`parse_h3_data` 增 `rewrite`/`rewrite_system`；`SEG_KEY_OWNER` 归 `submit`；`build`/`_do_build` 透传；新增 `_rewrite_for_cast` + 两个常量 |
| `js/csglide_desk.js` | `blankState` 增两字段；本段下方加「提示词改写」开关 + 系统提示词输入框；三处 `st` 重建点补 `paintRewrite()` |

**三个默认行为**

1. **系统提示词留空 = 内置 `REWRITE_SYSTEM_DEFAULT`**，它逐条钉住 `<d>…</d>` 台词、
   `[镜N]` 镜号、音效行、`@图片N/@音频N/@视频N` 引用、括号口型说明，只放开
   画面描述/光效/材质/氛围。面板可覆盖。
2. **输出上限固定 2048，界面不显示。** 模型的 32768 是**输入上下文**，不是生成长度；
   设这么大会让模型一直吐到超时。H3 段提示词常在 2000~3000 字，1024 会中途截断，
   截断后守门判镜号/标签数量不符、回落原文，等于白跑一轮。真要更长的段就往上调。
3. **用完自动回收**，复用既有 `_release_clip_when_done`（`banzhang_vram_cleaner.release_model_residency`）。
   只在 `rewrite_clip is not None` 时执行——退回主 clip 时卸掉它会掐死本次出片。

**硬守门（为什么必须有）**：下游 `_filter_refs_by_prompt` 是按提示词里出现的
`@图片N` 来筛参考素材的。改写只要写丢一个引用，那张参考图就不进编码，画面直接失控
且**没有任何报错**。所以改写结果要过三关，任何一关不过就**回落原文**，不做局部修补：
① `@引用` 集合不得减少；② `<d>` / `</d>` 数量必须一致；③ `[镜N]` 数量必须一致。

**自测 20 项**：字段契约导入期审计通过、两个新键的解析与缺省、owner 归类、
默认提示词内容、上限值、端口类型、build 签名；以及守门七例——正常改写被采用、
丢引用回落、台词标签数量变化回落、镜号数量变化回落、空输出原样、同文原样、抛异常不炸。

**待真机**：开关与输入框的显示、接 MOSS CLIP 后实际改写效果、显存是否回落。

### 13:38 补：改写改为多模态（参考图一起喂）

**更正一个错误结论**：`csglide_image_models.py` 里写着「MOSS-Image：qwen3.5_9b 编码器，
**无视觉塔**」——**这句是错的**。ComfyUI 源码实测：
`MOSSImageTokenizer(Qwen35ImageTokenizer)`（moss_image.py:5），父类
`Qwen35ImageTokenizer.tokenize_with_weights(text, ..., images=[], ...)`（qwen35.py:1039）
带 `llama_template_images = "…<|vision_start|><|image_pad|><|vision_end|>…"`，
且 `qwen35_9b` 配置里有 `vision=dict(hidden_size=1152, depth=27)`。**视觉塔完整存在。**

**改动**

| 文件 | 内容 |
|---|---|
| `csglide_image_models.py` | `rewrite_prompt` 加可选 `images=None`，透传到 `clip.tokenize(images=...)`；默认空列表，图像编辑台那条路行为不变 |
| `csglide_cast.py` | 新增 `_rewrite_ref_images`：按 `cfg["images"]` 全部加载，长边夹到 1024 并对齐 32（只缩不放）；`_rewrite_for_cast` 带上 `images=` |

**为什么不用原图/不复用编码那份**：9 张 4K 进视觉塔既慢又吃显存；而筛图要按改写结果里的
`@引用` 来筛，顺序上不可能先筛后改，所以改写必须独立加载一次（代价是重复一次 IO）。

**自测 14 项**：`images` 不传时为空列表、传了原样透传、`image` 仍为 None（走 images 通道）、
空提示词不调模型；`_rewrite_ref_images` 无图/None 不炸、读不到跳过并记日志、超长边被缩、
小图不放大；守门三例回归（正常采用、丢引用回落、标签数量变化回落）。

**遗留（未修，待定）**：`csglide_qwen.py` 对 MOSS 走 `if is_moss:` 分支直接丢弃参考图
（日志写「编码器无视觉塔，参考图已忽略」），与上面实测矛盾——图像编辑台用 MOSS 时
媒体架的图一直被丢。修它会影响现有 MOSS 出图行为，单独验。

### 13:45 修 MOSS 丢参考图 + 改写缩图改 512

**修 MOSS（`csglide_qwen.py`）**

原代码 `if is_moss:` 直接丢弃参考图，日志理由是「编码器无视觉塔」——**理由和结论都错**。
两步查实：
1. `model_base.py:2801` → MOSS 用 `comfy.ldm.moss_image.model.MOSSImage`；它的
   `rope(h, w, text_len)` 里序列是「生成图 token + 文本 token」，**没有 reference_latents
   这条通道**，所以 MOSS 做不了「按这张图编辑」。
2. 但**编码器能吃图**：`MOSSImageTokenizer(Qwen35ImageTokenizer)`，父类按 `len(images)`
   自动切到 `llama_template_images`（带 `<|vision_start|><|image_pad|><|vision_end|>`，
   多图还按张数复制 vision_block）。

所以改成：图照样加载进 `images_vl`，MOSS 只走视觉塔、不做 VAE 潜空间编码。

**踩到的坑**：`MOSSImageTokenizer.tokenize_with_weights` 有一段
「`llama_template is None` 且 `thinking is None` 就把模板覆盖成纯文本」的逻辑，
不显式给 `thinking=False`，图会被那个纯文本模板吞掉。所以 MOSS 传图时必须带
`thinking=False`。

**风险（必须知道）**：`thinking=False` 会让 chat 模板收成空 think 块
（`<think>\n\n</think>\n\n`），而 MOSS 原来的纯文本路径是 `thinking=True`（开着 think）。
**有参考图时**条件嵌入分布会变，出图效果可能跟以前不同；**没有参考图时走原路径，
一字未改，零影响**。

**缩图改 512**：`_rewrite_ref_images` 的 `cap` 默认 1024 → 512（长边、对齐 32、只缩不放）。

**验收 6 项**：4K 横图缩到 512×288、竖图缩到 288×512、小于 512 不放大、
**不改动入参 cfg**（导演台那份数据原样）、丢引用仍回落原文。

### 14:10 更正：改写端口加错了节点，已搬到文案台

**错在哪**：14:07 那轮把 `rewrite_clip` 端口、`rewrite`/`rewrite_system` 字段、
`_rewrite_for_cast` 全加进了 `csglide_cast.py`（**🎞️ H3 导演台**），
而前端 UI 加在 `js/csglide_desk.js`（**✍️ H3 文案台**面板）。两边不是同一个节点，
所以文案台上永远看不到那个口。

| | 文件 | 类 | widget |
|---|---|---|---|
| ✍️ 文案台 | `csglide_desk.py` | `CSGlideDeskCS` | `desk_data` |
| 🎞️ 导演台 | `csglide_cast.py` | `CSGlideCastCS` | `h3_data` |

**修法**

1. `csglide_cast.py` 整份还原（`cp csglide_cast.py.bak_rewrite_20261030_131659`），
   导演台零改动。
2. 改写逻辑搬到共用模块 `csglide_image_models.py`：
   `REWRITE_MAX_LENGTH_DESK = 2048`、`REWRITE_SYSTEM_DEFAULT`、`rewrite_with_guard()`
   （守门三关：`@引用`不减、`<d>`/`</d>` 数量一致、`[镜N]` 数量一致）。
3. `csglide_desk.py`：optional 增 `rewrite_clip`（带 tooltip，末尾追加不影响旧连线）；
   `compose()` 加同名参数；新增 `_rewrite_ref_images`（从透传的 H3_REFS 取图，
   缩到长边 512）和 `_release_rewrite_clip`；`_do_rewrite()` 内部函数包住整条流程。

**为什么改写只影响输出、归档仍存原文**：`_archive` 写的是 `prompt_seg`，时间轴与重抽
都靠它回显。归档存改写稿的话，下次重抽会拿改写稿再改一遍——逐轮叠加跑偏。
所以 `self._archive(...)` 用的是 `text`，`return` 的才是 `_do_rewrite(text)`。

**外接提示词模式也改写**：`外接提示词` 接线时早退分支同样走 `_do_rewrite`，
否则开关在那个模式下静默失效。

**验收 12 项**：守门五例（正常采用 / 丢引用回落 / 台词标签少了回落 / 镜号少了回落 /
抛异常不炸）、文案台 optional 有 `rewrite_clip` 且类型为 CLIP、`compose` 签名接受它、
从 H3_REFS 取到 2 张图、缩到 512×288、空 refs 与坏 JSON 都不炸。

### 14:20 文案台加「立即改写」按钮（HTTP 接口，不走画布运行通道）

**需求**：面板上点一下就改写本段并写回，不用排队跑整条工作流。

**实现**

| 位置 | 内容 |
|---|---|
| `csglide_desk.py` 类变量 | `_rw_clip` / `_rw_refs`：`compose()` 执行时把接进来的 CLIP 和参考素材缓存一份 |
| `csglide_desk.py` 路由 | `POST /csglide_desk/rewrite`：body `{prompt, system}` → 取缓存 CLIP + 参考图 → `rewrite_with_guard` → 用完 `_release_rewrite_clip` 交还驻留页 → 返回 `{text, logs}` |
| `js/csglide_desk.js` | 改写行加「立即改写」按钮；点击 → `api.fetchApi` → 改写稿写回本段（`st.segs[k]` + `setSegText` + `pushSegText` 推中央）→ **自动关掉面板的「自动改写」开关** |

**为什么成功后自动关开关**：按钮写回的本段词会进中央库；如果「自动改写」还开着，
下次画布运行 `compose` 会从库读到改写稿、再改一遍——逐轮叠加跑偏。
按钮 = 手动改一次；开关 = 每次画布运行都改。两者不能同时生效，toast 里会说明。

**为什么首次点击前必须先跑一次画布**：CLIP 对象只有在节点执行时才存在
（`rewrite_clip` 是连线输入，平时没有值）。`compose` 执行时缓存进类变量，
路由从这取。没跑过就是 409「改写模型还没就绪」。

**验收**：`node --check` / `py_compile` 均过；路由与缓存的真机验证需重启后点按钮看
（toast 出「已改写 N 字并写回本段」即通，出「改写模型还没就绪」就是还没跑过画布）。

### 16:05 方案 A 落地：导演级系统提示词（萃取版）

**从用户的「AI短剧导演 Skill」萃取**，新增 `REWRITE_SYSTEM_DIRECTOR`（约 800 字）。
**取舍**：只保留对「润色既有 H3 提示词」有用的部分——情绪转可拍行为（skill 3.2）、
摄影指导（4）、表演先心理后动作（5）、生成稳定性禁冲突指令（9）、镜头因果（17）、
禁空词（22）；**丢弃** 5 大模块输出格式、`[Shot N] At 00:XX.XXX` 时间戳、Subject/Audio
定义——那些是「从零生成」的规范，会让模型重组结构，与项目 `【镜头 N｜景别】` 格式
和 `check.py` 校验冲突，守门必回落。萃取版自带「铁律：结构一字不动」段，
逐条钉住段落标题 / 【镜头 N｜景别】 / 画面：等字段行 / (S1) 台词整行 / @引用。

**入口**：文案台改写行加「导演级」toggle（`st.rewrite_preset`，选中高亮）。
选中后**系统提示词输入框被忽略**（两者互斥，避免叠加两套规则）。
两条路径都认它：HTTP 路由的 `preset` 字段、compose 自动改写读 `st.rewrite_preset`。

**验收 10 项**：常量存在且含铁律段 / 钉住【镜头 N｜景别】/(S1)/@引用、
含导演原则与禁空词、**不含** subject_definitions 与 `At 00:`（防结构漂移）、
守门冒烟。

### 16:30 三处调整：默认导演级 / 报错可读 / 消息进检查框

1. **删「导演级」按钮**：导演级成为默认系统提示词；`rewrite_system` 框写了自定义
   才用自定义。`REWRITE_SYSTEM_DEFAULT` 成孤儿常量已删，fallback 统一指向
   `REWRITE_SYSTEM_DIRECTOR`（compose 与 HTTP 路由两条路径）。前端 preset 相关
   全部移除（`rewrite_preset` / `rewriteDir` / POST preset 字段）。
2. **「改写失败: Unexpected non-whitespace character after JSON at position 3」根因**：
   前端直接 `res.json()`，而后端未就绪时 aiohttp 回的是 `405: Method Not Allowed`
   纯文本——`405` 被当成合法 JSON 数字，到 `:` 炸出 position 3。已改成先 `res.text()`
   再 `JSON.parse`，解析失败抛 `HTTP 405：405: Method Not Allowed`（可读）。
   **对照实验**：POST 不存在的路径同样 405 → 运行中的服务端没有该路由 →
   用户尚未完全重启（改 `.py` 必须关黑窗口重开）。
3. **改写消息从 toast 移进「提示词检查」框**（`sayCheck`：显示 checkSec + prepend
   到 `d-check` 顶部，复用 `d-crow ok/warn` 样式）。用户一打字即被正常检查刷新，
   不会永久残留。

### 16:45 方案二落地：改写模型按文件直连，彻底解耦画布

**需求**：不要「先跑一次画布」的前置条件，不加下拉——默认搜索
`models/text_encoders`（含子目录）下的 `qwen3.5_9b_int8_convrot.safetensors`。

**改动（`csglide_desk.py`）**

| 内容 | 说明 |
|---|---|
| 删 `rewrite_clip` 端口 | 改写与连线彻底解耦；`compose` 签名同步删参 |
| 新增 `_get_rewrite_clip` | 按文件名直连加载（`CLIPLoader().load_clip(name, type="moss_image")`），类变量 `_rw_clip_cache` 常驻——只有第一次点击从磁盘读 |
| type 选 `moss_image` | 查证：qwen3.5_9b 只有在这个 type 下才挂 `MOSSImageTokenizer`（视觉塔+lm_head 兼备）；挂 qwen_image 会是另一套 tokenizer |
| 找不到模型 | 报错列出 text_encoders 目录现有文件清单，方便核对 |
| 参考图来源改双通道 | 前端按钮直传媒体架 `rack_data`（读「参考素材」口上游）优先；compose 缓存兜底；都没有则纯文本改写 |
| 路由注册防御 | `getattr(PromptServer, "instance", None)`——自检/无 server 环境里 `instance` 属性不存在，直接取会炸掉整个模块 import |

**显存策略不变**：改写完 `_release_rewrite_clip` 交还驻留页；对象常驻，下次改写
按需重载（不重读磁盘）。

**验收 7 项**：端口移除、compose 签名、子目录递归找到模型、type=moss_image、
二次调用走缓存、找不到抛错带清单、守门回归。

### 16:52 修「立即改写」生成第一步即崩（last_prompt_id 缺失）

**现象**：`Generating tokens: 1/2048` 后立刻
`AttributeError: 'PromptServer' object has no attribute 'last_prompt_id'`。

**根因链**：`last_prompt_id` 只在真实队列执行时由 `main.py:367` 赋值；改写路由绕过
队列直调 `clip.generate`，该属性从未存在。而第三方节点 ComfyUI-Majoor-OmniCam 给
模型挂了全局钩子去读它（其注释自己写明该属性「real prompt 之后才存在」）——
任何绕过队列的模型推理都会被这个钩子绊倒。

**修法**：路由开头补属性（`os.urandom(16).hex()`，每次不同，避免第三方按 id 去重
误判）。ComfyUI 核心本身不读它，补上无副作用。

### 17:05 画布自动改写完成后也自动关开关

**回答用户**：开关开着时点画布运行**会**自动改写（compose 里 `_do_rewrite` 生效），
输出给导演台的是改写稿；归档与中央库始终是原文，所以**不会叠加**——每次都是
「原文 → 重新润色」，但每次运行都会多花一轮 9B 生成时间（约 30~60 秒）。

**补齐**：画布路径的改写生效后，后端 `send_sync("bz_desk_rewrite_done", {node})`
通知前端自动关掉开关（按钮路径此前已自动关）。hidden 口 `unique_id: UNIQUE_ID`
只为拿节点 id。

**改动**：`csglide_desk.py`（hidden 口、compose 签名、`_HAS_SERVER` 标志 + 生效后
send_sync）；`js/csglide_desk.js`（监听 `bz_desk_rewrite_done` 关开关 +
`onRemoved` 摘除监听）。

**验收**：node --check / py_compile 通过；开关默认关、按钮成功自动关、画布改写
完成自动关——三条路径行为一致，均需重启后真机确认。

### 17:12 默认系统提示词换成官方全参考改写规范

**用户拍板**：不用导演级萃取版（内容全部移除，不留孤儿），只使用官方——
`ref-en.txt`（MiniMax H3 Full-Reference Mode Rewrite Output Format Guide）。
**不压缩**：规范的价值在逐字精确，23.5KB ≈ 7k token（上下文占比 <25%），
压缩的失真风险大于预填充省下的两秒；Complete Example 保留作 few-shot 锚点。

**改动**

| 文件 | 内容 |
|---|---|
| `csglide_image_models.py` | `REWRITE_SYSTEM_OFFICIAL` = 官方全文（raw 三引号，逐字未改）+ 末尾三条 Pipeline adaptations；`REWRITE_SYSTEM_DIRECTOR` 整块移除 |
| `csglide_desk.py` | import 与两处 fallback（compose / 路由）改指 OFFICIAL |

**三条 Pipeline adaptations**（接管线接口，非改官方）：
1. `@图片N/@音频N/@视频N` 引用逐字保留，**不得转写成 `<Picture N>` 等**——下游按
   `@` token 筛参考图，转换/丢失=素材静默消失；
2. 对白、歌词、画面可见文字保留原语言（覆盖「全英文输出」仅限这三类）；
3. 信息量对齐输入：不发明新镜头/新引用/新剧情，增量细节分摊到既有镜头。

**验收 9 项**：官方全文六段/标签/镜头格式在、三条补丁在、导演级内容清零、
文案台无 rewrite_clip 口。

### 17:15 混排变体：官方格式 + 中文输出

**需求**：改写输出不要全英文——段名与标记照官方，描述正文用中文。

**实现**：`REWRITE_SYSTEM_OFFICIAL` 在 Pipeline adaptations 之前插入
「Language override（最高优先级）」段：
- 六段**描述正文**一律简体中文；
- 保持原样的白名单：段名（subject_definitions 等六个英文段名）、固定标记
  （`<Subject N>` / `<Picture N>` / `<Video N>` / `<Audio N>` / `[Shot N] At MM:SS.mmm` /
  `<d>…</d>` / `<scenetrans>` / `<cutoff>`）、对白歌词与画面可见文字原语言、
  专业摄影术语可括注英文。
- 官方正文逐字未动——语言覆盖以「最高优先级」声明覆盖其英文要求，而非改写原文。

**验收 9 项**：覆盖段与中文要求在、白名单齐全、官方正文（六段/标签/时间戳）逐字在、
三条管线补丁在、覆盖段位于补丁之前、导演级仍为零。

### 18:30 修「编辑后第二次运行输出旧提示词」（库权威静默失败）

**现象**：未开改写；第一次运行 OK，编辑本段后第二次运行输出仍是第一次的词。

**根因（与改写无关）**：方案 A 的「中央库是段词唯一权威」+ `pushSegText` 的三个
**静默失败分支**（`!isRealCid` 临时段 / `probeMode!=="segment"` 段未登记 /
`projName()` 空根本不调）。任一发生 → 库停在第一次的词 → `compose` 的库权威覆盖
面板新词 → 文案台输出的 `prompt_text` 与上次相同 → **导演台缓存命中不重跑** →
出图用第一次提示词。全程无提示。

**修复**：
1. `csglide_desk.py` 库覆盖处加对比日志：库值 ≠ 面板镜像时打 ⚠ 并说明三个失败分支；
2. `csglide_desk.js` `onSegChange` 检查 `pushSegText` 结果（每段去重一次 toast）：
   「⚠ 本段词没写进中央库（临时段或段未登记）——画布将按上一次入库的词执行」。

**自查手段**：第二次运行的终端日志 `[H3 文案台] 片子级 X 字 + 本段 Y 字` 中，
Y 若不等于你编辑后的字数 → 库覆盖实锤。

### 18:35 媒体架审计：无同类问题（它 20261027 已根解）

**审计结论**：媒体架不存在「库权威静默失败」问题——
`csglide_media_rack.py emit()` 的注释明确记载：20261027 已拆掉「方案A」的库覆盖，
「架面内容的唯一权威是面板镜像（rack_data），库降级为存档与恢复」。
其注释还预言了文案台这次的 bug：库写入有 700ms 防抖 + 四道静默 return，
「命中任何一条，库里停在替换前的快照，表现就是导演台拿到的旧图」。

**即**：方案 A 的「执行时库覆盖」模式在媒体架已根解，文案台是漏拆的残留。
本次 18:30 的提交优先反转 = 把文案台对齐到媒体架 20261027 的既定架构。
至此两节点统一：**面板镜像为执行权威，中央库只做存档与恢复**。

### 19:55 修批量导入不识别新版技能的资产文件

**现象**：拖入别人发来的 `资产提示词-道具.md` 报「没找到资产节」。

**根因**：新版技能按集组织产出，资产节标题是**裸行** `@图片9 = 香烟`（无 `## ` 前缀）；
`SECTION` 正则硬性要求 `## ` 开头 → 整份 0 条。顺带确认该文件已带 `<<<元信息>>>` 层
（格式约定已进技能侧），元信息剥离与画幅/标题解析全部正常工作。

**修复**：`SECTION` 前缀放宽为可选的 `#{1,4}\s*`（旧 `## @图片N`、新版裸行、
`###` 变体都认）；正文行有 `- ` 列表前缀、变更记录日期行、不含「图片N+分隔符」的
标题行均不会误匹配。

**验收 10 项**（含真实微信文件）：裸行文件解析出 1 条（名/编号/类型正确）、
元信息进 meta 且正文干净、道具描述保留、旧版 `##` 兼容、
变更记录/日期行/正文行不误匹配、`###` 变体也认。

### 20:00 全局排查「资产/提示词文档解析点」对新版格式的兼容性

| 解析点 | 输入 | 新版格式兼容性 |
|---|---|---|
| `csglide_asset_batch.js parseAssetDoc`（图像编辑台拖资产文档） | `@图片N` 资产节 | **已修**（裸行标题+元信息层） |
| `csglide_desk.js pickVideoBlock`（文案台拖提示词文档） | `<<<视频提示词>>>` 标签块 | **无问题**——标签式解析，新版 SEG txt 的标签、文件名段号（`SEG_4_prompt.txt`）均未变；块内 `[场景与影调全局]`/`【镜头 N】` 新结构是内容不解析、整块写入。核心帧块被忽略属设计边界（核心帧归图像编辑台/预览卡） |
| `banzhang_sp_main.js` → `/banzhang/upload_script` → `banzhang_script_pipeline.py`（sp 预览） | **剧本文档**（02b 全片剧本） | 不在本次问题族（资产文件不是其输入）。但它是另一族格式解析点：技能未来若改**剧本**格式需单独审计（解析逻辑在 `_script_pipeline/`） |
| `banzhang_sp_cards.js` | 纯 UI 渲染 | 不解析文档 |

**结论**：文案台没有类似问题；全仓解析点已盘点归档。

### 17:00 消歧：执行其实用了文案台的词（两条误导线索）

**用户报「第二次输出仍是第一次的内容」，日志数字证明相反**：
- 前端 `[B1] 段词对账 中央=2390字`（JS `.length`，`\r\n` 算 2 字符）
- 后端 `本段 2321 字`（Python `_clean` 把 `\r\n` 归一成 `\n`，每个换行 1 字符）
- 差 69 = 换行数 → **同一份词**，提交优先生效正常。

**两条误导线索**：
1. 导演台日志「外接模式：prompt_text 接线……（面板提示词未参与）」——「面板」指
   导演台自己的提示词框，不是文案台；已改写消歧义。
2. 导演台固定种子出图：小改词 + 同种子 → 画面相似，观感「没生效」。验证法：
   把一个视觉要素改明显（黄昏→深夜）再跑。

**补**：compose 日志加「执行用词开头 40 字」预览——执行用的词从此直接可见可对照。

### 21:30 引用守门升级为逐位比对（防编号互换）

**背景**：原守门用集合差集，只查「少了哪些编号」——**抓不到编号互换**
（`@图片5`↔`@图片9` 对调，集合不变，素材全错）。中途一度改成多重集（Counter），
测试证明**纯互换仍抓不到**（每个编号的出现次数不变）。

**最终**：逐位序列比对——`findall(text) != findall(new)` 即回落，日志写明
「第 N 处引用被改（@图片5 → @图片9）」或「引用数量变了」。引用属结构
（官方指南亦要求原样保留），顺序/编号/次数任何一处不同都不采纳。
副作用：改写若调换引用顺序也会回落——宁严勿错。

**递归查找确认**（用户问）：`folder_paths.get_filename_list("text_encoders")` 本身
递归整棵树，返回带子目录的相对路径；匹配时取 basename，所以任意深度子目录都能命中。
用户日志里的 `MOSS-Image\qwen3.5_9b_int8_convrot.safetensors` 即证据。

**验收 6 项**：正常改写采用、编号互换拦下、日志指明第几处、丢引用回落、
次数变化回落、顺序变化也回落。

### 21:35 修改写模型导致的 OOM（「之前不会」的根因）

**为什么之前不会**：今天新增的改写模型 `qwen3.5_9b_int8_convrot` ≈ 9.3GB，
与 H3(19995MB Staged) + H3 文本编码器(14969MB Staged) 在 22GB 卡上三足鼎立；
dynamic VRAM 以前刚好够，多一个 9.3GB 竞争者就顶到墙。

**更深的坑（原实现）**：释放只交还「驻留页」，对象仍挂在 `_rw_clip_cache` →
ComfyUI 账本认为它还在用 → 采样前不愿驱逐 → 该腾不腾 → OOM。与 vram_cleaner
注释里那句「账本对不上，最后扩散模型加载不进来」同一个病。

**两处修复**
1. `_get_rewrite_clip` 加载前按**真实需求量**主动 `free_memory`
   （`getsize × 1.15`；`free_memory(0, dev)` 实测什么都不卸）。
2. `_release_rewrite_clip` 改为彻底摘账本：`release_model_residency` → 
   `unload_model_and_clones` → 非动态时 `model.to("cpu")` → `soft_empty_cache`
   → **`_rw_clip_cache = None`**（下次点击按需重载）。

**代价**：每次点「立即改写」重载一次 9.3GB（几秒）——换来跑画布不再被它挤爆。

### 21:40 A+B：改写附带素材清单 + 无参考图告警

**A. `_ref_manifest(refs)`**：把媒体架槽位拼成清单附在系统提示词后面——
```
【可用引用（改写时必须逐字保留这些编号，不得增删、不得改编号）】
@图片1 = 色彩参考色板
@图片2 = 九寸铜镜
@图片4 = 核心帧一
```
编号 = **槽位位置**（空槽占位不压缩），与导演台 `@图片N → 第 N 个槽位` 的口径一致；
有 alias 用别名，没有就用文件名去扩展名。空 refs / 坏 JSON / 无 slots 一律返回空串。
两条路径（compose 与 HTTP 路由）都拼。

**B. 无参考图告警**：`参考图 0 张` 时打 `⚠ 本次没有参考图 —— 改写模型看不到任何画面，
@引用容易被删；要更稳请先在媒体架摆素材`；前端在「立即改写」成功后把 logs 里的 ⚠
一并摆到「提示词检查」框（用户不看终端也知道前置条件没满足）。

**背景**：实测一次改写产出 4396 字但引用 1→0 被守门拦下（模型看不到图就把 @引用当
普通文字删了）。A 让它知道引用存在，B 让前置条件可见。

**验收**：编号按槽位不压缩、别名/文件名两种取名、空值与坏 JSON 不炸、两条路径都拼。

### 21:50 改写持续被守门拦：低温 + 带反馈重试

**现象**：连续两次改写都被守门回落——引用 1→0、台词 `<d>` 0→2。模型在**自由扩写**
（原文无对白时凭空造台词），官方指南「尽量详尽」是诱因。

**两项改动（`csglide_image_models.py`）**
1. `rewrite_prompt(..., temperature=0.7)` 参数化；`rewrite_with_guard` 默认用 **0.25**
   ——改写要贴原文，不需要创造力（0.7 是生成场景的值）。
2. 守门判据抽成 `_guard_reason(text, new)`；`rewrite_with_guard` 改为
   **不合格 → 带错误反馈重试一次**（默认 `retries=1`）：把「台词标签 <d> 数量变了
   （0 → 2）」这类原因拼进系统提示词再跑一遍，温度再降 0.1；两次都不合格才回落原文。

**为什么重试而不是直接回落**：官方指南是「从零写全参考提示词」的规范，模型顺势扩写
是系统性的，不会自愈；把不合格点回喂给它，等于一次带纠错的第二轮，比白跑一轮好。

**代价**：失败时多一轮 9B 生成（约 10 秒）。

**验收 12 项**：首次合格只调一次、默认温度 0.25、重试温度降到 0.15、反馈里含不合格
原因、第二次合格即采纳、两次都不合格回落原文、最多 2 次调用、引用丢失同样先重试。

### 21:45 结构剥离：改写从「事后拦」改为「物理上改不了」

**现象**：重试也压不住——第 1 次把 1 个镜头扩成 7 个（遵循官方指南），重试后矫枉
过正删成 0。模型在「指南要求多镜头分镜」与「反馈要求别加镜头」之间两难摇摆。

**根治：结构剥离**。改写前把镜头标记（`【镜头 1｜全景】`、`[Shot 2] At 00:09.000`）、
台词（`陈九一 (S1) :<d>…</d>` **整行**，含说话人 ID——防模型换角色导致音色错配）、
`@引用` 摘成 `⟦N⟧` 占位符；模型拿到的**只有纯描述文字**，物理上碰不到结构；
改完按映射放回原标记。守门三层复检：
① 结构标记**出现顺序**必须一致（互换/挪位唯一暴露点）；
② 引用逐位比对；③ `<d>` 数量。占位符丢失/乱编（⟦99⟧）在还原时即回落。

**验收 5 项**：正常改写整行还原（含说话人前缀）、说话人行不进模型、占位符丢失回落、
塞新镜头仍拦、占位符互换回落且日志指明。

### 21:55 终版架构：改写 = 格式规范化（任何输入 → 官方六段）

**用户拍板**：不分形态，任何输入都改成官方 skill 要求的形式结构。这推翻了
「润色保结构」的整个前提——官方指南的本意就是 Rewrite Output Format Guide，
「结构保护」是在跟官方规范对抗。

**架构（`csglide_image_models.py`）**
- 删除整套保结构补丁堆：`_STRUCT_RE` / `_guard_reason` / `rewrite_with_guard`
- 新增 `rewrite_normalized(..., manifest=None, temperature=0.3, retries=1)`：
  任何输入按官方指南重写成六段；单句扩成完整分镜（特性）；已是六段则幂等规范化
- 守门只剩两条（`rewrite_gate_refs`）：① 输入的 @引用编号必须全部出现在输出
  （丢=素材被筛）；② 输出不得编造清单外编号（编=素材错配）
- 不合格带原因反馈重试一次；`REWRITE_MAX_LENGTH_DESK` 2048 → 4096（六段更长）
- Pipeline adaptation 3 同步改：允许把短输入扩成完整分镜（素材与剧情仍受限）

**`csglide_desk.py`**：import 与 compose/路由两处调用切到 `rewrite_normalized`
（manifest 改为参数传入，由函数内部拼进系统提示词）；「默认导演级」注释改「官方六段规范」。

**验收 15 项**：旧函数清零、上限 4096、manifest 参数、两条引用守门（真丢/真编造
各拦且报错指明编号）、单句→六段采纳、编造触发重试后采纳、清单进系统提示词、温度 0.3。

### 22:05 删「提示词改写」开关：改写只剩「立即改写」按钮一条路

**用户拍板**：画布运行时不再自动改写，改写只由按钮手动触发。

**移除（后端 `csglide_desk.py`）**：`_do_rewrite` 整块、compose 的 `unique_id` hidden 口
与签名参数、`_HAS_SERVER` 标志、`bz_desk_rewrite_done` send_sync——compose 回归
纯粹的「读词 → 归档 → 返回」。跑画布永远不加载 9.3GB 改写模型（OOM 风险彻底消除）。

**移除（前端 `csglide_desk.js`）**：开关控件、`st.rewrite`、paintRewrite 的开关行、
`bz_desk_rewrite_done` 监听与 onRemoved 摘除、按钮成功分支的「自动关开关」两行；
toast 简化为「已改写 N 字并写回本段」。

**保留**：「立即改写」按钮、系统提示词框（留空 = 官方六段规范）、检查框消息、
后端直连加载/释放、素材清单、两条引用守门、反馈重试。

**验收**：py_compile / node --check / 三模块 import 通过；开关相关残留清零；
compose 签名与 INPUT_TYPES 干净。

### 22:15 修「参考图 0 张时改写必丢引用」

**现象**：无参考图（manifest 空）时改写，模型按官方指南的 `<Picture N>` 标签体系
转写，`@引用` 在输出里消失（实测连续两次：1→0、2→0），守门拦下后白跑。

**根因**：素材清单只从媒体架槽位生成——槽位空 → 系统提示词里**完全没有引用指令**，
模型不知道 `@图片N` 必须保留。

**修复**：`rewrite_normalized` 内部——manifest 为空时，从**输入文本**提取引用编号
（`_REF_RE.findall`）生成最小清单：「必须保留的引用：@图片1、@图片2（不要转写成
<Picture N> 等其它形式）」。重试轮的 sys_p 重建同样带上。有槽位清单时仍用清单
（带素材名，不重复 inline 段）。

**验收 5 项**：无清单时引用指令进系统提示词（含两个编号）、禁止转写说明在、
重试轮同样带、有清单时不重复、采纳。

### 22:20 无参考图改为静默降级（不再像报错）

**用户要求**：以后没提供参考图时按无图情况默认执行，不要直接报错。

**改动**：`csglide_desk.py` 路由里的无图分支从 `⚠ 本次没有参考图 —— …容易被删` 改为
中性说明「本次没有参考图：按纯文本模式改写（@引用编号仍会保留）；想让描述贴合画面，
可在媒体架摆好素材后再改一次」。去掉了警告前缀——前端只把带警告标记的日志行刷到
「提示词检查」框，去掉后无图不再呈现为红色错误，只在终端留一行说明。

**为什么现在敢直接执行**：22:15 的修复让 manifest 为空时从输入文本生成最小引用清单，
无图路径不再丢引用；守门与重试照常兜底。无图 = 正常可选状态，不是故障。

### 22:25 悬空编号自动转文字描述（+ 守门补漏）

**需求**：提示词含 `@图片N` 但没有对应参考图时，自动改成文字描述形式，而不是编号。

**机制（`csglide_desk.py`）**
- `_provided_refs(refs)`：refs 里**真有文件**的槽位编号集合
- `_drop_unbacked_refs(text, refs, log)`：把不在该集合里的编号从文本摘掉、压缩多余空白，
  返回被摘清单；系统提示词补一句「被移除的编号请按上下文用文字描述替代，不要编造编号」
- 理由：悬空编号会被导演台按槽位找素材（找不到 → 画面失控），模型也会误以为有图

**守门补漏（`csglide_image_models.py`）**：`rewrite_gate_refs` 的「编造检查」原来只在
有素材清单时执行——编号被摘掉后模型若自己写回 `@图片1`，会放行。改为**无条件执行**：
允许集 = 清单编号 ∪ 输入保留编号，多一个就拦。

**验收 14 项**：无 refs 两个编号都摘且文字保留、只缺 2 号时只摘 2、都有图原样、
无编号原样、摘后空格压缩；守门侧：无清单输出无编号通过、写回编号拦下且说明
「没有对应参考图」、清单内通过、清单外拦、输入保留编号通过。

### 22:35 根修「改写输出一直英文」：官方指南整篇中文化

**根因**：系统提示词是「341 行英文正文 + 中文覆盖指令」的对抗结构。英文正文里
「Write all six rewrite sections in English / Write the body in English / 350-500 English
words」是全篇最强指令，且示例全英文——加中文指令只是对抗它，压不住（首尾夹击也
只是缓解）。

**修复（彻底）**：`REWRITE_SYSTEM_OFFICIAL` 整篇译为中文，官方结构一个不丢：
- 六个段名、`<Subject N>/<Picture N>/<Video N>/<Audio N>`、`[Shot N] At MM:SS.mmm`、
  `<d>[语言]</d>`、`<scenetrans>/<cutoff>`、关系标记（fully_preserved / partially_copy …）、
  任务类型（reference generation / video editing …）**全部保留英文原样**
- 所有说明文字、规则、字段含义、示例**全中文**；示例改写为中文对白示范
  （few-shot 的语言示范作用最强，示例是英文是之前失败的关键之一）
- 开头即写【输出语言：简体中文】
- 三条管线适配（@引用逐字保留 / 只用清单内编号 / 允许把短输入扩成六段）并入第八节

**量化**：8588 字符，中文 4190 字 / 英文 396 词，**中文占比 91%**；四条「用英文写」
指令全部清除；必需标记 19 项齐全；开头即语言要求。

**为什么这次是根修**：语言冲突的载体没了——模型看到的是全中文规范，没有可模仿的
英文语境。

### 22:40 精简版补回 attribute_transfer 用法

用户确认会写「以参考图的脸生成另一个人」这类内容，把精简时删掉的用法说明补回
retention_analysis 标记行：attribute_transfer（把一份素材的外貌/特征移到另一个主体上，
例如以参考图的脸生成另一个人；只转移被引用的那几项特征，目标主体的身份、其余外貌与
动作自行合理设定）。现 2620 字符 / 1098 中文字，仍远小于原版 8588/4190。

### 2026-10-30 追加：三条防炸修正

用户真机报「参数有误，提示改成整数」，但三份日志（comfyui.log / .prev / .prev2）里
**没有任何后端异常**，也没有 `Failed to validate` —— 说明拦在前端。静态审查找出三处真缺陷：

1. **`token分块大小` / `权重缓存预算` 越界直接 raise** —— 这两个是可选调优项、默认值本身安全，
   而它们的位置可能被老存档的 `彩色光点`(9) / `权重`(4) 占着，9 和 4 都 < 128 → 必炸。
   改为**回默认 + 警告**：
   - token 不在 128~16384 → 4096
   - 权重不在 0~64 → 4.0
   根因同 10-25 那次：只在 `彩色光点` 上做了兜底，**新加的三个参数没做**。这次一起补上。

2. **`满分辨率分块` 在 global 系下静默失效** —— 用户看到「开了没反应 / 开了报错」互相矛盾，
   就是因为两条省显存路线互斥却没有任何提示。现在 `apply()` 里：
   `省显存模式 ∈ global 系` 且 `满分辨率分块 ≠ 关` → 打一行警告「本次不生效，要切块改回 spatial」，
   并直接 `spatial_params = None`。

3. **`_install_tile_pos` 无条件挂** —— 原来只看 `spatial_params is not None`；现在 global 系下
   `spatial_params` 已被清空，坐标注入 wrapper 自然不再空挂。

### 验证
- `py_compile` 通过；`_selftest_pycompat.py` **22 通过 / 0 失败**（3.11 + 3.12）
- 整包 import 成功，8 个控件顺序不变
- 备份：`banzhang_selflift.py.bak_advanced_20261030`

## 2026-10-31 03:10 🎨 批量资产：产物元数据跟着每条资产走

**现象**：拖入提示词文档批量出图后，把成品图拖回画布，旧提示词（「国风写真…」）和旧参考图跟着回来，看起来像「每次生图都重复出一张以前那张」。

**根因**：`csglide_asset_batch.js` 的 `dispatchAll` 只把每条资产的提示词写进 `output`（决定跑什么），却把**同一份 `p.workflow`**（画布快照，ComfyUI 原样写进产物 PNG 元数据）传给每个 job。实测三张成品（扁木箱 / 灵位 / 陈墨白）内嵌的 workflow 全是批量开始前那条「陈九一」，与画面内容无关。

**改动**（`js/csglide_asset_batch.js`）：
1. 新增 `syncWorkflowMeta(workflow, cfgJson, clearRack)`：提交前把本条的 `qwen_data` 写进 workflow 快照；批量路径同时清空媒体架图片槽位（本次 `no_refs`，快照里也不该留旧图）。`no_refs` 本身不写入元数据 —— 它是提交期指令，写进去会让用户重新拖素材也不生效，且面板上没有开关可关。
2. `dispatchAll` 每条深拷贝一份 workflow 再提交。
3. `CAST_CLASS` 由 `"CSGlideImageCast"` 改正为 `"CSGlideImageCastCS"`：原来写短了，`injectGlobals` 的 class_type 比对永远不成立，**片子级（LoRA 触发词）在批量路径上一直没生效**。

**验证**：`node --check` 通过；`tests/js/_selftest_modules.mjs` 31 通过 / 0 失败。真机验证：跑两条不同资产，把任一张成品拖回画布，看提示词是否换成该条自己的。
**备份**：`js/csglide_asset_batch.js.bak_metasync_20261031_031025`

## 2026-10-31 19:00 🔗 段间接缝单帧背景突变：潜空间档承接从「条件锚定」升级为「逐位钉死」

**现象**：工程 40 多段续接，两段过渡处背景某一帧硬突变、无过渡。以前（文件档时代）承接 5 帧就无缝，现在 39 帧都压不住。

**取证**（comfyui.log 三份 + 工程档案）：
- 10-30 22:41 → 10-31 16:58 的渲染日志全是「承接帧数为 0（独立成段）」——10-29 默认改不续接后，**续接一次都没真机跑过**；今天 17:15 / 18:08 两轮是 10-29「潜空间档自动升级」改造的**首次真机跑链**。
- 旧文件档 = H3 **原生引导帧**（整段承接打包成单个 keyframe 块 @ index 0）；新潜空间档 = Motion Context 逐 latent step keyframe **条件**。条件不等于钉死：模型（4 步 + cfg 1.0）对逐块 keyframe 的还原不忠实，新段头部重建出的承接帧与上一段**真实**尾部漂移 → 成片剪头后交界 = 真实末帧 ‖ 接着重建头的自由帧 → 单帧突变。这正是 10-29 改造记录里标注「仍未验证」的那条风险。

**改动**（`csglide_cast.py`，备份 `.bak_seam_20261031`）：
1. `_continuation_latent`（`[承接钉帧]` 锚点）：`_MC_Node().apply()` 之后，用 `_mc_tail_from_latent` 切上一段尾部 n 帧的 latent steps **位对位写进**输入潜空间头部，再挂 `build_pin_mask(head=n)` 遮罩钉住。头部逐位 = 上一段真实尾部（samplers.py:642），自由帧从真实内容续出 → 交界逐位连续。铁律：先写内容再挂遮罩；写不进就不挂（`_Stub`/形状异常 → 只靠 MC 条件，打日志）。
2. `_attach_pin`（重抽钉帧）三处配合：捕获延续已挂的 `noise_mask`；自建遮罩改 `torch.minimum` **合并**（重抽钉尾 + 续接钉头并存，覆盖会丢接缝）；回填写不进的 pop 路径**保住**延续遮罩（那个区域内容由延续自己写进去了，不存在「冻住空 latent」）。
3. 承接遮罩存在时，重抽「保留头部」**让位**（head=0）：承接头本来就要剪掉，钉旧版只会让接缝对不上新上一段。
4. 顺手修 `install_keyframe_autofit` 的 `_Stub` 崩溃（`hasattr(lat,"ndim")` 防御）：之前一个占位关键帧会把同批其余关键帧的网格自愈整个炸掉。

**栅格核对**：h3mc `_steps_for_frames` 与 `banzhang_h3_pin._steps_covering` 同一套 FRAME_PER_TOKEN(1,4,4,4,4)；22→7 步、39→12 步**精确**覆盖，写入块数与遮罩步数不会错位；`_empty_av_latent` 视频流 5 维 [1,24,T,H,W]，与切块形状一致。

**验证**：ast.parse 通过；`_selftest_segrev.py` 24/24、`_selftest_segcontract.py` 26/26。真机验证待用户重启 ComfyUI 后重跑一段续接：日志应出现「[承接钉帧] 上一段尾部 39 帧已**先写进**输入潜空间（12 步）并挂遮罩钉住」，交界处不再单帧突变。

### 10-31 改写模型改成下拉自选

**需求**：文案台改写不再固定默认模型，用户可下拉自选。

**后端（csglide_desk.py）**
- `_rewrite_model_names()`：候选 = MOSS-Image 目录（挂 moss_image tokenizer 才能
  看图+出字），无该目录退回全列表
- `_resolve_rewrite_model()`：裸文件名/带子目录都能解析；找不到列出候选报错
- `_get_rewrite_clip(log, model_file)`：缓存改键值对（相对路径, clip）；换模型先
  `_release_rewrite_clip` 请旧模型出显存账本（22GB 卡两份权重必爆）
- 路由 `/csglide_desk/rewrite` 读 `body.model`；新增 GET `/csglide_desk/models`
  返回 `{models, default}`

**前端（js/csglide_desk.js）**：改写行加 `<select class="d-rwmodel">`，候选惰性拉取
（失败只留「默认」一项不拖垮主功能）；选择存 `st.rewrite_model` 随档持久；请求体带
`model`；存档所选模型不在列表时保留显示「（存档所选）」。

**验收**：py_compile / node --check(.mjs) 过；离线 5 项解析逻辑全过（候选只含
MOSS-Image 且排序、空→默认、裸名→相对路径、带目录、找不到→报错含候选）。

### 10-31 方案 A 根修：引用链路由代码保证（摘出—生成—重注）

**根因**：引用编号的保全完全赌模型记性，2b 小模型写长文必丢 → 守门全弃 → 回落
原文 → 用户白等且不写回。

**改动（csglide_image_models.py）**
- 新增 `_reinject_lost_refs(new, lost, manifest)`：模型丢的编号按清单机械补回
  subject_definitions 定义行（`@图片N = 清单名称（本段引用的参考素材）`）；无该段
  头时整段前置；清单没有名称时兜底「参考素材」
- `rewrite_normalized` 主循环：守门报「丢掉了引用」→ 不弃稿，全部丢失引用一次补回
  → 再过闸（通过即返回，省掉一整轮生成）；补回后仍不合格（编造编号）→ 走原重试
- 名字解析正则用 `@(?:图片|音频|视频)\d+` 交替（字符类 `[图片音频视频]` 只匹配
  单个汉字，第一次就栽在这）

**验收**：py_compile / pycompat 22 项过；离线 5 项过（插入点、名单解析、无头前置、
补回后守门通过、编造仍拦、兜底名）。待真机：带图改写一次，预期终端出现
「模型丢了引用 …—— 已由代码按清单补回定义行，不弃稿」，检查框正常写回。

**教训**：守门是检测失败，不是保证成功；机械可验证的工作（编号存在性）不该赌
模型。失败处理要「降级」不要「全弃」。

## 2026-11-01 10:35 ⚡ SLA 加速挂不上（`__init__.py` 漏导出 `engine_status`）

**现象（用户 htd-106 / 1031 版提报）**：`BanZhang_SLABlockSparseAttention` 打
`[WARNING] [班长SLA] 加速没挂上 … ImportError: cannot import name 'engine_status'`，
实际按不加速跑。WARNING 里列的三种「常见情况」（ComfyUI 偏旧 / sm_80 / 接口变了）
全不成立 —— 启动日志 `comfy_kitchen backend cuda: available=True`，机器是 sm_89。

**根因**：`sla/patch.py:80` 新增 `engine_status()` 后，`sla/__init__.py` 没同步 re-export。
`banzhang_sla_attention.py:171` 是**多名字合并导入**
`from .sla import engine_status, patch_h3_sla` —— 缺一个名字整条导入失败（全或无），
被 186 行 `except Exception` 吞成「不加速跑」。

**改动**
| 文件 | 改什么 |
|---|---|
| `sla/__init__.py` | `from .patch import engine_status, patch_h3_sla`；`__all__` 补 `engine_status`（备份 `.bak_export_20261101`） |
| `sla/__pycache__/` | 清掉，避免旧字节码 |

**验收**：独立进程 `import sla` → `__all__` 两项齐、`engine_status()` 返回
`官方内核可用（不需要 triton）`。待真机：重启 ComfyUI 跑 H3 工作流，WARNING 消失、
日志改打 `[班长SLA] 本机加速档位：…`。

**教训（新增一类坑）**：给包加公开函数必须同一次改 `__init__.py` 的 import 与 `__all__`；
且自检要走**包入口**（`import sla; hasattr(sla,'xxx')`），不要只测子模块
`sla.patch.xxx` —— 现有 `_selftest_sla_notriton.py` 正是走子模块，所以漏掉这次回归。
`except Exception` 兜底会把 ImportError 伪装成环境问题，排查方向上先怀疑自己。

---

## 2026-11-01 🪞 人脸修复台：砍掉空转层，单出口重绘

**背景**：静态审查（十项问题）后整体重构。核心判断 —— 节点**不该自己采样**。

**根因（P0，已实证）**
1. `inpaint.patch_renoise` 调 `model_sampling.noise_scaling`，而 H3 的
   `ModelSamplingAV`（`comfy/model_sampling.py:338`）没有该方法（实测
   `hasattr == False`，它只存在于 EPS/CONST 等旧采样类）→ 接 model 后下游二采
   必抛 `AttributeError` 红框；若接了 positive 则被 try 吞成「失败已回退」，
   永远修不好。
2. 该补丁还丢了官方 `scale_latent_inpaint` 的 `x` 参数，把「保留区按
   VISUAL_COND_TIMESTEP=0.999 注入 + token 网格对齐混合」换成了「重噪到当前
   sigma」——语义相反，保留区会被搅脏。
3. `if patched_model and positive` 双路径：节点内自采（绕开用户 sigmas 与音视频
   时间步）与「输出 latent 给下游采样」并存，面板无提示。

**改动**
| 文件 | 改什么 |
|---|---|
| `_facefix/inpaint.py` | 删 `patch_renoise` / `sample_inpaint`；只留 `patch_sampler_only`（视频掩码不进 per-token 时间步条件）+ `attach_sigma_schedule` + `build_noise_mask` |
| `_facefix/pipeline.py` | 单一出口：检测→掩码→补丁→带 noise_mask 的 latent，节点内不采样 |
| `_facefix/detection.py` | 删 SAM3 分支（装了权重就 `faces=[]`，等于检测永久失效）；YOLO 权重模块级缓存 + 一次批量推理 |
| `_facefix/masks.py` | 帧数取各 track 最大长度（短 track 不再截断画布）；非 5 维 latent 明确跳过 |
| `banzhang_facefix.py` | 端口 7→5（删 `action`/`positive`/`ref_faces`/`identity_conds`）；删 `DEFAULT_MODULES`；旧存档 `modules` 键读入即丢 |
| `js/banzhang_facefix.js` | 卡片高度按行数推导（1–2 行，行高固定 132 与宽度无关）；`scrollbar-gutter:stable` 断自激回路；重复结果不再刷「未保存」 |

**停用（改名 `.bak_ffix20261101`，源码保留可查）**
`freq.py`（矩形框做 DWT，高频落在框边而非五官 → 权重方向与宣传相反）、
`tracking.py`（H3 整段 latent 一次采样，不存在"逐帧重绘闪烁"，且 `spread=n/8`
让长片段尾部权重只剩 0.13）、`router.py`（routes 只进报告字符串）、
`graft.py`（`FaceAnalysis` 每次重建、RGB/BGR 反、闭环空转）。

**验收**：`_selftest_facefix.py` 25 项全过（新增，含节点外壳/掩码/noise_mask/
补丁/曲线/单出口）；`_selftest_pycompat.py` 259 文件 0 失败；`node --check`（.mjs
方式）通过。**待真机**：重启 ComfyUI（改 .py 必须完全重启），旧工作流里
`positive`/`ref_faces` 的线会掉，需按新面板重接。

**已知问题**
- `project.faces[].thumb` 存的是 base64 PNG，10 张脸约 100 KB 会写进
  `node.properties` 与工作流 JSON；刷新可恢复缩略图，代价是存档变大。
- 未接 `model` 时仍会输出带 `noise_mask` 的 latent（下游采样器会读），但视频
  掩码会进时间步条件，效果差一档 —— 报告里已提示，未强制。
- 旁系 `custom_nodes/ComfyUI-H3-FaceRefine`（7 节点：Face Track+Crop、SAM 掩码、
  Per-Frame Denoise、Inject Video Latent）覆盖同类需求，若本节点效果不及预期，
  优先评估它而不是继续加巧思。

---

## 2026-11-01 人脸修复台改为「只用 SAM3.1 检测」（去 YOLO 降级）

**用户口径**：只使用 SAM3.1 检测，去掉自动降级 YOLO 的机制与代码。

**关键事实（别再猜）**
- SAM3.1 **不是独立检测器**：`comfy_extras/nodes_sam3.py` 的 `SAM3_Detect`
  必须同时接 `model`（SAM3.1 权重）与 `conditioning`（CLIP 文本编码，如 face），
  单给图像不出任何结果。所以节点新增两个**必接**端口，不是可选增强。
- 本机**没有 SAM3 权重**：`models/diffusion_models` 与 `models/text_encoders` 均无
  sam3 文件，`models/sams` 为空。真机要跑必须先下权重。
- `SAM3_Detect.execute` 返回的 `io.NodeOutput` **不是元组**（只有 `.args` / `.result`），
  不能 `out[1]`，必须 `out.result[1]`。

**改动**
| 文件 | 改什么 |
|---|---|
| `_facefix/detection.py` | 整篇重写：删 `_find_model_file`/`_load_yolo`/`_detect_yolo`/`YOLO_FACE_MODEL`/`YOLO_BATCH`；改为调 `SAM3_Detect.execute` 只取逐帧 bbox（`refine_iterations=0` 跳过 mask 精修），补同帧重叠框去重（IoU>0.6 只留高分） |
| `_facefix/pipeline.py` | `execute` 增 `sam3_model` / `sam3_cond` 透传 |
| `banzhang_facefix.py` | 端口 5→7：新增 `sam3_model`(MODEL) 与 `sam3_cond`(CONDITIONING)，均为 required |
| `js/banzhang_facefix.js` | 端口中文名补「SAM3.1模型」「人脸文本条件」；空态提示写明要接这两根 |
| `_selftest_facefix.py` | 29→33 项：新增「无 YOLO 残留」「缺 SAM3 输入不返回脸」「SAM3 输出解析（伪节点，含去重/坐标/缩略图）」 |

**验收**：`_selftest_facefix.py` 33 项全过；`_selftest_pycompat.py` 0 失败；
`node --check`(.mjs) 通过；全包 grep `YOLO|ultralytics` 只剩 detection.py 里一句
「没有 YOLO 降级路径」的说明文字。

**已知问题（真机前必读）**
- **显存**：`SAM3_Detect` 内部会 `load_model_gpu`，检测时 SAM3 与 H3 同时驻留，
  3090 24G 上 ComfyUI 可能把 H3 换出，二采重新载入 → 该段耗时明显变长。
- **速度**：SAM3 每帧一次 1008×1008 前向，12 帧约数秒～十余秒（比 YOLO 慢）。
- 旧工作流需要重接：删掉 `positive`/`ref_faces`/`identity_conds` 后，另加
  `UNETLoader`(sam3.1) → 「SAM3.1模型」、「CLIPLoader」+「CLIPTextEncode」→「人脸文本条件」。

---

## 2026-11-01 人脸检测换 SAM3.1 记忆追踪（SAM3_VideoTrack），掩码改轮廓

**触发**：确认 `models/checkpoints/sam3.1_multiplex_fp16.safetensors`（1.7G）在盘上，
键前缀 `detector.*`(1133) / `tracker.model.*`(457)，**文本编码器内置在
`detector.backbone.language_backbone.*`(736)**。ComfyUI `model_detection.py:1371`
有专门分支处理「detector./tracker. 在顶层、无公共前缀」的权重，`SAM3.text_encoder_key_prefix`
也是这个前缀 → **`CheckpointLoaderSimple` 一个节点同时出 MODEL + CLIP**，不需要
UNETLoader，也不需要单独下 CLIP。文件放 checkpoints 是对的。

**为什么换**：`SAM3_Detect` 是逐帧独立检测，帧间无身份关联，靠 IoU 猜"这帧第 0 个
框是不是上帧那个"→ 快速换位/擦身/短暂遮挡必串脸。`SAM3_VideoTrack` 走 memory
tracker，obj_id 全程稳定，且直接给像素级掩码 —— 我们最终要的就是掩码，不必先退化
成矩形框再画回来。

**改动**
| 文件 | 改什么 |
|---|---|
| `_facefix/detection.py` | 改调 `SAM3_VideoTrack.execute`（`max_objects=8`、`detect_interval=1`）；输出 `packed_masks` 用官方 `unpack_masks` 解包 → 4 维合并后 bilinear 放大到原图（**bilinear 只吃 4 维，5 维必炸**，首次自检就抓到）；obj 维直接当身份，删掉 `_iou`/`_associate_tracks`/`_dedupe`/`SAM3_REFINE` |
| `_facefix/masks.py` | 新增 `frame_masks` 优先路径：轮廓掩码只做 `PIXEL_FEATHER=5` 轻微羽化（框路径仍是 16）；报告区分「轮廓掩码 / 人脸框掩码」 |
| `_facefix/pipeline.py` | 把 `det.get("frame_masks")` 传进 `build_masks` |
| 端口 | **零变化**，仍是 `sam3_model` + `sam3_cond` |
| `_selftest_facefix.py` | 33→40 项：伪节点 + 真 `pack_masks` 打包，验「两个身份各有对象 / 身份0 两帧续上 / 身份1 中途出现不乱编号 / 并集掩码形状」；新增轮廓掩码 vs 框掩码两条路径对比 |

**接线（真机）**
```
CheckpointLoaderSimple(sam3.1_multiplex_fp16.safetensors)
  ├─ MODEL → 人脸修复台「SAM3.1模型」
  └─ CLIP  → CLIPTextEncode(文本 face) → 「人脸文本条件」
```

**验收**：`_selftest_facefix.py` 40 项全过；`py_compile` 通过；`_selftest_pycompat` 0 失败。

**已知问题**
- `CheckpointLoaderSimple` 会顺带构造一个空 VAE（本权重无 `first_stage_model.*`），
  输出口别接任何东西；若它直接报错，改用 `CheckpointLoaderSimple` 的
  `output_vae=False` 等价路径（暂无该开关，需换 `load_checkpoint_guess_config` 手搓）。
- SAM3 与 H3 同驻显存，3090 24G 上检测后二采可能要重载 H3。
- `max_objects=8` 是硬上限，群像超过 8 张脸会被截断。

---

## 2026-11-01 人脸修复台前端：面板压住端口 + 幽灵端口

**现象（用户截图）**：DOM 面板盖住最后一行端口「多身份条件(可选)」，卡片内容被裁到只剩
「全自动」一行，节点底部还有一片空白；左侧端口列同时出现已删除的「参考脸 / 正条件 /
多身份条件」。

**根因（两条，互相独立）**
1. **节点高度是手算的**：`setSize([w, 标题高 + panelHeight()])` 只算了 DOM 面板内容高，
   没算输入端口占的行高 → 面板起点在端口之后，但容器总高不够 → 面板底部被 `overflow:hidden`
   裁掉，视觉上就是"盖住端口 + 底部空白"。
   **正解：高度由 `node.computeSize()` 推**（它会把 inputs 行高与各 widget 的 computeSize
   一起加），且 DOM widget 必须同时声明 `computeSize`（旧引擎）与 `computeLayoutSize`（v2）
   两个通道，缺一个就按默认值排 —— 这和 `js/banzhang_lora_loader.js` 的做法一致。
2. **幽灵端口**：litegraph 的 `configure` 照抄存档 `inputs` 数组重建 slot，旧工作流的
   `ref_faces/positive/identity_conds` 虽然后端已删，前端照样画出来。
   **正解：`onConfigure` 后按后端 schema（`node.constructor.nodeData.input`）过滤 inputs，
   倒序 `removeInput`** —— 白名单只认 schema 这一个真值，不另维护一份端口表。

**改动**：只改 `js/banzhang_facefix.js`
- 新增 `nodeHeight()`（走 `node.computeSize()`）、`knownInputs()` / `pruneStaleSlots()`
- `domWidget.computeSize` 与 `computeLayoutSize` 都返回真实内容高（原来只有后者、且写死 120）
- `onResize` 的高度分支改用 `nodeHeight()`；`onConfigure` 的 rAF 里清端口 + `applySize()`

**验收**：`node --check`(.mjs) 通过；后端自检 40 项仍全过（本次未动 Python）。
**真机待确认**：`Ctrl+F5` 后重新打开旧工作流 —— 端口应只剩 6 个（一采潜空间 / SAM3.1模型 /
人脸文本条件 / 检测帧 / 解码VAE / H3修复模型），面板完整落在端口下方，无遮挡、无底部空白。

---

## 2026-11-01 人脸修复台集成 CLIPTextEncode（提示词进面板，少接一个节点）

**用户口径**：CheckpointLoaderSimple 的 CLIP 直接接节点，把 CLIPTextEncode 省掉，
前端给一个可编辑的提示词输入框。

**改动**
| 文件 | 改什么 |
|---|---|
| `banzhang_facefix.py` | 端口 `sam3_cond`(CONDITIONING) → **`sam3_clip`(CLIP)**；新增 required `sam3_prompt`(STRING, default `face`)；`run` 签名同步 |
| `_facefix/detection.py` | 新增 `encode_prompt(clip, text)`：`clip.encode_from_tokens_scheduled(clip.tokenize(t))`，等价 CLIPTextEncode；空文本回退 `DEFAULT_PROMPT="face"`；`DEFAULT_PROMPT` 常量 |
| `_facefix/pipeline.py` | `execute` 增 `sam3_clip` / `sam3_prompt`，先编码再检测；编码失败直接原样透传并给中文说明 |
| `js/banzhang_facefix.js` | `sam3_prompt` 隐藏（原生 widget 收起），工具栏放真输入框双向同步；端口标签改「SAM3.1文本编码」；空态文案同步 |
| `_selftest_facefix.py` | 40→44 项：端口改 5+3、断提示词默认 face、新增 [0d] 编码段（缺 CLIP / 中文提示词 / 空文本回退） |

**接线简化**
```
CheckpointLoaderSimple(sam3.1_multiplex_fp16)
  ├─ MODEL → 「SAM3.1模型」
  └─ CLIP  → 「SAM3.1文本编码」     ← 不再需要 CLIPTextEncode
面板顶部输入框填 face（或「人脸」）
```

**注意**
- 提示词在 `input` 事件只同步 widget 值，`change`（失焦/回车）才标脏工作流。
- `sam3_prompt` 隐藏后不占高度（`computeSize=()=>[0,-4]`），值仍随存档保存。
- 旧工作流的 `sam3_cond` 连线会掉，重新接 CLIP 即可。

**验收**：自检 44 项全过；`py_compile` 通过；`node --check`(.mjs) 通过；pycompat 0 失败。

---

## 2026-11-01 掩码保留契约：放大节点不再抹掉上游 noise_mask

**背景**：人脸修复台把脸区掩码写进 `latent["noise_mask"]`，但两个放大节点都会把它冲掉
——`H3 Latent放大` 无条件写 `NestedTensor((全1 视频, 音频掩码))`（原 `:942`），
`H3 终极放大` 的 `piece` 根本不携带掩码（`{"samples": ...}`）。结果：修复台接在放大之前
等于白做，且不报错。

**契约（新增，写进代码注释）**：`noise_mask` 是跨节点的「保留区声明」，谁都没有权限把
别人标好的保留区改成重绘区。多方掩码冲突一律**逐元素取小**（谁更保守听谁的）。

**改动**
| 文件 | 改什么 |
|---|---|
| `banzhang_h3_latent_upscaler_3d.py` | 新增 `_fit_video_mask()`（掩码按输出尺寸 trilinear 缩放 + 搬设备）；`_attach_audio_repaint_mask(..., prev_mask=None)` 视频支改为「有上游掩码就沿用、没有才全 1」；两处调用传 `prev_mask=latent.get("noise_mask")`（含不缩放分支） |
| `banzhang_mmh3_upscale.py` | 新增 `_merge_masks()` / `_fit_prev_mask()`；`_sample_spatial_tiled` / `_sample_temporal_windows` 增 `prev_mask` 参数；整幅两处 + 逐块一处改 `_merge_masks(...)`；逐块路径按分块轴切 `tile_prev`；主节点入口取掩码 → 放大后 `_fit_prev_mask` 对齐 → 传两处 → **输出写回 noise_mask（音频支全 0）** |

**关键细节**
- `_merge_masks` 遇到 NestedTensor（时间锁掩码）时**只合视频支**，音频支原样保留 ——
  否则时间分块的音频锁定会被这一步悄悄丢掉。
- 输出掩码必须与 `out_v` **同设备**，否则下游 `pack_latents` 的 `torch.cat` 跨设备报错。
- 上游没有 `noise_mask` 时两个节点行为**逐字不变**（向后兼容），这一点是改造的底线。

**验收**：两文件 `py_compile` 通过；`_selftest_pycompat` 0 失败；人脸修复台 44 项自检不受影响。
离线数值验证：单流取交集 mean 0.25 保持、nested 音频支全 0 保留、None 直通、
放大 8→12 后掩码覆盖率仍 0.25。

**真机待确认**：重启 ComfyUI 后，链路 `一采 → 人脸修复台 → 终极放大/Latent放大 → 二采`
跑一段，看 ①脸区是否被改、背景是否不动 ②日志有无「视频沿用上游局部掩码」/ 掩码相关报错
③分块接缝是否变差。
