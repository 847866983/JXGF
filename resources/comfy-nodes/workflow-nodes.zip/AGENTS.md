# AGENTS.md — AI 协作指令（班长全家桶 ComfyUI-Banzhang-All）

> 本文件是所有 AI 编程助手（豆包 / Cursor / Claude Code / Codex / Aider 等）在本仓库工作的**入口指令**。
> 开始任何任务前先读完本文件；涉及节点开发时，**必须先完整读 `docs/AI节点开发铁律.md` 再动手**。

## 项目是什么

ComfyUI 自定义节点包「班长全家桶」v2.1.1，Windows 便携版环境：
- 包根目录（本目录）：`K:\ComfyUI_windows_portable\ComfyUI\custom_nodes\ComfyUI-Banzhang-All`
- Python：`K:\ComfyUI_windows_portable\python_embeded\python.exe`（3.12）
- 节点后端：根目录 `banzhang_*.py` / `csglide_*.py`；统一在 `__init__.py` 注册
- 节点前端：`js/*.js`（ES module，经 ComfyUI 自动加载）
- 工作流模板与生成/校验脚本：`templates/`
- 设计与使用文档：`docs/`
- 用户面板语言：**中文**；代码内部标识（类名/端口 name/widget 名/JSON 键/API 字段）：**英文蛇形，禁止汉化**

## 开工前强制流程

1. **新建或修改任何节点（尤其含 `addDOMWidget` / 自定义界面 / 自定义绘制）前**：
   完整阅读 **`docs/AI节点开发铁律.md`**，并严格照做；带界面节点直接照抄其第 11 节标准骨架，
   不要自行发明节点高度/布局代码。参考实现：`js/banzhang_lora_loader.js`（内容行高型面板）、
   `js/minimax_h3_preview.js`（宽度公式型面板）。
2. 改既有文件前先通读原文件与同目录相邻实现，保持原有风格与中文注释习惯；
   修改本包既有 `.py/.js` 前留 `.bak`，不动第三方插件目录。
3. 涉及「AI 制片中枢」（banzhang_producer / templates / 导演台 h3 配置）时，
   先读 `docs/H3-Producer-AI制片中枢-执行方案.md` 与 `docs/H3-Producer-AI制片中枢-使用说明.md`；
   帧账（首段 360 帧 / 续段 379 帧等）是禁改常量，以方案文档为准。
4. 端口中文标签走前端 JS 的 `slot.label` 钉名机制（参照 `js/csglide_cast.js` pinLabel），
   新增端口必须同步登记，否则界面裸显英文。

## 交付前强制验证

- Python：`.\python_embeded\python.exe -m py_compile <改动的.py>`
- **Python 版本兼容：`.\python_embeded\python.exe _selftest_pycompat.py` 必须 0 失败。**
  用户侧 Python 版本不受控（实测有 3.11.6），而 PEP 701（f-string 表达式里允许反斜杠）
  是 **3.12 才有的**；`ast.parse(feature_version=)` 拦不住它，这个脚本自己在 token 流上数。
  栽过的事故：`banzhang_vram_cleaner.py` 一行 `f"{'\n   ' + note}"` → 整个模块 import 失败 →
  「🧹 全能系统净化 / 🛡️⚡ 显存守卫」两个节点静默消失 → 用户侧
  `invalid prompt: missing_node_type`。
- JS：`node --check <改动的.js>`
- 制片中枢：跑 `templates\producer_selftest.py`、`templates\validate_templates.py`，无 ✗/FAIL
- 前端布局类改动：代码校验之外，必须让用户真机过铁律第 12 节 6 步验收，不得自行宣称显示正常
- 最终交付物通过文件交付通道给到用户，并说明哪些项已验证、哪些待真机确认

## 高频事实（避免重复踩坑）

- ComfyUI 前端有新旧两套布局引擎：旧 litegraph 走 `widget.computeSize`，v2 VueNodes 走
  `computeLayoutSize / options.getMinHeight 等`，DOM widget 缺省 minHeight=50px —— 尺寸必须双通道声明。
- 隐藏原生 widget 只用 `hidden=true + computeSize=()=>[0,-4] + draw/mouse 空函数`；
  **禁止改 widget.type**（v2 不识别且破坏刷新恢复）。
- 节点高度是推导值不是存储值：禁止手算高度 + 固定像素补偿、禁止只增不减；
  刷新（configure）后必须重算高度。详见铁律第 2 节。
- 面板状态双写持久化：widget.value + node.properties；恢复时 properties 优先。
- **「为了性能」加的全局钩子（推迟 / 节流 / 合并 / 钳制）必须先分两类写入**：
  用户直接操作的写入（拖边角、拖滑块、打字）永远实时，代码自发的写入（扩展重算布局、
  批量刷新）才可推迟或合并。判定条件必须精确到「是不是这次交互的目标对象」（如
  `canvas.resizing_node === node`），**不能只用「是否在交互中」这种粗粒度状态** ——
  否则用户亲手拖的边角也被推迟，表现就是「鼠标在动、节点不动」，用户报的「卡顿」。
  但重绘合并是例外：合并后的 `setDirtyCanvas` **必须**仍按 `(true, true)` 全量重绘发出。
  新版前端 `GraphView` 有一条 DOM→节点的单向尺寸覆盖 —— 只要 `liteNode.size` 与 Vue 算出的
  `layout.size` 不相等就用 `layout.size` 覆盖（**不是取大**）。只脏前景会让 DOM 容器高度跟不上
  节点高度，触发这条覆盖 → **手动拉大的节点松手瞬间缩回原尺寸**。这是功能依赖，不是性能债。
- **尺寸纠正不要选时机，要挂在 `onResize` 上**（2026-10-26 连错 4 次的教训）：
  按住 Alt 复制带 DOM 面板的节点，前端在 `handleDragEnd` 用 Vue 默认布局覆盖副本宽度
  （实测 672 → 270），高度按宽度推导 → 493 变 275，正好缩一半。
  任何「事后纠正」—— rAF / 双 rAF / `pointerup` + `setTimeout` 兜底 —— 都可能早于这次覆盖
  而被吃掉，看起来"改了没生效"。**`onResize` 不是时机选择，而是尺寸唯一的写入口，谁改尺寸
  都得从这过。** 做法：宽度真值双写 `node.properties`（高度保持推导、不记忆），在
  `onResize` 里用 `app.canvas.resizing_node === this` 分流 —— 是用户亲手拖边角就记真值，
  否则（Vue 覆盖 / configure / 折叠）立刻 `setSize` 拉回；`setSize` 会再触发 `onResize`，
  用一个 `_bz_fixingW` 标志防重入（一层递归即收敛）。
  **VHS（VideoHelperSuite）参考不出方案**：它没有任何尺寸记忆/纠正代码
  （`node.size =` 0 处、`properties` 存尺寸 0 处、`onResize` 0 处，`fitHeight` 只有一行），
  高度纯由 `node.size[0]` 推导，只是没人拉宽它，所以同样被覆盖却不显眼。
- 查上游（ComfyUI 前端）的真实行为别凭记忆：未压缩源码在
  `python_embeded/Lib/site-packages/comfyui_frontend_package/static/assets/*.js.map`，
  超长单行用 `grep -o -E "关键字.{1400}" xxx.js.map | head -2` 逐段往后扒上下文。
