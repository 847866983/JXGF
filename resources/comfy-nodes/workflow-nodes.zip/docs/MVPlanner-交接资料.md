# 🎬 MV 规划台（BanZhang_MVPlanner）交接资料

> 本文档面向**接手继续开发的 AI / 开发者**，自包含：读完即可在不依赖历史对话的情况下理解现状、约束、算法与待办。
> 最后更新：2026-10-29。节点当前处于「可运行、待真机验收」状态。

---

## 0. 一句话概述

在 ComfyUI 自定义节点包「班长全家桶」内新增的**独立单节点**：把一首任意时长的歌曲（2 分钟 / 3 分钟 / 更长都**不写死**）按 H3 帧账自动拆成若干约 15 秒片段，可选接入现有 Qwen3VL 本地模型自动生成每段分镜提示词，再通过现有导演台的续拍能力逐段生成人物唱歌 MV，最后合并成片。

**核心隔离原则（最高优先级）**：不改动现有媒体架 / 文案台 / 导演台 / 制片中枢任何一行代码。新节点只通过现有节点已经存在的标准端口与其通信；删掉新文件并撤回注册行，现有工作流逐字不变。

---

## 1. 运行环境与项目根路径

| 项 | 值 |
|---|---|
| 包根目录 | `K:\ComfyUI_windows_portable\ComfyUI\custom_nodes\ComfyUI-Banzhang-All` |
| Python | `K:\ComfyUI_windows_portable\python_embeded\python.exe`（本机 3.12；**用户侧实测有 3.11.6，必须兼容 3.11**） |
| Shell | Windows / PowerShell 7（**没有 Bash 工具**，所有命令走 PowerShell） |
| 前端目录 | `js/`（ES module，ComfyUI 自动加载，无需改配置） |
| 节点后端 | 包根目录 `banzhang_*.py`，统一在 `__init__.py` 注册 |

### 强制验证命令（改完必须跑，全部 0 失败才算完）

```powershell
$py = "K:\ComfyUI_windows_portable\python_embeded\python.exe"
$root = "K:\ComfyUI_windows_portable\ComfyUI\custom_nodes\ComfyUI-Banzhang-All"

# 1. Python 单文件编译
& $py -m py_compile "$root\banzhang_mv_planner.py"

# 2. Python 版本兼容自检（必须 23 通过 / 0 失败；PEP 701 f-string 反斜杠是 3.12 专属，3.11 会炸）
& $py "$root\_selftest_pycompat.py"

# 3. JS 语法检查
node --check "$root\js\banzhang_mv_planner.js"
```

> 历史事故：`f"{'\n   ' + note}"` 这类把反斜杠写进 f-string 表达式的写法，在 3.11 下整个模块 import 失败、节点静默消失。**新代码禁止在 f-string 表达式里放反斜杠**，先算成变量再插入。

---

## 2. 本次新增 / 修改的文件

| 文件 | 状态 | 说明 |
|---|---|---|
| `banzhang_mv_planner.py` | **新增** | 后端节点本体，自带 `NODE_CLASS_MAPPINGS` / `NODE_DISPLAY_NAME_MAPPINGS` |
| `js/banzhang_mv_planner.js` | **新增** | 苹果风三栏 DOM 面板 + 歌曲槽位 / 播放器 / 频谱 |
| `__init__.py` | **修改（仅注册）** | 加了一个 `try-import` 块 + 映射表各一行；改动前备份为 `__init__.py.bak_mvplanner_20261029` |

**没有改动**：`csglide_cast.py`（导演台）、`csglide_desk.py`（文案台）、`csglide_media_rack.py`（媒体架）、`banzhang_producer.py`（制片中枢）及其任何前端。

### `__init__.py` 里的注册片段（结构照抄现有 try-import 风格）

```python
# 27. 🎬 MV 规划台：独立外挂节点，只通过标准 STRING 端口驱动导演台
try:
    from . import banzhang_mv_planner
    MVPlan_Cls = getattr(banzhang_mv_planner, 'NODE_CLASS_MAPPINGS', {})
    MVPlan_Names = getattr(banzhang_mv_planner, 'NODE_DISPLAY_NAME_MAPPINGS', {})
except Exception as e:
    print(f"⚠️ [班长全家桶] MV 规划台节点加载失败: {e}")
    MVPlan_Cls, MVPlan_Names = {}, {}
```

然后在 `NODE_CLASS_MAPPINGS` 末尾加 `**MVPlan_Cls,`，`NODE_DISPLAY_NAME_MAPPINGS` 末尾加 `**MVPlan_Names,`。

---

## 3. 节点规格

- **class_type**：`BanZhang_MVPlanner`
- **显示名**：`🎬 MV 规划台 (Music Video Planner)`
- **分类**：`👨‍🏫班长/MV制片`
- **FUNCTION**：`run`

### 3.1 输入（required 是隐藏 widget，optional 是可见端口）

| 内部 name（**英文蛇形，禁止汉化**） | 类型 | 性质 | 界面中文 label（前端钉名） | 说明 |
|---|---|---|---|---|
| `project_data` | STRING | 隐藏 widget | — | 完整工程 JSON，前端双写持久化，刷新恢复 |
| `action` | STRING | 隐藏 widget | — | 动作分发：`idle` / `analyze` / `generate_one` / `generate_all` |
| `current_index` | INT | 隐藏 widget | — | 当前选中段索引 |
| `audio_path` | STRING | 隐藏 widget | — | 歌曲相对/绝对路径（上传后写入） |
| `audio` | AUDIO | 可见端口 | 歌曲音频 | 可选，管线音频对象 `{waveform:[B,2,N], sample_rate}` |
| `refs` | H3_REFS | 可见端口 | 参考素材 | 可选，接「H3 媒体架」的「参考素材」口。planner 只数有效图数量用来补 `@图片N` 标签，图本身不经过 planner（详见 §5.8） |
| `qwen_config` | QWEN3VL_MODEL_CONFIG | 可见端口 | Qwen配置 | 可选，接现有「🍭 Qwen3VL 模型配置」节点 |
| `person_image` | IMAGE | 可见端口 | 人物参考图 | 可选，`[B,H,W,3]`，作为 Qwen 视觉参考 |
| `temperature` | FLOAT | 可见端口 | 温度 | 默认 0.7 |
| `max_tokens` | INT | 可见端口 | 最大Token | 默认 2000 |

> 端口中文不是在后端 `INPUT_TYPES` 里写中文，而是**前端 JS 遍历 `node.inputs` 给 `slot.label` 赋值**（见 §7.4）。后端 key 永远英文。

### 3.2 输出（顺序固定，下游按序号接）

| 序号 | RETURN_NAMES | 类型 | 去向 |
|---|---|---|---|
| 0 | 当前段提示词 | STRING | → 导演台 optional 口 `prompt_text` |
| 1 | 当前段h3配置 | STRING | → 导演台 optional 口 `h3_override` |
| 2 | 完整工程JSON | STRING | 调试 / 级联，前端执行后回写面板 |
| 3 | 编排报告 | STRING | 状态文字，显示在面板底部状态行 |

---

## 4. 工程 JSON 数据结构（`project_data` / 输出 2）

前端 `state.project` 与后端 `project` 是同一份结构，序列化进 `project_data` widget 与 `node.properties.mv_project`。

```jsonc
{
  "project_name": "未命名MV",
  "canvas": { "width": 576, "height": 320 },
  "audio": {
    "path": "mv_planner/song.mp3",   // input 相对路径或绝对路径
    "sample_rate": 44100,
    "duration": 180.33,              // 秒，分析后回填
    "bpm": 128.4,
    "beat_times": [0.23, 0.70, ...]  // 节拍时间点（秒）
  },
  "segments": [
    {
      "index": 0,
      "total_frames": 362,          // 送导演台的段总长（含头钉）
      "net_frames": 362,            // 净画面帧
      "head_overlap": 0,            // 首段 0；续段 22
      "start": 0.0,                 // 净画面在整曲时间轴的起点（秒）
      "end": 15.083,
      "lyric": "",                  // 手填歌词/旁白
      "mood": "",                   // 手填情绪/风格
      "prompt": "",                 // Qwen 生成或手改的画面提示词
      "status": "pending",          // pending / ready / done
      "shot": ""                    // 可选，自定义 shot id
    }
  ]
}
```

### 段状态色（前端）

- `pending` 橙 `#FF9F0A`
- `ready` 绿 `#30D158`
- `done` 蓝 `#0A84FF`

---

## 5. 后端算法详解（`banzhang_mv_planner.py`）

### 5.1 帧账常量（与 `banzhang_producer.py` 对齐，**禁改**）

```python
FPS = 24
FIRST_FRAMES = 362        # 首段 362 帧 = 15.083s
NEXT_TOTAL_FRAMES = 379   # 续段总长（含 22 帧头部重叠）
HEAD_OVERLAP = 22         # 续段头钉/头部重叠
NEXT_NET_FRAMES = 357      # 续段净帧 = 379-22 = 14.875s
MIN_LEGAL_FRAMES = 22
```

H3 合法帧长网格 = **5 + 17n**（n≥1）。`_snap_legal_frames(frames)` 把任意目标帧长吸附到最近合法值。

### 5.2 动态分段 `_plan_segments(duration)`（时长绝不写死）

1. 若整曲 ≤ 首段时长：整曲一段，帧长吸附到 `5+17n`。
2. 否则首段固定 `362` 帧、`head_overlap=0`。
3. 循环规划续段：
   - 剩余时长 ≤ `357/24 + 0.6` 秒 → 进入**末段**：净帧 = `_snap_legal_frames(剩余秒×24)`，总长 = 净帧 + 22。
   - 否则标准续段：总长 379、净帧 357、头钉 22。
4. `start/end` 用净帧累计（续段按净 357 帧推进时间轴，头钉是承接上一段的重叠，不占新时长）。

**实测覆盖**（已跑单元验证）：

| 歌曲时长 | 段数 | 覆盖时长 | 帧长序列（首段/续段/末段） |
|---|---|---|---|
| 120s（2 分钟） | 9 | 120.12s | 362, 379×7, 44 |
| 180s（3 分钟） | 13 | 180.33s | 362, 379×11, 61 |
| 270s（4.5 分钟） | 19 | 270.29s | 362, 379×17, 78 |
| 60s | 4 | 59.92s | 362, 379×2, 384 |
| 15s | 1 | 15.08s | 362 |

> 末段 `total_frames` = 净帧 + 22，所以末段数字（44/61/78）看起来不在 5+17n 上；**净帧**才在网格上，核对时别搞错。

### 5.3 音乐分析 `_analyze_music(waveform, sr)`

- 优先用 `librosa.beat.beat_track` 取 BPM 与节拍帧，`frames_to_time` 转秒。
- 先重采样到 22050 再分析。
- **分析失败只记 `error` 到报告，不阻断分段**（librosa 是增强项，不是硬依赖）。

### 5.4 音频来源 `_resolve_audio(audio_input, audio_path)`

1. 优先 AUDIO 端口张量。
2. 否则走 `audio_path`：`_resolve_input_path` 先当绝对路径，找不到再拼 `folder_paths.get_input_directory() + path`（前端上传落 `input/mv_planner/`）。
3. 解码复用公共层 `csglide_audio_io.decode_audio_file`（soundfile → PyAV → torchaudio 三后端降级），**不自己写解码器**。

### 5.5 动作分发（`run` 内）

| `action` | 行为 |
|---|---|
| `analyze` | 取音频 → 算时长 → librosa 分析 → `_plan_segments` 重建段表；**已有同索引段的 lyric/mood/prompt/status 保留**，只刷新时间码与帧长 |
| `generate_one` | 仅对 `current_index` 段调 Qwen |
| `generate_all` | 循环所有段调 Qwen |
| `idle`（默认） | 透传工程，只输出当前段两个 STRING |

### 5.6 Qwen 复用 `_qwen_generate(...)`

- **不重写推理**：`from .banzhang_translator.banzhang_ai_translator import BanzhangAITranslator`，无参构造后直接调其私有入口 `_run_local_inference(config, system_prompt, user_prompt, media_seq, fps, max_tokens, temperature, max_side)`，返回 `(report, generated_text)`。
- `media_seq` 元素：图片 `{"kind":"image","no":1,"tensor":person_image}`。本地推理会跳过音频（仅 API 模式支持音频直传）。
- `system_prompt` 是内置 MV 分镜导演人设；`user_prompt` 拼段序号、时间码、歌词、情绪。
- 生成成功 → `seg.prompt`、`seg.status="ready"`；失败 → 报告写警告，不清空旧提示词。

### 5.7 当前段 h3 配置 `_build_h3_override(seg, project, clip_id, shot_id)`

构造的 JSON 字段**严格对齐导演台 `parse_h3_data` 白名单**（`csglide_cast.py:906`），白名单外的键会被导演台丢弃，别往里加。要点：

- `mode: "ref2va"`；`width/height` 取 `project.canvas`；`length = seg.total_frames`
- `pin_head`：首段 0，续段 22；`pin_tail: 0`（导演台会自动把钉尾抬到下一段的 `trim_frames`，见 `csglide_cast.py:2745`，不用 planner 操心）
- **`cont: {"mode": "latent", "frames": 22}`**（首段 `frames: 0`）。
  ⚠️ **承接的唯一开关是 `cont.frames`**（`csglide_cast.py:2252` 第一道门就是 `frames <= 0 → return cond, 0`），`mode` 只决定走文件档还是潜空间档。20261029 之前的版本只写了 `mode`，导致 13 段跑出来是 13 个独立片段、段间人物长相全跳。潜空间档另需 `latent_file` 或「档案 order 里真有上一段」（`csglide_cast.py:2267`），后者由导演台「全部渲染」或 ClipArchive/ClipAdopt 写入。
- **`slots.audios[0] = {file, start, end}`**：填整曲路径 + 本段净画面窗口（秒），**不需要提前切音频文件** —— 导演台 `_load_audio(slot["file"], start, end)` 自己按窗口从整曲里截（`csglide_cast.py:565`），参考音频上限 `ref_audio_limit_seconds(片长)` 恰好等于片长，15 秒段 100% 覆盖（覆盖 76% 就会换嗓子，20261026 实测）。独立音频**不参与**「提示词没写 `@音频N` 就丢」的按需过滤（`csglide_cast.py:1710` 明写无条件发送），所以槽位填上就一定会送。
  `file` 必须是 **input 相对路径**：导演台 `resolve_asset`（`csglide_assets.py:59`）只往 input 目录上拼，绝对路径会被拼坏并抛 `FileNotFoundError`。planner 用 `_audio_ref_for_cast()` 做这层转换，转不出来就留空槽位（宁可不挂音频，也不要炸掉整段）。
- `chain: {name, clip, shot}`：`clip_id = "clip_%04d" % (cur+1)`，`shot_id` 取段内 `shot` 或 `shot_%04d`
- `slots` 空槽位：images 9 / videos 3，`first/last` 空对象；`audios` 见上条
- `push_whole: false`，`bridge_alpha: 0`，`pace: 2.5`

> **续段承接机制（重要，别重复造轮子）**：导演台靠**工程档案系统**（`csglide_chain` 的 chain/clip 档案 + `order` 列表 + 段尾归位 `ClipAdopt` 写 `cont_saved`）自动找上一段承接档。planner 只负责给每段正确的 `chain` 身份；**段尾归位仍由现有 ClipArchive + ClipAdopt 节点完成**，planner 不写档案、不碰链路代码。

### 5.8 人物参考图：接媒体架，且必须写进提示词（20261029 定案）

这一条踩过两次坑，两处的机制都不一样，写清楚免得再绕：

1. **图不用 planner 转存**。媒体架「参考素材」(`H3_REFS`) 直接接**导演台**的 `refs` 口。
   导演台 `_merge_rack_refs` 在 `parse_h3_data` **之后**执行（`csglide_cast.py:2944`），
   会用媒体架的槽位覆盖同编号位置 —— planner 再往 `slots.images` 里填一遍是重复且会打架。
2. **但提示词里必须有 `@图片N`**。导演台对**图片是按需发送**：提示词一个 `@标签` 都没提
   就整类不送（`csglide_cast.py:1730 kept[kind] = ... if any_keep else []`）。
   音频才是不参与过滤的特例（`1710`）。所以「媒体架摆好了人物图、Qwen 没写标签」
   = 图白摆，13 段跑出来主角长相逐段漂移 —— 这是接参考图最常见的失效方式。
3. 因此 planner 加了一个可选 `refs`（`H3_REFS`）端口，**只为数一下有几张有效图**，
   然后 `_ensure_ref_tags()` 在提示词末尾补 `@图片1 @图片2…`（已有 `@图片` 就不重复补）。
   planner 不读图、不转存、不碰媒体架内部。

> 验收口径：终端出现「【参考素材】按需发送：@图片1」才算图真的进去了。
> 只看到「提示词未引用任何 @标签，本次不送参考」就是标签没补上。

---

## 6. 端到端流程

```mermaid
flowchart TD
    A[拖入歌曲到规划台槽位<br/>或接 AUDIO 端口 / 填路径] --> B[前端上传 /upload/image<br/>落 input/mv_planner/]
    B --> C[点「分析歌曲」→ action=analyze]
    C --> D[后端 librosa 取时长/BPM/节拍]
    D --> E[动态分段 _plan_segments<br/>首段362 · 续段净357 · 末段吸附]
    E --> F{是否接 Qwen 配置?}
    F -- 是 --> G[点「生成当前段 / 全部生成」<br/>action=generate_one/all]
    G --> H[_run_local_inference 本地推理<br/>输出每段 prompt]
    F -- 否 --> I[手填歌词/情绪/提示词]
    H --> J[左栏选当前段]
    I --> J
    J --> K[输出0 prompt_text → 导演台]
    J --> L[输出1 h3_override → 导演台]
    K --> M[导演台逐段生成<br/>首段 → 续段潜空间承接]
    L --> M
    M --> N[现有 ClipArchive + ClipAdopt<br/>段尾归位写 cont_saved]
    N --> O{还有下一段?}
    O -- 是 --> J
    O -- 否 --> P[现有合并/插帧/超分节点出整片]
```

### 标准工作流接线（下游复用现有节点，不要在规划台里重做）

1. 规划台「当前段提示词」→ 导演台 `prompt_text`
2. 规划台「当前段h3配置」→ 导演台 `h3_override`
3. 导演台输出后面接现有**段档案**与**段尾归位**节点（参考现有三采工作流里的 ClipArchive / ClipAdopt 接法）
4. 逐段排队：左栏切段 → 导演台跑该段 → 归位 → 切下一段
5. 全部段跑完后走现有视频合并 / RIFE 插帧 / RTX 超分出片

---

## 7. 前端实现详解（`js/banzhang_mv_planner.js`）

### 7.1 结构骨架（DOM 尺寸双通道，铁律）

- `app.registerExtension({ name: "BanZhang.MVPlanner", beforeRegisterNodeDef(nodeType, nodeData) })`，`nodeData.name === "BanZhang_MVPlanner"` 才挂载。
- `chainCallback` 风格的 `chain(target, name, fn)` 包装 `onNodeCreated / onConfigure / onResize / onConnectionsChange`，先调原方法再跑自定义。
- `node.addDOMWidget("mv_planner_panel", "mv_planner", root, { serialize: false })`；创建后 `node.widgets.unshift(node.widgets.pop())` 把 DOM widget 挪到 widgets 最前。
- **双通道尺寸声明**（新旧两套前端布局引擎都要覆盖）：
  ```js
  domWidget.computeLayoutSize = () => ({ minHeight: PANEL_H, maxHeight: undefined, minWidth: 0 }); // v2 Vue
  domWidget.computeSize = () => [node.size[0], PANEL_H];                                      // 旧 litegraph
  ```

### 7.2 布局常量与高度推导

```js
const PANEL_W = 700;
const MIN_W = 560;
const W_KEY = "mv_width";
const TOOLBAR_H = 46;
const SLOT_H = 140;      // 118 时减掉播放器行和进度条，频谱只剩约 50px，跳动几乎看不出来
const BODY_H = 300;
const STATUS_H = 20;     // .bz-mv-status 实际是 height:16 + padding-top:4 = 20px
// 只作首帧兜底（root 还没进 DOM 时 offsetHeight 为 0），真正用的是 panelH()
const PANEL_H_FALLBACK = 20 + TOOLBAR_H + 10 + SLOT_H + 10 + BODY_H + STATUS_H;
```

- `root` 必须 `width:100%; height:auto; box-sizing:border-box`，**root 不要自己画外边框/双层框**（外层框交给节点），这是"面板不贴节点外框"事故的修复点。
- **面板高度实测，不手算**（20261029 改）：`panelH() = root.offsetHeight || PANEL_H_FALLBACK`。
  原先手算常量相加，和 CSS 实际占位对不上 —— `.bz-mv-slot` 有 1px 边框却是
  `content-box`（root 的 `border-box` **不继承**给子元素）、`.bz-mv-status` 是
  `height:16 + padding-top:4`。两处各差一点，累加就是「面板底和节点底对不上」。
  带边框的块一律补 `box-sizing:border-box`，高度仍由 `onResize` 回写 ——
  **高度是推导值不是存储值**，刷新后由 `onResize` 重算，不要手存高度、不要加固定像素补偿。
- `computeLayoutSize` / `computeSize` / `onResize` 三处统一走 `panelH()`，
  任一处漏改就会错位（漏的那个还在用旧常量）。
- 隐藏原生 widget 的唯一合法写法：`hidden=true` + `computeSize=()=>[0,-4]` + `draw/mouse` 空函数；**禁止改 `widget.type`**（v2 不识别且破坏刷新恢复）。

### 7.3 页面分区

| 区域 | 位置 | 职责 |
|---|---|---|
| 工具栏 | 顶部 46px | 标题、Segmented Control（分段/Qwen/导出，目前仅视觉切换）、三个动作按钮 |
| 歌曲槽位 | 118px | 未加载：虚线拖入区；已加载：播放器 + 进度条 + 频谱 canvas |
| 左栏 200px | 片段列表，状态点 + 序号 + 时间码，点击选段 |
| 中栏 flex | 分段时间轴 canvas：时间刻度、分段色块、节拍竖线、点击定位段 |
| 右栏 220px | 歌词 / 情绪 / 画面提示词三个输入 |
| 状态行 | 16px | 执行回执、错误提示 |

### 7.4 端口中文钉名（三时机重钉）

```js
const PORT_LABELS = { audio:"歌曲音频", qwen_config:"Qwen配置",
  person_image:"人物参考图", temperature:"温度", max_tokens:"最大Token" };
function pinPortLabels(n) {
  for (const s of n.inputs || []) {
    const key = String(s.name || "").toLowerCase();
    if (PORT_LABELS[key]) s.label = PORT_LABELS[key];
  }
}
```

必须在 **`onNodeCreated`、`onConfigure`（含 rAF 补钉）、`onConnectionsChange`** 三处各钉一遍：configure 会按存档重建 slot 对象，新对象不带钉过的 label，只钉一次会回退裸英文。

### 7.5 歌曲槽位 / 播放器 / 频谱

- **上传**：`POST /upload/image`（FormData 字段名 `image` 是历史命名，音频也走它），`subfolder=mv_planner`，`overwrite=true`，返回 `subfolder/name` 相对路径。播放 URL 用 `api.apiURL("/view?filename=...&subfolder=...&type=input")`。
- **节点级拖入**：`slot` 上挂 `dragover / dragleave / drop`，只接受 `audio/*`；`dragover` 必须 `preventDefault()` 否则放不进来；`stopPropagation` 防止被画布默认行为吞掉。点击拖入区弹文件对话框。
- **播放器**：`new Audio()`；`AudioContext` + `AnalyserNode(fftSize=1024, smoothing=0.82)` + `createMediaElementSource`；**media source 只能对同一 audio 元素连一次**，用 `mediaReady` 标志防重复。
- **频谱**：rAF 循环，`getByteFrequencyData` → 40 根蓝紫渐变镜像圆角柱；`audio.paused` 时空转不写 DOM。
- **进度条**：track 点击 / 拖动 seek；`timeupdate` 更新 fill/knob/时间码。
- **移除**：`✕` 暂停并清 src，回到拖入区。

### 7.6 状态双写持久化（刷新必须恢复）

- 写入：`wMap.project_data.value = JSON.stringify(state.project)` **同时** `node.properties.mv_project = raw`；`current_index`、`action`、`audio_path` 同步各自 widget。
- 恢复：`onConfigure` 里优先读 `node.properties.mv_project`，解析后重建面板；有 `audio.path` 则静默恢复播放器（**不自动播放**，浏览器自动播放策略）。
- 用户直接操作（点段、打字、拖进度）写入必须**实时**；代码自发的批量重算才可推迟合并。

### 7.7 动作提交（只让本节点单独排队）

```js
async function submitAction(act) {
  syncProject();
  const p = await app.graphToPrompt();
  // 只提交「本节点 + 上游」：整图一起提交会把导演台/保存节点也拉起来跑一遍，
  // 用户点「分析歌曲」却得到一次几十分钟的视频生成。上游必须保留 —— prompt
  // 里上游以 [nodeId, slot] 引用，只留本节点会让引用指向不存在的节点。
  const output = upstreamOnly(JSON.parse(JSON.stringify(p.output)), node.id);
  const target = output[String(node.id)] || output[node.id];
  target.inputs.action = act;
  ...
  await api.queuePrompt(0, { output, workflow: p.workflow });
}
```

- 配套后端必须有 `OUTPUT_NODE = True`：否则本节点不是任何输出节点的上游时会被
  ComfyUI 剪枝掉，点了按钮连报告都不回。二者缺一不可。
- 另一个致命搭档是 `IS_CHANGED = float("nan")`：ComfyUI 默认按输入 hash 缓存，
  输入没变就命中缓存、根本不执行 —— 「重生成这一段」点第二次完全没反应，
  提示词纹丝不动，看起来像模型坏了。
- `syncProject()` 里会把 `action` widget 重置回 `"idle"`，所以画板 ▶ 不会被上次
  的按钮动作带偏（这条已确认正确，别误改）。
- 执行结果回写：监听 `api.addEventListener("executed", ...)`，`detail.node === String(node.id)` 时取 `out["完整工程JSON"][0]` 解析重建面板，取 `out["编排报告"][0]` 显示在状态行。
- 输出 key 是中文 RETURN_NAMES；`detail.output` 的值是数组。

### 7.8 苹果 HIG 视觉规范（现有色板）

```js
{ blue:"#0A84FF", orange:"#FF9F0A", purple:"#BF5AF2",
  green:"#30D158", red:"#FF453A",
  bg1:"#1d1d22", bg2:"#141418", line:"rgba(255,255,255,.1)" }
```

- 字体栈：`-apple-system,BlinkMacSystemFont,"SF Pro Text","Segoe UI","PingFang SC","Microsoft YaHei"`
- 毛玻璃 `backdrop-filter: blur(8px)`；圆角 10–14；按钮弹簧动效 `cubic-bezier(.34,1.4,.5,1)`。
- 成熟参考：`js/music_player_node.js`（完整播放器 + 频谱）、`js/banzhang_lora_loader.js`（内容行高型面板）、`js/minimax_h3_preview.js`（宽度公式型面板）。

---

## 8. 现有可复用资产（不要重写）

| 能力 | 位置 | 复用方式 |
|---|---|---|
| 本地 Qwen/HF/GGUF 推理 | `banzhang_translator/banzhang_ai_translator.py` → `BanzhangAITranslator._run_local_inference(...)` | 实例化后直接调 |
| Qwen 配置节点 | `banzhang_translator/qwen3vl_config_node.py`，类型 `QWEN3VL_MODEL_CONFIG` | 端口对接，不读内部 |
| 音频解码三后端降级 | `csglide_audio_io.py` → `decode_audio_file` / `resample_waveform` | 直接 import |
| 导演台续拍 / 段尾归位 / 档案 | `csglide_cast.py` / `csglide_chain.py` / ClipAdopt 系列 | **不 import、不改**，仅通过 `prompt_text` / `h3_override` 标准口对接 |
| 上传 / 拖入通用工具 | `js/csglide_rack_core.js`（`uploadFile`、`fileKind`、`viewURL`）、`js/csglide_rack_drop.js` | 可参考；当前 planner 自带了一份精简上传，避免强耦合媒体架模块 |
| 帧账 / 制片中枢模板 | `banzhang_producer.py`（`FIRST_CLIP_LENGTH=360`、`NEXT_CLIP_LENGTH=379` 等禁改常量） | 常量口径对齐即可 |

---

## 9. 铁律与禁区（接手前必读，违反必出事故）

1. **不改现有稳定代码**：媒体架、文案台、导演台、制片中枢、链路档案只做端口对接；新功能优先写在 `banzhang_mv_planner.py` / `js/banzhang_mv_planner.js`。
2. **代码标识英文蛇形**：类名、端口 name、widget 名、JSON 键、API 字段一律英文；只有面板文案和 `slot.label` 用中文。
3. **Python 兼容 3.11**：不用 3.12 专属语法；f-string 表达式内禁反斜杠；改完跑 `_selftest_pycompat.py`。
4. **尺寸双通道**：DOM widget 必须同时实现 `computeLayoutSize`（v2）和 `computeSize`（旧 litegraph）；高度推导挂 `onResize`，不手存、不补固定像素。
5. **隐藏 widget**：只用 `hidden + computeSize 零高 + draw/mouse 空函数`，禁改 `type`。
6. **重绘合并必须 `setDirtyCanvas(true, true)` 全量**；用户亲手操作的写入实时执行，代码自发写入才可推迟。
7. **帧账常量禁改**：首段 362、续段 379/净 357、头钉 22、网格 5+17n。
8. 改既有 `.py/.js` 前留 `.bak`；不动第三方插件目录。
9. 前端布局类改动**必须由用户真机验收**（见 §10），自动化校验通过 ≠ 显示正常，不要自行宣称界面正常。

---

## 10. 当前状态与待真机验收清单

### 已自动化验证（开发侧已通过）

- `py_compile` 后端 / `__init__.py`：通过
- `_selftest_pycompat.py`：23 通过 / 0 失败，3.11 与 3.12 全过
- `node --check` 前端：通过
- 动态分段多时长单测：120/180/270/60/15 秒段数与帧账符合 §5.2 表
- `_selftest_out/_check_mv_h3.py`：**30 通过 / 0 失败** —— 覆盖 `cont.frames`、`slots.audios`
  槽位内容、绝对→相对路径转换、过导演台 `parse_h3_data` 白名单后字段不丢、
  `_filter_refs_by_prompt` 下音频仍被送出
- 节点在精简环境成功注册（缺 comfy 模块导致其他节点报 `No module named` 是测试环境正常现象，真机 ComfyUI 运行时不会出现）

### 待用户真机确认（重启 ComfyUI + Ctrl+F5 强刷后逐项过）

1. 节点出现在 `👨‍🏫班长/MV制片` 分类，五输入端口显示中文，刷新/接线后不回退英文
2. 三栏布局无错位、无裁切；面板四边贴紧节点边框，无双层框、无底部空白、无溢出
3. 拖入/点击上传音频成功，槽位切到播放器；播放时频谱跳动，暂停即停；进度条 seek 准确；`✕` 移除回到拖入区
4. 点「分析歌曲」段数与歌曲时长匹配；左栏选段、中栏点击定位、右栏编辑联动
5. 接 Qwen 配置 + 人物图，「生成当前段」提示词回到右栏；刷新工作流后歌曲与分段状态都恢复
6. 拖宽/拖窄节点，高度仍贴合，松手不回缩
7. 接上导演台：当前段提示词 / h3 配置正确送出；终端出现「音频 @音频1 … 覆盖 100%」，
   第 2 段起出现「延续（潜空间）本段承接 22 帧」（不是「承接帧数为 0」）

### 已知未实现 / 设计缺口（下一步候选，不是 bug）

- [x] ~~点面板按钮会把整张工作流重新排队~~ —— 20261029 已修：前端 `upstreamOnly` 只提交
      本节点+上游，后端补 `OUTPUT_NODE=True` + `IS_CHANGED=nan`。
- [x] ~~`analyze` 按 index 保留歌词~~ —— 20261029 已修：只有「同一首歌」（`audio.path`
      相同）才按序号继承，否则清空。
- [ ] 接 AUDIO 端口（不落文件）时 `project.audio.path` 为空，刷新后播放器恢复不了、也不能重新
      分析；且导演台只能从磁盘读音频，这种情况不填 `slots.audios`（报告里会写「未挂」）。
- [x] ~~状态行只显示报告第一行~~ —— 20261029 已修：正文仍是第一行，全文进 `title` 悬停可看。
- [x] ~~`onConfigure` 不恢复 `current_index`~~ —— 20261029 已修。
- [x] ~~宽度没双写 `node.properties` / 无 `resizing_node` 分流~~ —— 20261029 已修（铁律欠账结清）：
      宽度真值双写 `properties.mv_width`，`onResize` 用 `app.canvas.resizing_node === node`
      分流 —— 用户亲手拖就记真值，其余（Vue 覆盖 / configure / 折叠）立刻 `setSize` 拉回，
      `_bz_fixingW` 防一层递归。
- [x] ~~工具栏 Segmented Control 是纯视觉~~ —— 20261029 已删。不响应用户操作的控件
      只会让人以为界面坏了；三栏本来就是同时看的，没有切换视图的必要。
- [x] ~~人物参考图进不了导演台~~ —— 20261029 已修，**但修法和原来设想的不同**，见 §5.8。
- [x] ~~`done` 状态永远不出现~~ —— 20261029 已修：`_mark_done` 只读 `csglide_chain.film_summary`，
      有成片的段置 `done`。planner 不写档案、不改链路，读不到就保持原状态。
- [x] ~~工程名默认「未命名MV」导致不同片子共用一条 chain~~ —— 20261029 已修：默认
      `MV_<月日时分秒>`，用户一旦改名就以他的为准。
- [ ] **面板配色写死深色**（`#1d1d22` 一整套），不跟随 ComfyUI 主题。浅色主题下会是
      一整块深色。修之前要先在真机确认前端暴露的主题变量名，别凭记忆猜 --bg-color。
- [ ] 中栏目前画的是**分段时间轴 + 节拍竖线**，尚未画真实音频波形（vendor 目录有 `wavesurfer.core.min.js.txt` 可接入）；当前依赖后端 `beat_times`，未做切点拖动手动微调。
- [ ] 节拍只做了展示，**切点尚未吸附节拍**；当前严格按帧网格切分（保证时长精确）。后续可在合法帧长网格内做 ±0.5s 节拍就近微调。
- [ ] 工具栏 Segmented Control（分段/Qwen/导出）目前是纯视觉，未接独立视图切换。
- [ ] 未实现「导出分段工程 / 歌词批量导入（LRC 解析）」；右栏歌词现在逐段手填。
- [ ] 未做 Qwen 批量生成的显存占用控制（`keep_loaded` 由 Qwen 配置节点决定）；`generate_all` 逐段串行，长歌可能耗时较长，可加进度回执。
- [ ] 人物参考图目前只走 Qwen 视觉参考；尚未把参考图自动填进每段 h3 的 `slots.images`（承接媒体架/文案台的现有参考素材体系，需先确认接线约定）。
- [ ] 末段时长误差由网格吸附产生（±0.6s 内），未在面板上标注"末段加长/缩短"。

---

## 11. 建议的下一步完善优先级（给接手 AI）

1. **先补真机验收回归**：§10 清单 1–7 跑通，修任何贴边/回缩/状态恢复问题，再谈新功能。
2. **真实波形**：接入 `wavesurfer`（或复用 `music_player_node` 的 canvas 波形），中栏同时显示波形、段边界、节拍、可拖切点；切点改动写回 `seg.start/end` 并重算帧长（仍须落在 5+17n）。
3. **LRC 歌词导入**：选 `.lrc` 后按时间戳自动填进对应段 `lyric`，减少手填。
4. **参考图桥接**：明确与媒体架 / 文案台参考素材的接线方式，把人物图/风格图按规则填入 h3 `slots.images`。
5. **批量生成进度**：`generate_all` 过程在状态行回执段号，避免长歌看起来像卡死。
6. 歌词/情绪模板库、段间运镜衔接指令（首段开场、副歌、桥段、末段收尾）写进 Qwen system prompt 的分段语境。

---

## 12. 关键参考文件路径（按需要打开）

```
包根: K:\ComfyUI_windows_portable\ComfyUI\custom_nodes\ComfyUI-Banzhang-All
├─ banzhang_mv_planner.py            # 本节点后端
├─ js/banzhang_mv_planner.js         # 本节点前端
├─ __init__.py                       # 注册（try-import 块 + 映射两行）
├─ csglide_cast.py                   # 导演台：parse_h3_data 白名单(906行起)、端口/prompt_text/h3_override
├─ csglide_audio_io.py               # 音频解码/重采样公共层
├─ banzhang_translator/
│  ├─ banzhang_ai_translator.py      # BanzhangAITranslator._run_local_inference
│  └─ qwen3vl_config_node.py         # QWEN3VL_MODEL_CONFIG 类型
├─ js/
│  ├─ csglide_cast.js                # pinCastPortLabels 三时机钉名参考(243行起)
│  ├─ music_player_node.js           # 播放器 + 频谱参考(424行 ensureGraph / 727行 drawViz)
│  ├─ minimax_h3_preview.js           # DOM 双通道尺寸 / onResize 推导参考
│  ├─ banzhang_lora_loader.js        # 内容行高型面板参考
│  ├─ csglide_rack_core.js           # uploadFile / fileKind / viewURL
│  └─ csglide_rack_drop.js           # 节点级拖入路由参考
├─ banzhang_producer.py              # 帧账禁改常量
├─ AGENTS.md                         # 仓库 AI 协作指令（开工先读）
└─ PROJECT.md                        # 尺寸/卡顿/贴边历史事故与经验记录（288KB，按需 grep）
```

> 排查上游 ComfyUI 前端真实行为别凭记忆：未压缩源码在
> `python_embeded/Lib/site-packages/comfyui_frontend_package/static/assets/*.js.map`，
> 超长单行用 `grep -o -E "关键字.{1400}" xxx.js.map | head -2` 逐段扒上下文。
