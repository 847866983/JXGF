# CLAUDE.md
# 兼容 Claude Code / Cursor 等工具：本仓库的 AI 指令统一维护在 AGENTS.md。
# 请直接阅读并遵守 AGENTS.md 与 docs/AI节点开发铁律.md（节点开发必读）。

请阅读本目录下的 AGENTS.md；节点开发任务还必须先读 docs/AI节点开发铁律.md。
Please read AGENTS.md in this directory; for any node development task also read docs/AI节点开发铁律.md first.
