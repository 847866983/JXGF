# -*- coding: utf-8 -*-
"""🎚️ H3 画面微调 —— 不用训练、不用 LoRA，现场拨画面的三个旋钮。

来源与版权
----------
算法整合自第三方包 ComfyUI-Fizgig-H3-Tweaks（MIT 协议，作者 Peter Neill /
shootthesound，仓库 https://github.com/shootthesound/ComfyUI-Fizgig-H3-Tweaks）。
这里沿用它的核心做法，按班长全家桶的习惯重写：中文参数、中文悬停说明、
注册方式与本包一致。

它到底干了什么
--------------
H3 是把 50 个「处理块」串起来的一根管子：每一块读一遍当前画面，算出自己这一轮
要往上加的改动（行话叫 update），再加回去。节点做的是 —— 在指定的几个块里，
把这份改动按「粗 / 中 / 细」拆成不同频段，然后按比例放大或缩小再加回去。
三个旋钮各管一个频段：

  细节与对比   = d - 模糊(d)              高频：毛孔、睫毛、细纹理（第 40-49 块）
  场景变化     = 模糊(d)                  低频：整体布局、明暗大块（第 20-49 块）
  提示词强度   在注意力内部把提示词那几行的权重整体乘一个系数

文字行和声音行一律不动；三个旋钮全在 0 的时候节点等于直通。

什么时候管用
------------
- 细节与对比（默认 0.15）：正数＝皮肤更实、毛孔睫毛更清、阴影更沉；
  负数＝更柔更透。0.15 通常干净，再往上容易发干发硬。
- 场景变化（默认 0＝关）：相当于换个副种子 —— 整体观感不变、布局轻微重排，
  用来重摇一条「差一点就对」的片子。±0.1 起试。同样的参数一定得到同样的结果。
- 提示词强度（默认 0＝关）：H3 的 Turbo 模式本身不跑 CFG，没有「听话程度」旋钮，
  这个补上它。0.2 起步往上加。

三条要注意的
------------
1. 只认 H3（fl2va / ref2va）。接了别的模型会直接报错说明。
2. 它占的是 H3 的「块替换补丁」位，而这个位一块只能坐一个人：如果同一条模型链
   上还挂了班长 SLA 注意力加速（sla/patch.py 也占 20-49 块），后挂的会把先挂的
   顶掉 —— 两者不要串在同一条模型链上，装的时候控制台会有提示。
3. 涉及到的每个块、每个步都要把改动在 fp32 下多算一遍并做高斯模糊对照，
   分辨率越高、步数越多越慢，显存也会上去。
"""

import math

import torch
import torch.nn.functional as F

_NUM_BLOCKS = 50                       # H3 一共 50 个 transformer 块，编号 0-49
_KEY = "banzhang_h3_tweaks"            # 微调清挂在模型 options 上的键：串多个节点时清单累加

# 各旋钮作用在哪些块、哪一段步上（作者 2026-09-25 六步 Turbo 实测后的定值，别随手改）
_DETAIL_BLOCKS = list(range(40, 50))   # 细节：靠后的块管纹理
_SCENE_BLOCKS = list(range(20, 50))    # 场景：中后段的块管布局
_WINDOW_DETAIL = "后半程"               # 细节在最后一半步里加，先粗后细
_WINDOW_SCENE = "前三分之一"            # 布局在最前面三分之一步里动
_WINDOW_ALL = "全程"

_MODE_STABLE = "跨帧稳定"               # 细节模式的两个选项（会存进工作流 JSON）
_MODE_PERFRAME = "逐帧"


# ---- 当前是整体过程的第几步 ------------------------------------------------------------------
def _step_of_sigmas(transformer_options):
    """从采样器的 sigma 记账里认出「现在是第几步 / 一共几步」，认不出来返回 (None, None)。"""
    sig = transformer_options.get("sigmas")
    all_sig = transformer_options.get("sample_sigmas")
    if sig is None or all_sig is None:
        return None, None
    try:
        cur = sig.flatten()[0]
        idx = int((all_sig.to(cur.device, cur.dtype) - cur).abs().argmin())
        total = max(int(all_sig.shape[0]) - 1, 1)
        return min(idx + 1, total), total
    except Exception:
        return None, None


def _窗口步号(window, total):
    """一个窗口在「总共 total 步」时覆盖哪几步（1 起算）。"""
    if window == _WINDOW_DETAIL:
        return set(range(total // 2 + 1, total + 1))
    if window == _WINDOW_SCENE:
        return set(range(1, math.ceil(total / 3) + 1))
    return set(range(1, total + 1))


# ---- 频段拆分 ----------------------------------------------------------------------------------
def _模糊_网格(x, sigma=1.0):
    """在每帧自己的 token 网格（h, w）上做一次高斯模糊，边缘用镜像填充。

    x: [T, h, w, C] —— T 帧，每帧 h*w 个 token，每 token C 个数。
    """
    T, h, w, C = x.shape
    r = max(1, int(math.ceil(sigma * 3)))
    k = torch.arange(-r, r + 1, device=x.device, dtype=torch.float32)
    k = torch.exp(-(k ** 2) / (2 * sigma ** 2))
    k = k / k.sum()
    y = x.float().permute(0, 3, 1, 2).reshape(T * C, 1, h, w)
    if h > 1:
        rh = min(r, h - 1)
        kh = k[r - rh:r + rh + 1]
        kh = kh / kh.sum()
        y = F.conv2d(F.pad(y, (0, 0, rh, rh), mode="reflect"), kh.view(1, 1, -1, 1))
    if w > 1:
        rw = min(r, w - 1)
        kw = k[r - rw:r + rw + 1]
        kw = kw / kw.sum()
        y = F.conv2d(F.pad(y, (rw, rw, 0, 0), mode="reflect"), kw.view(1, 1, 1, -1))
    return y.reshape(T, C, h, w).permute(0, 2, 3, 1)


def _取频段(kind, d4, mode=None):
    """把一块的改动 d4 [T, gh, gw, C]（fp32）拆出某个频段，形状不变。"""
    if kind == "detail":
        high = d4 - _模糊_网格(d4, 1.0)
        if mode == _MODE_STABLE and d4.shape[0] > 1:
            # 「跨帧稳定」：只留每一帧都一样的那部分细节 —— 少了不少闪烁
            high = high.mean(dim=0, keepdim=True).expand_as(high)
        return high
    if kind == "composition":
        return _模糊_网格(d4, 3.0)
    raise ValueError(kind)


# ---- 提示词强度：换掉块自带的那个注意力模块 --------------------------------------------------
class _提示词加权注意力:
    """和 H3 自带的注意力算同一套数学，只是把提示词那几行的值整体乘个系数。

    H3 Turbo 不跑 CFG，没有正负提示词的差值可放；给提示词行的 value 加权，
    等价于让每个画面/声音 token 从提示词里多取一点（或少取一点）。
    """

    def __init__(self, attn, text_len, scale):
        self.attn = attn
        self.text_len = text_len
        self.scale = scale

    def __call__(self, x, rope_freqs=None, transformer_options={}):
        import comfy.model_management
        import comfy.quant_ops
        from comfy.ldm.modules.attention import optimized_attention
        from comfy.ldm.minimax.model import AttentionTensorContainer

        a = self.attn
        n = x.shape[0]
        q, k, v = a.qkv_proj(x).split(a.heads * a.head_dim, dim=-1)
        v = v.reshape(n, a.heads, a.head_dim).clone()
        v[: self.text_len] *= self.scale
        if rope_freqs is not None:
            q = q.reshape(1, n, a.heads, a.head_dim).contiguous()
            k = k.reshape(1, n, a.heads, a.head_dim).contiguous()
            qw = comfy.model_management.cast_to(a.q_norm.weight, device=x.device)
            kw = comfy.model_management.cast_to(a.k_norm.weight, device=x.device)
            rot = rope_freqs.shape[-3] * 2
            q, k = comfy.quant_ops.ck.rms_rope_split_half(
                q, k, rope_freqs, qw, kw, epsilon=a.q_norm.eps, rot_dim=rot)
            q, k = q[0], k[0]
        else:
            q = a.q_norm(q.reshape(n, a.heads, a.head_dim))
            k = a.k_norm(k.reshape(n, a.heads, a.head_dim))
        q = AttentionTensorContainer(q.transpose(0, 1).unsqueeze(0))
        k = AttentionTensorContainer(k.transpose(0, 1).unsqueeze(0))
        v = AttentionTensorContainer(v.transpose(0, 1).unsqueeze(0))
        out = optimized_attention(q, k, v, a.heads, mask=None, skip_reshape=True,
                                  transformer_options=transformer_options)
        return a.out_proj(out.squeeze(0))


# ---- 每块的调度：把真正生效的旋钮应用上去 ----------------------------------------------------
def _造调度器(dm):
    def dispatch(args, extra):
        original = extra["original_block"]
        to = args.get("transformer_options", {})
        tweaks = to.get(_KEY) or []
        layout = args.get("layout")
        step, total = _step_of_sigmas(to)
        if not tweaks or step is None or layout is None:
            return original(args)

        block = int(to.get("block_index", -1))
        active = [t for t in tweaks
                  if block in t["blocks"] and step in _窗口步号(t["window"], total)]
        if not active:
            return original(args)

        report = any(t["report"] for t in active)
        call = dict(args)

        # 提示词强度：换掉这一块用的注意力模块
        scale = 1.0
        prompt = [t for t in active if t["kind"] == "prompt"]
        if prompt:
            text_len = next((b - a for a, b, kind in layout.segments if kind == "text"), 0)
            for t in prompt:
                scale *= 1.0 + t["strength"]
            if text_len and scale != 1.0:
                call["attention"] = _提示词加权注意力(dm.blocks[block].attn, text_len, scale)

        updates = [t for t in active if t["kind"] != "prompt"]
        if not updates:
            out = original(call)
            if report:
                print("🎚️ [H3 画面微调] 第 %d/%d 步 第 %d 块：提示词 ×%.2f"
                      % (step, total, block, scale), flush=True)
            return out

        # 画面频段：把这一块「加了什么」拆开，按旋钮重配之后再加回去
        va, vb, _ = next(s for s in layout.segments if s[2] == "video")
        _, T, lh, lw, _ = layout.signature
        gh, gw = lh // 2, lw // 2                      # 2x2 并块 -> token 网格
        if T * gh * gw != vb - va:
            return original(call)                      # 布局不是预期形状，原样放行
        before = args["img"][va:vb].clone()            # 块是在原张量上就地改写的
        out = original(call)["img"]
        delta = out[va:vb].float() - before.float()
        d4 = delta.reshape(T, gh, gw, -1)
        new = d4
        for t in updates:
            new = new + t["strength"] * _取频段(t["kind"], d4, t.get("mode"))
        out[va:vb] = (before.float() + new.reshape(delta.shape)).to(out.dtype)
        if report:
            print("🎚️ [H3 画面微调] 第 %d/%d 步 第 %d 块：" % (step, total, block)
                  + "，".join("%s %+.2f" % (t["kind"], t["strength"]) for t in updates),
                  flush=True)
        return {"img": out}

    return dispatch


def _make_tweak(kind, strength, blocks, window, report, **extra):
    return dict(kind=kind, strength=float(strength), blocks=list(blocks),
                window=window, report=bool(report), **extra)


def _装微调(model, tweaks, node_name="🎚️ H3 画面微调"):
    """把生效的旋钮挂到模型上。

    清单挂在模型 options 里共享，所有涉及到的块统一走一个调度器 —— 串两个本节点，
    两份清单会叠在一起算（不是互相覆盖）。
    """
    dm = getattr(getattr(model, "model", None), "diffusion_model", None)
    if dm is None or type(dm).__name__ != "MiniMaxH3Model":
        raise ValueError("%s 只认 MiniMax H3 —— 请接 H3 模型。" % node_name)
    patched = model.clone()
    tweaks = [t for t in tweaks if t["blocks"] and t["strength"] != 0]
    if not tweaks:
        return patched                                  # 三个旋钮全是 0：直通

    to = patched.model_options.setdefault("transformer_options", {})
    to[_KEY] = list(to.get(_KEY) or []) + tweaks
    blocks = set()
    for t in to[_KEY]:
        blocks |= set(t["blocks"])

    # 这些块上若已经坐着别人的替换补丁（SLA 注意力加速就占这一类），我们这一挂
    # 会把它顶下来：ComfyUI 一个块只留一个替换补丁。如实说一句，别让画面平白变了。
    other = to.get("patches_replace", {}).get("dit", {})
    taken = sorted(i for i in blocks
                   if ("double_block", i) in other
                   and getattr(other[("double_block", i)], "_banzhang_h3_tweaks", False) is False)
    if taken:
        print("⚠️ [H3 画面微调] 第 %s 块上原本挂着别的替换补丁（SLA 注意力加速？），"
              "已被本节点顶掉，那条链上的加速在这些块上失效。" % taken, flush=True)

    patch = _造调度器(dm)
    patch._banzhang_h3_tweaks = True
    for i in sorted(blocks):
        patched.set_model_patch_replace(patch, "dit", "double_block", i)
    return patched


# ---- 节点 --------------------------------------------------------------------------------------
class BanZhangH3Tweaks:
    """🎚️ H3 画面微调：MODEL → MODEL，夹在 LoRA 之后、采样器之前。"""

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "模型": ("MODEL", {
                    "tooltip": "H3 模型，可以先接过 LoRA（本节点要排在 LoRA 之后、"
                               "采样器之前）。只认 MiniMax H3，接别的模型会报错。"}),
                "细节与对比": ("FLOAT", {
                    "default": 0.15, "min": -1.0, "max": 1.0, "step": 0.05,
                    "tooltip": "纹理和明暗对比一起调，作用在最后面的那一半步上（步数多少都自动换算）。\n"
                               "往正数走 = 更锐更实：毛孔、雀斑、睫毛更清，阴影更沉；"
                               "0.15 通常干净，再往上容易发干发硬。\n"
                               "往负数走 = 更柔更透：皮肤更顺、阴影提亮。\n"
                               "0 = 不动。"}),
                "细节模式": ([_MODE_STABLE, _MODE_PERFRAME], {
                    "default": _MODE_STABLE,
                    "tooltip": "只对「细节与对比」生效（它为 0 时这里没影响）。\n"
                               "跨帧稳定 = 只加每一帧都一样的那部分细节，画面照样清"
                               "但不闪（实测 0.3 时闪烁 +7%，逐帧是 +20%），拍片子用这个。\n"
                               "逐帧 = 每帧各自的高频，出单张图可以，拍片子容易闪。"}),
                "场景变化": ("FLOAT", {
                    "default": 0.0, "min": -0.5, "max": 0.5, "step": 0.05,
                    "tooltip": "给一条「差一点就对」的片子换个副种子：在最前面三分之一步里"
                               "轻轻重排布局，整体观感不变。\n"
                               "±0.1 起试；同样的参数一定得到同样的结果。0 = 关。"}),
                "提示词强度": ("FLOAT", {
                    "default": 0.0, "min": -0.5, "max": 3.0, "step": 0.05,
                    "tooltip": "H3 的 Turbo 模式不跑 CFG，本来没有「听话程度」这个旋钮，这里是补它的。\n"
                               "往正数走 = 你写进提示词的东西更突出；往负数走 = 更松散。\n"
                               "0.2 起步慢慢加。0 = 关。"}),
                "打印日志": ("BOOLEAN", {
                    "default": False, "label_on": "开", "label_off": "关",
                    "tooltip": "在控制台逐行打印「第几步 / 第几块 / 哪个旋钮生效了」，排查用。"}),
            }
        }

    RETURN_TYPES = ("MODEL",)
    RETURN_NAMES = ("模型",)
    FUNCTION = "apply"
    CATEGORY = "👨‍🏫班长/MiniMax H3"
    DESCRIPTION = ("给 H3 加三个画面旋钮：细节与对比（更锐或更柔）、场景变化（换个副种子重摇布局）、"
                   "提示词强度（Turbo 模式缺失的听话程度）。不训练、不用额外模型，"
                   "是一个 MODEL → MODEL 的模型补丁。")

    def apply(self, 模型, 细节与对比=0.15, 细节模式=_MODE_STABLE, 场景变化=0.0,
              提示词强度=0.0, 打印日志=False):
        tweaks = [
            _make_tweak("detail", 细节与对比, _DETAIL_BLOCKS, _WINDOW_DETAIL, 打印日志,
                        mode=细节模式),
            _make_tweak("composition", 场景变化, _SCENE_BLOCKS, _WINDOW_SCENE, 打印日志),
            _make_tweak("prompt", 提示词强度, range(_NUM_BLOCKS), _WINDOW_ALL, 打印日志),
        ]
        return (_装微调(模型, tweaks),)


NODE_CLASS_MAPPINGS = {
    "BanZhangH3Tweaks": BanZhangH3Tweaks,
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "BanZhangH3Tweaks": "🎚️ H3 画面微调",
}
