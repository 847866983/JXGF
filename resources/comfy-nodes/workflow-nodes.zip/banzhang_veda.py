# -*- coding: utf-8 -*-
"""⚡ Veda 稀疏注意力 (H3)：班长的中文薄壳层。

为什么单独一层：上游 Veda 是英文 V3 节点、走独立包入口，无法被班长
__init__.py 收录。本文件只负责「中文 schema + 组装」，核心全在 _veda/，
唯一的耦合点是 comfy_patch.apply(model, bundle, settings, node_id)——
上游升级时直接覆盖 _veda/ 即可，这层不用动。

_veda/ 保持上游零改动（含它自带的英文 nodes.py，那个不注册、仅原样留存）。
文案在 banzhang_veda_texts.py，打分器的目录/下载/缓存 在
banzhang_veda_predictor.py。
"""

from __future__ import annotations

try:
    from comfy_api.latest import io
    USE_NEW_API = True
except ImportError:
    USE_NEW_API = False

    class io:  # 旧版 ComfyUI 占位：保证模块可导入，节点不注册
        class ComfyNode: pass
        class Schema: pass
        class NodeOutput: pass
        class Model:
            @staticmethod
            def Input(*a, **k): return "MODEL"
            @staticmethod
            def Output(*a, **k): return "MODEL"
        class Combo:
            @staticmethod
            def Input(*a, **k): return a[0] if a else "COMBO"
        class String:
            @staticmethod
            def Input(*a, **k): return a[0] if a else "STRING"
        class Boolean:
            @staticmethod
            def Input(*a, **k): return a[0] if a else "BOOLEAN"

from . import banzhang_veda_texts as T
from ._veda import backends, comfy_patch, hardware
from ._veda import settings as veda_settings
from ._veda import status as veda_status
from ._veda.core import bundle as veda_bundle
from .banzhang_veda_predictor import FOLDER, load as load_predictor
from .banzhang_veda_predictor import options as predictor_options
from .banzhang_veda_predictor import register_model_folder
from .banzhang_veda_predictor import resolve as resolve_predictor

# 上游默认打分器是 T2VA（清单第一项），但本机主跑参考生视频，指定 R2VA
# 开箱即用。跑纯文生视频时在下拉框切回 minimax_h3_t2va_... 即可。
_DEFAULT_PREDICTOR = "minimax_h3_r2va_veda_preview_fp8.safetensors"
# 参考段给满注意力：参考图是主体一致性的唯一锚点，砍它的注意力会直接掉脸
# /掉风格，而它只占一小部分 token，省下来的时间不划算。
# 必须写带百分号的 "0%"：裸 "0" 会被当成 tile 数（要求大于 0）直接报错。
_DEFAULT_REFERENCE = "0%"


def _check_model(model, bundle) -> int:
    """校验模型是 H3 且与打分器层头匹配，返回 block 数。"""
    diffusion = model.get_model_object("diffusion_model")
    if type(diffusion).__name__ != "MiniMaxH3Model":
        raise ValueError(
            "Veda 只加速 MiniMax-H3。请连接 MiniMax-H3 模型的 MODEL"
            f"（现在接的是 {type(diffusion).__name__}）。")
    attn = diffusion.blocks[0].attn
    shape = (len(diffusion.blocks), attn.heads, attn.head_dim)
    trained = (bundle.num_layers, bundle.num_heads, bundle.head_dim)
    if shape != trained:
        got = " x ".join(map(str, shape))
        want = " x ".join(map(str, trained))
        raise ValueError(
            f"这个模型是 {got}（block x 头数 x 头维度），打分器训练于 {want}。\n"
            "请选择为这个模型训练的打分器。")
    return len(diffusion.blocks)


def _other_sparse_node(model) -> bool:
    """ComfyUI 自带的稀疏注意力节点会把注意力 block 整个换掉，
    那样 Veda 永远不会被调用。"""
    import comfy.patcher_extension
    callbacks = getattr(model, "callbacks", {}) or {}
    prepare = callbacks.get(
        comfy.patcher_extension.CallbacksMP.ON_PREPARE_STATE, {})
    return "block_sparse_attention" in prepare


if USE_NEW_API:

    class BanZhangVedaSparseAttention(io.ComfyNode):
        """Veda 学习式块稀疏注意力，只加速 MiniMax-H3。"""

        @classmethod
        def define_schema(cls):
            return io.Schema(
                node_id="BanZhang_VedaSparseAttention",
                display_name="⚡ Veda 稀疏注意力 (H3)",
                category="👨‍🏫班长/MiniMax H3",
                description=T.DESCRIPTION,
                inputs=[
                    io.Model.Input("model", display_name="模型",
                                   tooltip=T.TIP_MODEL),
                    io.Combo.Input("predictor", display_name="打分器",
                                   options=predictor_options(),
                                   default=_DEFAULT_PREDICTOR,
                                   tooltip=T.TIP_PREDICTOR),
                    io.String.Input(
                        "generated_sparsity", display_name="生成段稀疏度",
                        default=veda_settings.DEFAULT_BUDGET, advanced=True,
                        tooltip=T.TIP_GENERATED),
                    io.String.Input(
                        "reference_sparsity", display_name="参考段稀疏度",
                        default=_DEFAULT_REFERENCE, advanced=True,
                        tooltip=T.TIP_REFERENCE),
                    io.String.Input(
                        "full_attention_layers", display_name="全注意力层",
                        default="", advanced=True, tooltip=T.TIP_LAYERS),
                    io.String.Input(
                        "full_attention_steps", display_name="全注意力步",
                        default="", advanced=True, tooltip=T.TIP_STEPS),
                    io.Boolean.Input(
                        "auto_download", display_name="自动下载打分器",
                        default=False, advanced=True,
                        tooltip=T.TIP_DOWNLOAD),
                    io.Boolean.Input("verbose", display_name="详细信息",
                                     default=False, advanced=True,
                                     tooltip=T.TIP_VERBOSE),
                ],
                outputs=[io.Model.Output(
                    display_name="模型",
                    tooltip="已接上 Veda 稀疏注意力的模型。")],
                hidden=[io.Hidden.unique_id],
            )

        @classmethod
        def execute(cls, model, predictor,
                    generated_sparsity=veda_settings.DEFAULT_BUDGET,
                    reference_sparsity=_DEFAULT_REFERENCE,
                    full_attention_layers="", full_attention_steps="",
                    auto_download=False, verbose=False) -> io.NodeOutput:
            hidden = getattr(cls, "hidden", None)
            node_id = getattr(hidden, "unique_id", None)
            status = veda_status.NodeStatus(node_id)
            try:
                bundle = load_predictor(
                    resolve_predictor(predictor, auto_download, status.show))
            except veda_bundle.BundleError as error:
                raise ValueError(
                    f"{predictor} 不是可用的 Veda 打分器（原因见上）。\n"
                    f"models/{FOLDER} 里只放 Veda 打分器文件。") from error
            num_layers = _check_model(model, bundle)
            settings = veda_settings.VedaSettings(
                generated=veda_settings.parse_sparsity(
                    generated_sparsity, "生成段稀疏度", bundle.generated),
                reference=veda_settings.parse_sparsity(
                    reference_sparsity, "参考段稀疏度", bundle.reference),
                dense_layers=veda_settings.parse_index_list(
                    full_attention_layers, "全注意力层"),
                dense_steps=veda_settings.parse_index_list(
                    full_attention_steps, "全注意力步"),
                verbose=verbose)
            missing = sorted(i for i in settings.dense_layers
                             if i >= num_layers)
            if missing:
                raise ValueError(
                    "全注意力层：这个模型的 block 是 0-"
                    f"{num_layers - 1}，"
                    f"{veda_settings.format_index_list(missing)} 不存在。")
            if _other_sparse_node(model):
                raise ValueError(
                    '同时接了 ComfyUI 的「Model Sparse Attention」节点：'
                    "它在 H3 上直接替换注意力 block，Veda 无法运行。请二选一。")
            # 在这里解析 kernel 而不是等采样第一步，是为了让跑不了的 kernel
            # 当场停在这个节点上，而不是等采样器启动后才炸。
            import comfy.model_management
            device = comfy.model_management.get_torch_device()
            info = hardware.describe(device)
            resolution = backends.resolve(device, notify=status.show)
            if resolution.backend is None:
                raise comfy_patch.kernel_error(resolution)

            patched, patch = comfy_patch.apply(model, bundle, settings, node_id)
            lines = [f"Veda ready | {resolution.backend.display}"
                     f" | {info.short_name}",
                     f"Sparsity: {settings.describe()}"]
            full = settings.describe_full_attention()
            if full:
                lines.append(f"Full attention: {full}")
            if patch.taken_over:
                names = ", ".join(patch.taken_over)
                lines.append(veda_status.bilingual(
                    f"Took over the attention from {names}: Veda runs the "
                    "sparse layers, it keeps the full-attention ones.",
                    f"已接管 {names} 的注意力：稀疏层由 Veda 计算，"
                    "全注意力层仍由它计算。"))
            if verbose:
                lines.append(f"Predictor: {bundle.describe()}")
                lines.append(f"  {resolution.report()}")
            if patch.taken_over:
                status.warn("\n".join(lines))
            else:
                status.show("\n".join(lines))
            return io.NodeOutput(patched)


register_model_folder()

if USE_NEW_API:
    NODE_CLASS_MAPPINGS = {
        "BanZhang_VedaSparseAttention": BanZhangVedaSparseAttention,
    }
    NODE_DISPLAY_NAME_MAPPINGS = {
        "BanZhang_VedaSparseAttention": "⚡ Veda 稀疏注意力 (H3)",
    }
else:
    NODE_CLASS_MAPPINGS = {}
    NODE_DISPLAY_NAME_MAPPINGS = {}
