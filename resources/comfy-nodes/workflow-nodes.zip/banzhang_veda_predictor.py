# -*- coding: utf-8 -*-
"""⚡ Veda 节点的打分器：目录注册、路径解析、下载、加载缓存。

和节点逻辑分开，是因为这一块涉及磁盘和网络，出错点（缺文件、下载中断、
校验不过）和注意力本身完全无关。
"""

from __future__ import annotations

import os
import threading

import folder_paths

from ._veda import predictors
from ._veda.core import bundle as veda_bundle

FOLDER = "veda"

_BUNDLES: dict[str, tuple[tuple[float, int], object]] = {}
_BUNDLE_LOCK = threading.Lock()


def register_model_folder() -> str:
    """注册 models/veda（只认 .safetensors）。

    必须在 define_schema 之前跑：打分器下拉框直接读这个目录，晚一步注册
    就是空列表。
    """
    path = os.path.join(folder_paths.models_dir, FOLDER)
    entry = folder_paths.folder_names_and_paths.get(FOLDER)
    if entry is None:
        folder_paths.folder_names_and_paths[FOLDER] = ([path], {".safetensors"})
    else:
        if path not in entry[0]:
            entry[0].append(path)
        if entry[1]:
            entry[1].add(".safetensors")
    try:
        os.makedirs(path, exist_ok=True)
    except OSError:  # 只读安装：用户仍可手动放文件
        pass
    return path


def options() -> list[str]:
    """下拉框选项：本地已有文件 + 班长内置清单里还没下的。"""
    local = folder_paths.get_filename_list(FOLDER)
    return list(local) + [n for n in predictors.KNOWN_PREDICTORS
                          if n not in local]


def resolve(name: str, auto_download: bool, notify=None) -> str:
    """打分器的本地路径；缺失时按 auto_download 决定下载还是报错引导。"""
    path = folder_paths.get_full_path(FOLDER, name)
    if path is not None:
        return path
    known = predictors.KNOWN_PREDICTORS.get(name)
    if known is None:
        raise ValueError(f"打分器 {name!r} 不在班长内置清单里，"
                         f"请手动把 .safetensors 放进 {_folder()} 后重启 ComfyUI。")
    if not auto_download:
        raise ValueError(predictors.how_to_get(known, _folder()))
    return _download(known, notify)


def _folder() -> str:
    paths = folder_paths.get_folder_paths(FOLDER)
    return paths[0] if paths else os.path.join(folder_paths.models_dir, FOLDER)


def _download(known, notify=None) -> str:
    """把打分器下到 models/veda，下完核 sha256。

    为什么默认不自动下：上游原版本自带下载，后因「自定义节点联网 + 读
    HF_TOKEN 会触发 Comfy Registry 安全扫描」而移除。班长是本地安装不走
    Registry，但仍保留上游的边界——由用户在节点上勾选后才联网。
    """
    import hashlib

    from huggingface_hub import hf_hub_download

    folder = register_model_folder()
    if notify:
        notify(f"正在下载打分器 {known.filename}（{known.megabytes()} MB）…")
    path = hf_hub_download(repo_id=known.repo, filename=known.filename,
                           revision=known.revision, local_dir=folder)
    # 必须核：中途断网会留下截尾文件，不核会被当成可用打分器，
    # 报错会变成莫名其妙的张量形状不匹配。
    digest = hashlib.sha256()
    with open(path, "rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            digest.update(block)
    if digest.hexdigest() != known.sha256:
        os.remove(path)
        raise ValueError(
            f"打分器 {known.filename} 下载不完整（校验不匹配），已删除。\n"
            f"请重新运行，或手动下载后放进 {folder}：\n  {known.url}")
    return path


def load(path: str):
    """按 mtime + 大小缓存打分器，只留一个（约 0.5 GB 内存）。"""
    stat = os.stat(path)
    stamp = (stat.st_mtime, stat.st_size)
    with _BUNDLE_LOCK:
        cached = _BUNDLES.get(path)
        if cached is not None and cached[0] == stamp:
            return cached[1]
        bundle = veda_bundle.load_bundle(path)
        _BUNDLES.clear()
        _BUNDLES[path] = (stamp, bundle)
        return bundle
