# -*- coding: utf-8 -*-
"""🪞 人脸修复台（BanZhang_FaceFixStudio）—— 独立外挂节点，零侵入。

定位：插在 H3 三采管线的「一采之后、二采之前」，主干走 LATENT。在最便宜的
基础分辨率上把远景崩脸标出来并保护保留区，再让二采神经放大、三采精修带着
正确的脸去做。

本节点只做三件事：
  1) SAM3.1 记忆追踪人脸（文本提示 face）→ obj_id 全程稳定，多人同框不串身份
  2) 逐帧轮廓掩码（轻微羽化）→ trilinear 对齐到一采 latent 网格
  3) 模型补丁：视频掩码不进 per-token 时间步条件 + 按 sigma 进度缩放掩码强度
输出「带 noise_mask 的 latent」与「补丁模型」，重绘交给下游采样器完成 ——
尊重用户自己的 sigmas 与音视频时间步对齐，节点内部不自行采样。

隔离承诺：不 import、不修改导演台/媒体架/文案台/mmh3_upscale/采样器，只通过
标准端口（LATENT/MODEL/IMAGE/VAE）对接。删掉本文件并撤回 __init__ 注册行，
现有工作流逐字不变。
"""

import json

from ._facefix.pipeline import execute


class BanZhang_FaceFixStudio:
    """🪞 人脸修复台：latent 主干，全自动单页面板。"""

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                # 完整工程 JSON 承载 widget（前端双写，刷新恢复）
                "project_data": ("STRING", {"default": ""}),
                # 主干 latent：一采 KSampler 输出，必接
                "h3_latent": ("LATENT",),
                # SAM3.1 检测模型（CheckpointLoaderSimple 加载 sam3.1 权重）
                "sam3_model": ("MODEL",),
                # SAM3.1 的文本编码器（同一 CheckpointLoaderSimple 的 CLIP 口）
                # 节点内部自己编码提示词，不需要外接 CLIPTextEncode
                "sam3_clip": ("CLIP",),
                # 人脸提示词，前端面板里直接可改
                "sam3_prompt": ("STRING", {"default": "face", "multiline": False}),
            },
            "optional": {
                # 旁路解码帧，供检测用；不接则用「解码VAE」内部解码关键帧
                "detect_frames": ("IMAGE",),
                # 未接检测帧时内部解码关键帧；同一 VAE 即可
                "vae": ("VAE",),
                # H3 修复模型：接了才输出补丁模型（视频掩码不进时间步条件）
                "model": ("MODEL",),
            },
        }

    RETURN_TYPES = ("LATENT", "MODEL", "STRING", "STRING")
    RETURN_NAMES = ("修复潜空间", "补丁模型", "工程JSON", "修复报告")
    FUNCTION = "run"
    CATEGORY = "👨‍🏫班长/人脸修复"

    # 面板按钮只提交「本节点 + 上游」，节点不是任何输出的上游时会被剪枝，
    # 故声明为 OUTPUT_NODE。
    OUTPUT_NODE = True

    # 关闭输入 hash 缓存：每次都真实执行，避免「再点一次没反应」。
    @classmethod
    def IS_CHANGED(cls, **kwargs):
        return float("nan")

    def run(self, project_data, h3_latent, sam3_model, sam3_clip, sam3_prompt,
            detect_frames=None, vae=None, model=None):
        # 恢复工程（properties/前端双写），失败则用默认工程
        try:
            project = json.loads(project_data) if str(project_data).strip() else {}
        except Exception:
            project = {}
        if not isinstance(project, dict):
            project = {}
        # 旧版存档里的模块开关已下线，读到就丢掉，避免幽灵键一路传下去
        project.pop("modules", None)

        fixed_latent, info = execute(h3_latent, detect_frames,
                                     model=model, vae=vae,
                                     sam3_clip=sam3_clip,
                                     sam3_model=sam3_model,
                                     sam3_prompt=sam3_prompt)
        report = info.get("report", "")

        # 前端人脸缩略图：保留代表帧 data URI
        project["faces"] = [
            {"index": int(f.get("index", i)),
             "status": str(f.get("status", "detected")),
             "thumb": f.get("thumb")}
            for i, f in enumerate(info.get("faces", []))
        ]
        project["backend"] = info.get("backend", "none")
        project["coverage"] = round(float(info.get("coverage", 0.0)), 4)
        project["last_report"] = report
        full_json = json.dumps(project, ensure_ascii=False)

        patched_model = info.get("patched_model", model)
        # 带 ui 的 dict 才会写 history.outputs 并触发 executed 事件回写面板
        return {
            "ui": {"project": [full_json], "report": [report]},
            "result": (fixed_latent, patched_model, full_json, report),
        }


NODE_CLASS_MAPPINGS = {
    "BanZhang_FaceFixStudio": BanZhang_FaceFixStudio,
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "BanZhang_FaceFixStudio": "🪞 人脸修复台 (Face Fix Studio)",
}
