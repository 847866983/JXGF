# -*- coding: utf-8 -*-
"""
班长全家桶 — 取色器 (Color Picker)
合并自 Goohaitools-comfyui 的常用颜色🔵孤海，去除孤海品牌前缀。
从预设颜色中选取，或通过取色器（COLORCODE 控件）自定义颜色，
输出十六进制颜色字符串（如 #FFFFFF）。
"""


颜色预设 = {
    "白":     "#FFFFFF",
    "蓝":       "#0d89d0",
    "红":     "#9b0302",
    "黑":     "#000000",
    "灰":       "#808080",
    "湖蓝":     "#769ba2",
    "毕业蓝": "#62c2fc",
    "深蓝":     "#01648d",
    "海马体蓝":       "#095498",
    "水蓝":     "#c2e8f3",
    "司法蓝":     "#428eda",
    "天真蓝":     "#7389ae",
    "粉蓝":     "#9ecad7",
    "浅蓝":     "#81cffd",
    "祖玛绿":       "#37a3bf",
    "果绿":     "#7fa08f",
    "橄榄绿":     "#9c9a71",
    "松绿":     "#1c6959",
    "抹茶绿":     "#a1ba90",
    "登记红":  "#760404",
    "豆沙红":     "#86404a",
    "石榴红":     "#e60213",
    "正红":     "#be0201",
    "粉色":     "#fbc6d6",
    "浅粉":     "#f6d7dd",
    "浅紫":     "#d2c2e9",
    "鹅黄":   "#ecd56b",
    "奶茶":     "#c7ae90",
    "蜜瓜橙":     "#ce9b6c",
    "香槟色":       "#b19e97",
    "高级灰":     "#505050",
    "简灰":     "#cfd0d2",
    "深灰":       "#747277",
    "落日黄":     "#F4A460",
    "午夜黑":  "#2e2e30",
}


自定义标识 = "自定义"


class BanZhangColorPicker:
    """
    取色器
    从预设颜色中选取，或通过取色器自定义颜色，
    输出十六进制颜色字符串（如 #FFFFFF）。
    """

    @classmethod
    def INPUT_TYPES(cls):
        # 下拉菜单：预设颜色名称 + "自定义"
        颜色选项列表 = list(颜色预设.keys()) + [自定义标识]

        return {
            "required": {
                "选择颜色": (颜色选项列表, {"default": 颜色选项列表[0]}),
            },
            "optional": {
                "自定义颜色": ("COLORCODE", {"default": "#242730"}),
            },
        }

    # 节点输出类型
    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("T",)
    FUNCTION = "获取颜色"
    CATEGORY = "👨‍🏫班长/工具与标注"
    OUTPUT_NODE = False

    def 获取颜色(self, 选择颜色, 自定义颜色="#213D50"):
        if 选择颜色 == 自定义标识:
            # 使用取色器的值
            颜色结果 = self.规范化颜色(自定义颜色)
        else:
            # 从预设字典中取值
            颜色结果 = 颜色预设.get(选择颜色, "#000000")

        return (颜色结果,)

    @staticmethod
    def 规范化颜色(颜色值):
        """确保颜色值为 #RRGGBB 格式"""
        颜色值 = 颜色值.strip()
        if not 颜色值.startswith("#"):
            颜色值 = "#" + 颜色值
        # 处理短格式 #RGB -> #RRGGBB
        if len(颜色值) == 4:
            颜色值 = "#" + 颜色值[1]*2 + 颜色值[2]*2 + 颜色值[3]*2
        return 颜色值.upper()


# ============================================
# 节点注册映射
# ============================================
NODE_CLASS_MAPPINGS = {
    "BanZhang_ColorPicker": BanZhangColorPicker,
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "BanZhang_ColorPicker": "取色器",
}
