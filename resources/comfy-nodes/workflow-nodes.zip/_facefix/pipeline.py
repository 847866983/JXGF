# -*- coding: utf-8 -*-
"""修复管线编排：检测 → 掩码 → 模型补丁 → 带 noise_mask 的 latent。

只有一条出口：节点不在内部采样。重绘交给工作流下游的采样器（尊重用户自己
的 sigmas、音视频时间步对齐与采样器选择），本节点只负责"把该修的地方标出来
并把保留区保护起来"。
"""

from . import detection, inpaint, masks


def _is_valid_latent(h3_latent):
    return isinstance(h3_latent, dict) and "samples" in h3_latent


def execute(h3_latent, detect_frames=None, model=None, vae=None,
            sam3_clip=None, sam3_model=None, sam3_prompt=detection.DEFAULT_PROMPT):
    """返回 (latent, info)。info 含 backend/faces/coverage/report。"""
    if not _is_valid_latent(h3_latent):
        return h3_latent, {
            "backend": "none", "faces": [], "coverage": 0.0,
            "report": "❌ 未检测到有效 LATENT，请把一采 LATENT 接入「一采潜空间」口",
        }

    # 提示词在节点内自己编码（等价于外接 CLIPTextEncode），接线少一个节点
    sam3_cond, cond_note = detection.encode_prompt(sam3_clip, sam3_prompt)
    if sam3_cond is None:
        return h3_latent, {
            "backend": "none", "faces": [], "coverage": 0.0,
            "report": "⚠️ %s —— latent 原样透传" % cond_note,
        }

    det = detection.detect_faces(detect_frames, h3_latent, vae=vae,
                                 sam3_model=sam3_model, sam3_cond=sam3_cond)
    faces = det.get("faces", [])
    backend = det.get("backend", "none")
    base_info = {"backend": backend, "faces": faces, "coverage": 0.0}

    if not faces:
        info = dict(base_info)
        info["report"] = "⚠️ %s —— 未生成掩码，latent 原样透传" % det.get("note", "")
        return h3_latent, info

    mres = masks.build_masks(faces, det.get("frame_size", []), h3_latent,
                             frame_masks=det.get("frame_masks"))
    if mres.get("mask") is None:
        info = dict(base_info)
        info["report"] = "⚠️ %s —— latent 原样透传" % mres.get("note", "")
        return h3_latent, info

    patched_model, model_note = inpaint.prepare_model(model)
    if patched_model is not None:
        try:
            patched_model = inpaint.attach_sigma_schedule(patched_model)
        except Exception as e:
            model_note += "；sigma 调度跳过（%s）" % str(e).splitlines()[0][:60]

    try:
        noise_mask = inpaint.build_noise_mask(mres["mask"], h3_latent)
        out_latent = inpaint.attach_noise_mask(h3_latent, noise_mask)
        mask_note = "noise_mask 已就绪"
    except Exception as e:
        out_latent = h3_latent
        mask_note = "noise_mask 生成失败（%s）" % str(e).splitlines()[0][:80]

    info = dict(base_info)
    info["coverage"] = mres.get("coverage", 0.0)
    info["patched_model"] = patched_model
    info["report"] = "✅ %s；%s；%s；%s" % (
        det.get("note", ""), mres.get("note", ""), model_note, mask_note)
    return out_latent, info
