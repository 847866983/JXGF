# -*- coding: utf-8 -*-
"""脸形软掩码：像素域按框生成 + 高斯羽化，再 trilinear 对齐到 H3 latent 网格。

输出掩码语义与 mmh3_upscale 一致：1=生成（脸区），0=保留（背景）。
多脸在同一掩码上取并集，互不连通区域各自羽化，不产生矩形接缝。
"""

import numpy as np
import torch
import torch.nn.functional as F

DEFAULT_FEATHER = 16
# 轮廓掩码本身已贴脸形，羽化要小，否则会把脸缘糊掉
PIXEL_FEATHER = 5


def _pixel_mask(faces, height, width, feather):
    """逐帧像素软掩码 [N,H,W]，多脸取并集后高斯羽化。"""
    # 帧数取各 track 的最大长度：短 track（中途丢失）不能截断画布，否则错位
    n = max((len(f["boxes"]) for f in faces), default=0)
    canvas = np.zeros((n, height, width), dtype=np.float32)
    for face in faces:
        raw = np.zeros((n, height, width), dtype=np.float32)
        for fi, box in enumerate(face["boxes"]):
            if box is None:
                continue
            x1, y1, x2, y2 = [int(round(v)) for v in box]
            x1 = max(0, min(x1, width - 1))
            x2 = max(x1 + 1, min(x2, width))
            y1 = max(0, min(y1, height - 1))
            y2 = max(y1 + 1, min(y2, height))
            raw[fi, y1:y2, x1:x2] = 1.0
        # 单脸先羽化，再与画布取并集
        if feather > 0:
            import cv2
            ksize = int(feather * 2) + 1
            for fi in range(n):
                raw[fi] = cv2.GaussianBlur(raw[fi], (ksize, ksize), 0)
        canvas = np.maximum(canvas, raw)
    return np.clip(canvas, 0.0, 1.0)


def _soften_frames(frame_masks, feather):
    """SAM3.1 给的逐帧轮廓掩码已经是脸形，只需轻微羽化避免接缝硬切。"""
    arr = frame_masks.detach().cpu().numpy().astype(np.float32)
    n = arr.shape[0]
    if feather > 0:
        import cv2
        ksize = int(feather * 2) + 1
        for i in range(n):
            arr[i] = cv2.GaussianBlur(arr[i], (ksize, ksize), 0)
    return np.clip(arr, 0.0, 1.0)


def build_latent_mask(faces, frame_size, h3_latent, feather=DEFAULT_FEATHER,
                      frame_masks=None):
    """像素软掩码 → 对齐 latent 的 [1,1,T,h,w]。

    优先用 SAM3.1 的逐帧轮廓掩码（frame_masks），没有才退回人脸框矩形。
    """
    width, height = int(frame_size[0]), int(frame_size[1])
    samples = h3_latent["samples"]
    _, _, T, h, w = samples.shape

    if frame_masks is not None:
        pixel = _soften_frames(frame_masks, PIXEL_FEATHER)
    else:
        pixel = _pixel_mask(faces, height, width, feather)

    # [N,H,W] → [1,1,N,H,W] trilinear 一次对齐时间与空间
    t = torch.from_numpy(pixel).to(samples.device)[None, None]
    aligned = F.interpolate(t, size=(int(T), int(h), int(w)),
                            mode="trilinear", align_corners=False)
    return aligned.clamp(0.0, 1.0)


def build_masks(faces, frame_size, h3_latent, feather=DEFAULT_FEATHER,
                frame_masks=None):
    """主入口，返回 {"mask": tensor, "coverage": float, "note":...}。"""
    if not faces:
        return {"mask": None, "coverage": 0.0, "note": "无脸，未生成掩码"}
    if not frame_size:
        return {"mask": None, "coverage": 0.0, "note": "缺画面尺寸，未生成掩码"}
    samples = h3_latent["samples"]
    if getattr(samples, "ndim", 0) != 5:
        # 掩码按 [B,C,T,h,w] 对齐；单图 latent（4 维）不在本节点处理范围
        return {"mask": None, "coverage": 0.0,
                "note": "该 latent 不是视频形态（%d 维），跳过掩码" % samples.ndim}
    mask = build_latent_mask(faces, frame_size, h3_latent, feather,
                             frame_masks=frame_masks)
    coverage = float(mask.mean().item())
    kind = "轮廓掩码" if frame_masks is not None else "人脸框掩码"
    return {
        "mask": mask,
        "coverage": coverage,
        "note": "%s已对齐 latent，脸区占比 %.3f" % (kind, coverage),
    }
