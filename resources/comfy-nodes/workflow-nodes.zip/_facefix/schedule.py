# -*- coding: utf-8 -*-
"""巧思4：sigma 阶段强度调度。

扩散前期 sigma 高、结构未定，掩码强度高以锁定身份重绘；后期 sigma 低、
进入细节收敛，掩码强度回落以柔和融合接缝、避免边缘硬切。用余弦缓动生成
逐去噪步强度曲线，离线可验证（单调、值域、步数）。

曲线在模型侧按当前 sigma 索引应用；当前先保证曲线正确并写入工程报告。
"""

import torch

HIGH_STRENGTH = 1.0
LOW_STRENGTH = 0.35


def sigma_strength(steps, start=HIGH_STRENGTH, end=LOW_STRENGTH):
    """返回逐去噪步强度张量 [steps]，余弦缓动从 start 平滑到 end。"""
    steps = max(1, int(steps))
    x = torch.linspace(0.0, 1.0, steps)
    return end + (start - end) * 0.5 * (1.0 + torch.cos(torch.pi * x))
