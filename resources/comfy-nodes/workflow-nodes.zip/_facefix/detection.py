# -*- coding: utf-8 -*-
"""人脸检测：SAM3.1 记忆追踪（SAM3_VideoTrack），一次会话拿到逐帧逐身份掩码。

为什么不用 SAM3_Detect：那个是**逐帧独立检测**，帧与帧之间没有身份关联，
只能靠 IoU 猜"这帧的 0 号框是不是上帧的 0 号框"，快速换位／擦身／短暂遮挡
就会串脸。SAM3_VideoTrack 走 memory tracker，obj_id 全程稳定，还直接给像素级
掩码 —— 我们最终要的正是掩码，不必先退化成矩形框再画回来。

SAM3.1 不是独立检测器：它需要「SAM3 模型」+ 文本提示。模型由端口传入，提示词
用同一份权重自带的文本编码器在节点内编码（等价于外接一个 CLIPTextEncode，
接线少一个节点）。没有 YOLO 或任何其它降级路径：缺模型/缺编码器时直接给中文说明。
"""

import numpy as np
import torch
import torch.nn.functional as F

SAM3_THRESHOLD = 0.5
# 一段镜头里同时追踪的身份上限（初始掩码也计入）；0 会用内部上限 64，太危险
MAX_OBJECTS = 8
# 掩码折算成框时，低于这个像素面积视为伪检测
MIN_FACE_SIDE = 8.0
# 默认提示词：SAM3.1 是开放词汇检测，文本说 face 就找脸
DEFAULT_PROMPT = "face"


def encode_prompt(clip, text):
    """用 SAM3.1 自带的文本编码器编码提示词（等价于外接 CLIPTextEncode）。

    节点内集成这一步，前端只留一个可编辑的文本框，接线少一个节点。
    返回 (conditioning, note)；失败时 conditioning 为 None。
    """
    if clip is None:
        return None, "未接「SAM3.1文本编码」：把 CheckpointLoaderSimple 的 CLIP 口接过来"
    t = str(text or "").strip() or DEFAULT_PROMPT
    try:
        return clip.encode_from_tokens_scheduled(clip.tokenize(t)), ""
    except Exception as e:
        return None, "提示词「%s」编码失败（%s）" % (t, str(e).splitlines()[0][:80])


def _video_track_class():
    """取官方 SAM3 视频追踪节点类。"""
    from comfy_extras.nodes_sam3 import SAM3_VideoTrack
    return SAM3_VideoTrack


def _unpack(packed):
    """bit-packed [N,K,H,W//8] uint8 → bool [N,K,H,W*8]。"""
    from comfy.ldm.sam3.tracker import unpack_masks
    return unpack_masks(packed)


def _bbox_of(mask):
    """bool/float 2D 掩码 → [x1,y1,x2,y2] 或 None。"""
    rows = torch.any(mask, dim=1).nonzero()
    cols = torch.any(mask, dim=0).nonzero()
    if rows.numel() == 0 or cols.numel() == 0:
        return None
    y1, y2 = int(rows[0]), int(rows[-1])
    x1, x2 = int(cols[0]), int(cols[-1])
    if (x2 - x1) < MIN_FACE_SIDE or (y2 - y1) < MIN_FACE_SIDE:
        return None
    return [float(x1), float(y1), float(x2 + 1), float(y2 + 1)]


def _sam3_track(sam3_model, frames, sam3_cond):
    """一次会话跑完整段追踪。

    返回 (frame_masks [N,H,W] float 并集掩码, per_obj [N][K] bbox, W, H)。
    """
    height, width = int(frames.shape[1]), int(frames.shape[2])
    cls = _video_track_class()
    out = cls.execute(
        images=frames, model=sam3_model, conditioning=sam3_cond,
        detection_threshold=SAM3_THRESHOLD, max_objects=MAX_OBJECTS,
        detect_interval=1)
    res = out.result if getattr(out, "result", None) is not None else out.args
    td = res[0]

    packed = td.get("packed_masks")
    if packed is None:
        return None, [], width, height

    masks = _unpack(packed)                       # [N,K,Hm,Wm] bool
    n, k = int(masks.shape[0]), int(masks.shape[1])
    if n == 0 or k == 0:
        return None, [], width, height

    # 逐帧逐身份掩码放大到原图，同时得到逐帧并集（多脸取最大值，不叠加）
    # 帧与身份先并成一维通道再插值：bilinear 只吃 4 维张量
    hm, wm = int(masks.shape[-2]), int(masks.shape[-1])
    flat = masks.float().reshape(1, n * k, hm, wm)
    up = F.interpolate(flat, size=(height, width),
                       mode="bilinear", align_corners=False)[0]
    up = up.reshape(n, k, height, width)                            # [N,K,H,W]
    union = up.amax(dim=1)                                          # [N,H,W]

    per_obj = []
    for i in range(n):
        bboxes = []
        for j in range(k):
            bboxes.append(_bbox_of(up[i, j] > 0.5))
        per_obj.append(bboxes)
    return union, per_obj, width, height


def detect_faces(detect_frames=None, h3_latent=None, vae=None,
                 sam3_model=None, sam3_cond=None):
    """主入口。返回 {"faces","frame_masks","backend","frame_size","note"}。

    外部检测帧优先；未接时用 VAE 内部解码一采 latent 的关键帧兜底。
    """
    if sam3_model is None:
        return {
            "faces": [], "frame_masks": None, "backend": "none", "frame_size": [],
            "note": "未接「SAM3.1模型」：CheckpointLoaderSimple 的 MODEL 口接过来"
                    "（没有降级检测器）",
        }
    if sam3_cond is None:
        return {
            "faces": [], "frame_masks": None, "backend": "none", "frame_size": [],
            "note": "提示词没编成条件，本次不检测（没有降级检测器）",
        }

    if detect_frames is None:
        from . import frames
        detect_frames = frames.decode_keyframes(vae, h3_latent)
        source = "VAE 内部解码关键帧"
        if detect_frames is None:
            return {
                "faces": [], "frame_masks": None, "backend": "none", "frame_size": [],
                "note": "未接检测帧且未接解码VAE：接「检测帧」或「解码VAE」即可自动检测",
            }
    else:
        source = "外部检测帧"

    try:
        frame_masks, per_obj, width, height = _sam3_track(
            sam3_model, detect_frames, sam3_cond)
    except ImportError:
        return {
            "faces": [], "frame_masks": None, "backend": "sam3.1", "frame_size": [],
            "note": "当前 ComfyUI 没有 SAM3 追踪节点（comfy_extras/nodes_sam3.py）",
        }
    except Exception as e:
        return {
            "faces": [], "frame_masks": None, "backend": "sam3.1", "frame_size": [],
            "note": "SAM3.1 追踪失败：%s" % str(e).splitlines()[0][:120],
        }

    if frame_masks is None:
        return {
            "faces": [], "frame_masks": None, "backend": "sam3.1",
            "frame_size": [width, height],
            "note": "SAM3.1 在 %s 上没追踪到人脸（可把文本条件改成 face / 人脸）" % source,
        }

    # 只保留至少在一帧里成立的身份（obj_id 直接就是身份，不再需要 IoU 猜）
    n_obj = len(per_obj[0]) if per_obj else 0
    rgb = np.clip(detect_frames.detach().cpu().float().numpy() * 255.0,
                  0, 255).astype(np.uint8)

    from . import frames as frames_mod
    faces = []
    for j in range(n_obj):
        per_frame = [per_obj[i][j] for i in range(len(per_obj))]
        valid = [(i, b) for i, b in enumerate(per_frame) if b is not None]
        if not valid:
            continue
        best_frame, best_box = max(
            valid, key=lambda ib: (ib[1][2] - ib[1][0]) * (ib[1][3] - ib[1][1]))
        faces.append({
            "index": j,
            "boxes": per_frame,
            "status": "tracked",
            "thumb": frames_mod.make_thumb(rgb[best_frame], best_box),
        })

    return {
        "faces": faces,
        "frame_masks": frame_masks,
        "backend": "sam3.1",
        "frame_size": [width, height],
        "note": "已用 SAM3.1 记忆追踪 %s，共 %d 个身份" % (source, len(faces)),
    }
