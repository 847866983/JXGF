# -*- coding: utf-8 -*-
"""🪞 人脸修复台引擎子包（_facefix）。

节点只做端口与面板，真正的修复逻辑按职责拆在这里：
  detection  SAM3.1 记忆追踪（文本提示 face，obj_id 全程稳定）+ 逐帧轮廓掩码
  frames     未接检测帧时用 VAE 内部解码关键帧、裁人脸缩略图
  masks      轮廓掩码（优先）或人脸框软掩码 → 羽化 → latent 网格对齐
  inpaint    模型补丁（视频掩码只走采样器）、noise_mask 构造、sigma 强度调度
  schedule   sigma → 强度的余弦曲线
  pipeline   统一编排：检测 → 掩码 → 补丁 → 带 noise_mask 的 latent
"""

from .pipeline import execute

__all__ = ["execute"]
