# -*- coding: utf-8 -*-
"""掩码驱动的 H3 重绘准备。

只做三件可离线验证的事，且都不重写采样器：
  1) 在传入模型的克隆上打一个补丁（add_object_patch，不动全局）：
     视频掩码只走采样器，剔除 H3 的 per-token 时间步条件（音频侧保留）。
  2) 经官方 denoise_mask_function 钩子，按 sigma 进度缩放掩码强度。
  3) 把软掩码转成 H3 NestedTensor noise_mask（video 掩码 + audio 零）。

保留区**不再打补丁**：H3 官方的 scale_latent_inpaint（comfy/model_base.py
MiniMaxH3）已经做了「保留区按 VISUAL_COND_TIMESTEP 注入 + token 网格 ceil
对齐混合」。在那之上再叠一层"重噪到当前 sigma"会把保留区搅脏，而且该公式
依赖的 model_sampling.noise_scaling 在 ModelSamplingAV 上并不存在（旧采样类
EPS/CONST 才有），一旦挂上必抛 AttributeError。所以这层补丁整体删除。
"""

import math

import torch


def patch_sampler_only(model):
    """克隆模型，视频掩码不进 per-token 时间步条件（音频侧原样保留）。"""
    m = model.clone()
    base = getattr(m, "model", None)
    if base is None or not hasattr(base, "_denoise_mask_conds"):
        return m, "模型无 denoise 掩码钩子，跳过采样器隔离"
    orig_conds = base._denoise_mask_conds

    def _audio_only(denoise_mask, latent_shapes):
        out = dict(orig_conds(denoise_mask, latent_shapes))
        out.pop("denoise_mask", None)      # 视频掩码剔除，音频条件保留
        return out

    m.add_object_patch("_denoise_mask_conds", _audio_only)
    return m, "视频掩码只走采样器，音频锁保持不变"


def prepare_model(model):
    """返回 (patched_model, note)。model 为 None 时安全返回。"""
    if model is None:
        return None, "未接「修复模型」：掩码已就绪，但视频掩码会进时间步条件，建议接入"
    return patch_sampler_only(model)


def attach_sigma_schedule(model, steps=6, start=1.0, end=0.35):
    """经官方 denoise_mask_function 钩子，按当前 sigma 进度用调度曲线缩放掩码。

    每步采样器会调用钩子并传入当前 sigma；高 sigma（进度0）保持 start 强度定
    身份，低 sigma（进度1）回落到 end 强度融接缝。
    """
    from .schedule import sigma_strength
    curve = sigma_strength(steps, start, end)

    def mask_fn(sigma, denoise_mask, extra_options=None):
        try:
            sigmas = (extra_options or {}).get("sigmas")
            s0, s1 = float(sigmas[0]), float(sigmas[-1])
            cur = float(sigma.reshape(-1)[0])
            prog = 0.0 if s0 == s1 else (s0 - cur) / (s0 - s1)
            prog = min(1.0, max(0.0, prog))
            pos = prog * (steps - 1)
            i0 = int(math.floor(pos))
            i1 = min(steps - 1, i0 + 1)
            frac = pos - i0
            k = float(curve[i0] * (1 - frac) + curve[i1] * frac)
        except Exception:
            k = 1.0
        if getattr(denoise_mask, "is_nested", False):
            import comfy.nested_tensor as nt_mod
            members = [t * k for t in denoise_mask.unbind()]
            return nt_mod.NestedTensor(tuple(members))
        return denoise_mask * k

    m = model.clone()
    m.set_model_denoise_mask_function(mask_fn)
    return m


def build_noise_mask(soft_mask, h3_latent):
    """软掩码 [1,1,T,h,w] → H3 NestedTensor noise_mask（video 掩码 + audio 零）。"""
    import comfy.nested_tensor as nt
    samples = h3_latent["samples"]
    members = list(samples.unbind())
    video = members[0]
    vmask = soft_mask.to(video.device, video.dtype).expand(video.shape).contiguous()
    if len(members) > 1:
        audio_zero = torch.zeros_like(members[1])
        return nt.NestedTensor((vmask, audio_zero))
    return nt.NestedTensor((vmask,))


def attach_noise_mask(h3_latent, noise_mask):
    """返回带 noise_mask 的 latent 副本，不修改原 dict。"""
    out = dict(h3_latent)
    out["noise_mask"] = noise_mask
    return out
