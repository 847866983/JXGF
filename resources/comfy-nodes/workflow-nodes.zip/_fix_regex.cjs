const fs = require("fs");
const p = "js/csglide_cast_core.js";
let s = fs.readFileSync(p, "utf8");

// 目标：把 safeDirName 里的 | -] 换成 |\u0000-\u001f]（字面转义序列）
const lines = s.split(/\r?\n/);
let hit = -1;
for (let i = 0; i < lines.length; i++) {
  if (lines[i].includes('replace(/[') && lines[i].includes('| -]+/g')) { hit = i; break; }
}
if (hit < 0) {
  console.error("NOT FOUND");
  process.exit(1);
}
console.log("BEFORE: " + JSON.stringify(lines[hit]));
lines[hit] = lines[hit].replace("| -]+/g", "|\\u0000-\\u001f]+/g");
console.log("AFTER : " + JSON.stringify(lines[hit]));
fs.writeFileSync(p, lines.join("\n"));
