# -*- coding: utf-8 -*-
"""💾 H3 续拍存档 · 中央档案统一编号（注册层包装）

设计
----
续拍存档不再使用 ComfyUI 保存计数器生成 ``h3_context/clip_00420_.safetensors``。
它以导演台当前段和当前 take 为唯一归属，直接写入中央工程目录：

    output/h3_chain/<片名>/clip_000N.t<take>.cont.safetensors

同时，``📦 H3 段落存档`` 会写同一版本的：

    output/h3_chain/<片名>/clip_000N.t<take>.latent.safetensors

这样「成片 / latent / cont」三者共用同一套段落与 take 编号，中央系统可以按
一次执行回执反查，而不是从全局历史或保存计数器里猜。

顺带保留「顺序锚」输入口：它不参与计算，只保证导演台先登记当前段，本节点
随后落到同一段、同一版本上。
"""

import os
import time

_NODE_ID = "MiniMaxH3MotionContextSaveLatent"
_TAG = "[H3 续拍存档]"

_ANCHOR_SPEC = ("*", {
    "label": "顺序锚",
    "tooltip": "不参与计算，只保证本节点排在导演台之后执行。",
})

# 开关两档文字一并提供中文：ComfyUI 原生支持 BOOLEAN 的 label_on / label_off
# （comfy/comfy_types/node_typing.py），不写就回落成前端默认的英文 true/false。
_ENABLED_SPEC = ("BOOLEAN", {
    "default": True,
    "label": "启用存档",
    "label_on": "开",
    "label_off": "关",
    "tooltip": "关掉后本节点只透传潜空间，不写档、不推进 take、不登记段落。"
               "一采/二采/三采可各挂一个存档节点，只开想存档的那一段。",
})


def _set_last_saved(path):
    """把中央 cont 路径登记给 _h3mc；兼容旧代码读取 LAST_SAVED。"""
    try:
        from ._h3mc import nodes as mc_nodes
    except Exception:
        from _h3mc import nodes as mc_nodes
    mc_nodes.LAST_SAVED = {"path": path, "time": time.time()}


def _write_latent_copy(latent, path):
    """把同一 AV latent 写成 cont 副本；复用段落存档的安全落盘逻辑。"""
    from .csglide_clip import _streams, _write_st

    streams = _streams((latent or {}).get("samples"))
    if not streams:
        raise ValueError("续拍存档收到的潜空间是空的。")
    tensors = {}
    for i, stream in enumerate(streams):
        key = "video" if i == 0 else "audio" if i == 1 else "s%d" % i
        tensors[key] = stream.cpu().contiguous()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    _write_st(path, tensors)


def mirror_to_central(latent, anchor):
    """把当前采样 latent 归到导演台当前段，并直接写统一编号的 cont 文件。"""
    from . import csglide_chain as chain
    from .csglide_clip import CSGlideClipSaveCS

    name = chain.last_name()
    if not name:
        print("%s 导演台还没登记过工程名，本次不能使用统一编号存档。" % _TAG)
        return None

    cid = ((chain.load_chain(name) or {}).get("current") or "").strip()
    if not cid or chain.load_clip(name, cid) is None:
        print("%s 导演台还没有登记当前段，本次不能使用统一编号存档。" % _TAG)
        return None

    meta = chain.load_clip(name, cid) or {}
    seed = int(meta.get("seed") or 0)

    # 先让段落存档生成/确认当前 take 与 .latent 文件。
    cid_out, _report = CSGlideClipSaveCS().save(
        潜空间=latent, 片名=name, 段落=cid, 提示词="",
        帧数=0, 种子=seed, 另存为版本=True, 顺序锚=anchor)
    if cid_out:
        cid = cid_out

    meta = chain.load_clip(name, cid) or {}
    take = max(1, int(meta.get("current_take") or 1))
    latent_path = chain.clip_latent(name, cid, take)
    cont_path = chain.clip_cont(name, cid, take)

    _write_latent_copy(latent, cont_path)
    _set_last_saved(cont_path)

    print("%s 已统一归档：%s / %s / take %d，cont=%s"
          % (_TAG, name, cid, take, os.path.basename(cont_path)))
    return {
        "name": name,
        "cid": cid,
        "take": take,
        "latent_path": latent_path,
        "cont_path": cont_path,
    }


def apply_archive(cls_map):
    """给续拍存档节点补「顺序锚」口、撤掉保存计数控件，并接入中央统一编号。"""
    cls = cls_map.get(_NODE_ID)
    if cls is None:
        return False
    try:
        # 取未绑定的原函数，避免 classmethod 包装后多传一次 cls。
        orig_input = cls.INPUT_TYPES.__func__

        def _patched_input(cls, *a, **k):
            data = orig_input(cls, *a, **k)
            required = data.get("required") or {}
            # 保存路径和本片段编号不再交给用户；统一由导演台当前段/take 决定。
            required.pop("filename_prefix", None)
            required.pop("clip_index", None)
            # 开关设为可选（默认开）：老工作流/老模板没有这个控件也不会被判缺字段，
            # 且可选控件同样会随工作流提交、带默认值，中央选片能照常读到状态。
            data.setdefault("optional", {})["archive_enabled"] = _ENABLED_SPEC
            data.setdefault("optional", {}).setdefault("顺序锚", _ANCHOR_SPEC)
            return data

        cls.INPUT_TYPES = classmethod(_patched_input)

        def _patched(self, *a, **kw):
            latent = kw.pop("latent", None)
            if latent is None and a:
                latent = a[0]
            anchor = kw.pop("顺序锚", None)

            # 开关关闭：纯透传，不写档、不推进 take、不登记段落（20261017）。
            if not kw.pop("archive_enabled", True):
                return (latent,)

            stale = []
            for key in ("filename_prefix", "clip_index"):
                if key in kw:
                    value = kw.pop(key)
                    if value not in (None, "", 0):
                        stale.append("%s=%r" % (key, value))
            if stale:
                print("%s 旧参数 %s 已失效；现在按中央段落/take 统一编号。"
                      % (_TAG, "、".join(stale)))

            info = mirror_to_central(latent, anchor)
            if info is None:
                raise RuntimeError(
                    "H3 续拍存档：先让导演台登记当前段；本节点不再使用保存计数。")
            # 输出仍为 latent 直通，供后续 VAE 解码和二采链使用。
            return (latent,)

        cls.save = _patched
        return True
    except Exception as e:
        print("⚠️ [班长全家桶] 续拍存档统一编号未挂载: %s" % e)
        return False
