/* ============================================================
 * 画布运行对齐（20261017）
 * ------------------------------------------------------------
 * 为什么要有这一层：
 *   画 ▶ / Ctrl+Enter 走的是 ComfyUI 原生提交，交出去的是「画布 widget 此刻
 *   的字面量」。但导演台 / 文案台 / 媒体架的真实状态住在面板闭包与中央库里
 *   ——两者不同步时，后端读到的就是空提示词、空素材、空段落 id；而空 clip
 *   还会被当成「新建一段」，于是你以为在重跑第 2 段，时间轴上却多出一个新段。
 *
 *   20261023 起改用**编译式渲染**（bz_prompt_build）：按段身份把三个
 *   *_data 整块覆写成"这一段自己的数据"，而不是"打补丁修画布字面量"。
 *   「全部渲染」的 queueOnce 走的是同一份编译函数，两条提交路径从此不可能
 *   出现"一个对一个错"。
 *
 * 边界（很重要）：
 *   · 只在提交对象里含导演台时才介入，普通工作流完全不受影响
 *   · 编译失败退回旧的提交对齐；再失败就按原样提交 —— 对齐/编译失败绝不能
 *     把用户手点的运行拦下来
 *   · 不改 ComfyUI 任何文件，只是把 api.queuePrompt 换了个包装
 *
 * 不弹窗（20261026 用户定）：
 *   对齐/编译的结果只写 console，不在屏幕右下角弹 toast。画布运行是最高频的
 *   动作，每次提交弹一条「班长 · 提交对齐」纯属噪音 —— 结果对不对看画面就知道，
 *   真要排障控制台里有 [编译] / [班长] 两行。
 *
 * 补不到的部分（设计如此，不是本文件的缺陷）：
 *   逐段切换、自动续写、批量跑多段仍在「全部渲染」的循环里。这里的对齐只让
 *   单次运行等价于「全部渲染 · 只跑当前这一段」。
 * ============================================================ */
import { app } from "../../scripts/app.js";
import { api } from "../../scripts/api.js";
import { projectStore } from "./bz_project_store.js";
import { promptBuild, lineOf } from "./bz_prompt_build.js";
import { noteCompile } from "./bz_audit.js";

const CAST = "CSGlideCastCS";
let patched = false;

/** 画布上的导演台节点（面板状态挂在 node.h3ui.st 上，与「全部渲染」同一份）。 */
function castNodeOf() {
  const g = (typeof app !== "undefined" && app && app.graph) || null;
  const nodes = (g && (g._nodes || g.nodes)) || [];
  for (const n of nodes) {
    if (n && n.type === CAST) return n;
  }
  return null;
}

/** 这次提交里有没有导演台 —— 没有就当普通工作流，一律不碰。 */
function hasCastIn(prompt) {
  const out = (prompt && prompt.output) || {};
  for (const k of Object.keys(out)) {
    if (out[k] && out[k].class_type === CAST) return true;
  }
  return false;
}

function install() {
  if (patched || !api || typeof api.queuePrompt !== "function") return false;
  const orig = api.queuePrompt.bind(api);

  api.queuePrompt = async function (number, workflow, ...rest) {
    try {
      /* 「全部渲染」的循环里已经 flush + applyToPrompt 过了，它提交的每一段
         都会经过这里 —— 再做一遍纯属重复劳动，直接放行。 */
      if (projectStore.isGloballyRendering && projectStore.isGloballyRendering()) {
        return orig(number, workflow, ...rest);
      }
      if (hasCastIn(workflow)) {
        const node = castNodeOf();
        const st = node && node.h3ui && node.h3ui.st;
        if (st) {
          const chain = st.chain || {};
          const clip = String(chain.clip || "");
          /* 等三节点在途落库，保证提交那一刻前端缓存 = 后端 */
          await projectStore.flushWrites(String(chain.name || ""));
          let msg = "";
          try {
            /* 编译：三个 *_data 整块换成本段数据（与「全部渲染」同一份函数） */
            const built = promptBuild.apply(workflow, node, clip);
            console.log("[编译] " + lineOf(built.receipt));
            noteCompile(built.receipt, node.h3ui);
            msg = "画布运行已编译到段 " + (clip || "(未登记)")
              + "（" + built.receipt.patched.join("/") + "）";
          } catch (e) {
            /* 编译不出来（段身份对不上 / 面板还没就绪）时退回旧的提交对齐：
               手点的运行不能被一个"编译错误"拦下，用户此刻要的是出画面。 */
            console.warn("[班长] 画布运行编译失败，退回提交对齐：", e);
            const touched = projectStore.applyToPrompt(workflow, node, clip);
            if (touched.length) {
              msg = "画布运行已退回对齐到段 " + (clip || "(未指定)")
                + "（" + touched.join("/") + "）";
            }
          }
          if (msg) console.log("[班长] " + msg);
        }
      }
    } catch (e) {
      console.warn("[班长] 提交前对齐失败，已按原样提交：", e);
    }
    /* 提交失败的兜底：浏览器对 fetch 失败只给一句 "TypeError: Failed to fetch"，
       而这几乎总是「后端不可达」（进程崩溃 / OOM 退出 / 正在重启），不是脚本 bug。
       原始错误冒出去时会被算在本文件头上（因为 queuePrompt 是本文件包装的），
       所以这里换成一句能照着查的话再抛。 */
    try {
      return await orig(number, workflow, ...rest);
    } catch (e) {
      if (e instanceof TypeError && /failed to fetch/i.test(String(e.message || ""))) {
        console.error("[班长] 提交失败：连不上 ComfyUI 后端（进程可能已崩溃/OOM 退出或正在重启）。"
                      + "请查看启动黑窗口的最后几行。");
        throw new Error("连不上 ComfyUI 后端（不是脚本问题）：请检查启动黑窗口是否已退出或报错。");
      }
      throw e;
    }
  };

  patched = true;
  console.log("[班长] 画布运行对齐已安装");
  return true;
}

/* api 与本模块的加载顺序不保证：装不上就退避重试，而不是一次失败就永久失效
   （首版就是因为顶层只试一次、又静默跳过，才看着像"补丁没生效"）。
   一直装不上只报错一次，绝不拖慢或阻断任何提交。 */
function ensurePatch(tries) {
  if (install()) return;
  if (tries > 0) { setTimeout(() => ensurePatch(tries - 1), 300); return; }
  console.error("[班长] 画布运行对齐未能安装：api.queuePrompt 一直不可用");
}

ensurePatch(20);
