import { app } from "../../scripts/app.js";
import { api } from "../../scripts/api.js";

// ═══════════════════════════════════════════════════════════════════════
//  🪞 人脸修复台 · 苹果风极简单页（全自动，无按钮、无参数滑块）
//  工作流执行即自动检测 + 出掩码；面板只展示检测到的人脸缩略图与状态。
//  卡片高度按人脸行数推导（1–3 行，超出滚动），行高固定，与宽度无关 ——
//  避免「宽度 ↔ aspect-ratio 高度」互相触发的那条自激回路。
// ═══════════════════════════════════════════════════════════════════════

const PANEL_W = 480;
const MIN_W = 400;
const W_KEY = "facefix_width";
const PAD = 10;
const TOOLBAR_H = 44;
const HEAD_H = 22;        // 卡片内「全自动 / 检测到 N 张脸」一行
const TILE_H = 132;       // 固定行高，不随宽度变化
const GAP = 8;
const MAX_ROWS = 2;      // 最多两行（≤6 张），再多在卡片内滚动，避免节点过高
const STATUS_H = 20;
const COLS = 3;

const C = {
  blue: "#0A84FF", green: "#30D158", red: "#FF453A",
  line: "rgba(255,255,255,.1)",
};

function ensureStyles() {
  if (document.getElementById("bz-facefix-style")) return;
  const css = `
  .bz-ff-root{width:100%;height:100%;box-sizing:border-box;padding:${PAD}px;border-radius:10px;color:#f5f5f7;
    background:linear-gradient(180deg,#1d1d22,#141418);border:none;overflow:hidden;
    font-family:-apple-system,BlinkMacSystemFont,"SF Pro Text","Segoe UI","PingFang SC","Microsoft YaHei",sans-serif;}
  .bz-ff-toolbar{display:flex;align-items:center;gap:8px;height:${TOOLBAR_H}px;margin-bottom:10px;}
  .bz-ff-title{font-size:13px;font-weight:700;white-space:nowrap;}
  .bz-ff-spacer{flex:1;}
  .bz-ff-prompt{width:150px;height:24px;box-sizing:border-box;padding:0 8px;font-size:11px;
    color:#f5f5f7;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.12);
    border-radius:6px;outline:none;font-family:inherit;}
  .bz-ff-prompt::placeholder{color:rgba(255,255,255,.32);}
  .bz-ff-prompt:focus{border-color:${C.blue};background:rgba(10,132,255,.14);}
  .bz-ff-dot{width:9px;height:9px;border-radius:50%;flex:none;background:${C.green};
    box-shadow:0 0 8px rgba(48,209,88,.6);}
  .bz-ff-dot.busy{background:${C.blue};box-shadow:0 0 8px rgba(10,132,255,.6);}
  .bz-ff-dot.err{background:${C.red};box-shadow:0 0 8px rgba(255,69,58,.6);}
  .bz-ff-card{box-sizing:border-box;border:1px solid ${C.line};border-radius:10px;
    background:rgba(0,0,0,.3);padding:${PAD}px;display:flex;flex-direction:column;overflow:hidden;}
  .bz-ff-head{display:flex;align-items:baseline;gap:8px;height:${HEAD_H}px;flex:none;}
  .bz-ff-auto{font-size:11px;font-weight:700;color:${C.green};}
  .bz-ff-count{font-size:11px;color:rgba(255,255,255,.6);}
  .bz-ff-grid{flex:1;min-height:0;overflow-y:auto;scrollbar-gutter:stable;
    display:grid;grid-template-columns:repeat(${COLS},1fr);gap:${GAP}px;align-content:start;}
  .bz-ff-thumb{position:relative;height:${TILE_H}px;border-radius:8px;overflow:hidden;
    background:rgba(255,255,255,.05);}
  .bz-ff-thumb img{width:100%;height:100%;object-fit:cover;display:block;}
  .bz-ff-thumb .tag{position:absolute;left:4px;bottom:4px;font-size:9.5px;color:#fff;
    background:rgba(0,0,0,.55);padding:1px 6px;border-radius:6px;}
  .bz-ff-empty{display:flex;align-items:center;justify-content:center;height:${TILE_H}px;
    font-size:12px;color:rgba(255,255,255,.4);text-align:center;line-height:1.6;white-space:pre-line;
    grid-column:1 / -1;}
  .bz-ff-status{font-size:10.5px;color:rgba(255,255,255,.55);height:${STATUS_H}px;line-height:16px;
    padding-top:4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
  `;
  const style = document.createElement("style");
  style.id = "bz-facefix-style";
  style.textContent = css;
  document.head.appendChild(style);
}

function el(tag, cls, parent) {
  const node = document.createElement(tag);
  if (cls) node.className = cls;
  if (parent) parent.appendChild(node);
  return node;
}

function hideWidget(w) {
  if (!w) return;
  w.hidden = true;
  w.computeSize = () => [0, -4];
  w.draw = () => {};
  w.mouse = () => {};
}

// 内部 name 英文蛇形，仅钉显示用中文 label
const PORT_LABELS = {
  h3_latent: "一采潜空间",
  sam3_model: "SAM3.1模型",
  sam3_clip: "SAM3.1文本编码",
  detect_frames: "检测帧(可选)",
  vae: "解码VAE(可选)",
  model: "H3修复模型(可选)",
};

function pinPortLabels(n) {
  for (const s of n.inputs || []) {
    const key = String(s.name || "").toLowerCase();
    if (PORT_LABELS[key]) s.label = PORT_LABELS[key];
  }
}

app.registerExtension({
  name: "BanZhang.FaceFixStudio",
  async beforeRegisterNodeDef(nodeType, nodeData) {
    if (nodeData?.name !== "BanZhang_FaceFixStudio") return;

    const chain = (target, name, fn) => {
      const old = target[name];
      target[name] = function (...args) {
        if (old) old.apply(this, args);
        return fn.apply(this, args);
      };
    };

    chain(nodeType.prototype, "onNodeCreated", function () {
      ensureStyles();
      const node = this;
      node.properties = node.properties || {};

      const wMap = {};
      // sam3_prompt 由面板顶部的输入框代理，原生 widget 收起来只留值
      const HIDDEN_WIDGETS = ["project_data", "sam3_prompt"];
      function bindWidgets() {
        for (const name of HIDDEN_WIDGETS) {
          const w = (node.widgets || []).find((x) => x.name === name);
          if (!w) continue;
          wMap[name] = w;
          hideWidget(w);
        }
      }
      bindWidgets();

      const state = { project: { faces: [] } };

      // ── 工具栏：标题 + 提示词 + 状态点 ─────────────────────────
      const root = el("div", "bz-ff-root");
      const toolbar = el("div", "bz-ff-toolbar", root);
      el("span", "bz-ff-title", toolbar).textContent = "🪞 人脸修复台";
      el("div", "bz-ff-spacer", toolbar);
      const promptInput = el("input", "bz-ff-prompt", toolbar);
      promptInput.type = "text";
      promptInput.placeholder = "人脸提示词";
      promptInput.spellcheck = false;
      promptInput.title = "SAM3.1 开放词汇提示词，默认 face；改「人脸」等同义也行";
      const dot = el("span", "bz-ff-dot", toolbar);

      // ── 人脸缩略图卡片 ─────────────────────────────────────────
      const card = el("div", "bz-ff-card", root);
      const head = el("div", "bz-ff-head", card);
      el("div", "bz-ff-auto", head).textContent = "全自动";
      const count = el("div", "bz-ff-count", head);
      const grid = el("div", "bz-ff-grid", card);

      const statusLine = el("div", "bz-ff-status", root);

      function setStatus(text, tone) {
        statusLine.textContent = text;
        statusLine.title = text;
        dot.className = "bz-ff-dot" + (tone === "busy" ? " busy" : tone === "err" ? " err" : "");
      }

      // 提示词：面板输入框 ↔ 隐藏 widget 双向同步（值随工作流存档走）
      function promptFromWidget() {
        const w = wMap.sam3_prompt;
        promptInput.value = (w && w.value) || "face";
      }
      // 打字时只同步值，失焦/回车才标脏，避免每敲一个字都刷「未保存」
      promptInput.addEventListener("input", () => {
        const w = wMap.sam3_prompt;
        if (w) w.value = promptInput.value;
      });
      promptInput.addEventListener("change", () => {
        const w = wMap.sam3_prompt;
        if (w) {
          w.value = promptInput.value;
          node.graph?.change?.();
        }
      });
      // 打字/滚轮别冒到画布，否则会触发画布快捷键
      ["pointerdown", "keydown", "keyup", "wheel"].forEach((ev) =>
        promptInput.addEventListener(ev, (e) => e.stopPropagation()));
      promptFromWidget();

      // 卡片高度 = 表头 + 行数×行高 + 行间距；行高固定，与节点宽度无关
      function cardHeight() {
        const n = (state.project.faces || []).length;
        const rows = Math.min(MAX_ROWS, Math.max(1, Math.ceil(n / COLS)));
        return HEAD_H + rows * TILE_H + (rows - 1) * GAP + PAD * 2;
      }
      function panelHeight() {
        return PAD * 2 + TOOLBAR_H + 10 + cardHeight() + STATUS_H;
      }
      function wantWidth() {
        return Math.max(node.properties[W_KEY] || PANEL_W, MIN_W);
      }
      // 节点高度必须由 litegraph 推：它先算输入端口占的行高，再叠 DOM 面板的
      // computeSize。手算「标题 + 面板高」会漏掉端口那几行 → 面板压住最后一个端口、
      // 底部内容被裁掉（2026-11-01 截图实测）。
      function nodeHeight() {
        const computed = node.computeSize ? node.computeSize() : null;
        return computed ? computed[1]
          : (LiteGraph.NODE_TITLE_HEIGHT || 30) + panelHeight();
      }
      function applySize() {
        card.style.height = cardHeight() + "px";
        if (node._bz_fixingW) return;
        node._bz_fixingW = true;
        node.setSize([wantWidth(), nodeHeight()]);
        node._bz_fixingW = false;
      }

      let lastRaw = "";
      function syncProject() {
        const raw = JSON.stringify(state.project);
        if (wMap.project_data) wMap.project_data.value = raw;
        node.properties.facefix_project = raw;
        // 只有内容真变了才标脏，重复执行同样结果不再刷「未保存」
        if (raw !== lastRaw) {
          lastRaw = raw;
          node.graph?.change?.();
        }
      }

      function renderFaces() {
        grid.innerHTML = "";
        const faces = state.project.faces || [];
        count.textContent = faces.length ? `检测到 ${faces.length} 张脸` : "";
        if (!faces.length) {
          el("div", "bz-ff-empty", grid).textContent =
            "工作流执行后自动检测人脸\n接「SAM3.1模型」+「SAM3.1文本编码」\n此处显示识别到的人脸缩略图";
          return;
        }
        faces.forEach((f, i) => {
          const thumb = el("div", "bz-ff-thumb", grid);
          if (f.thumb) {
            const img = document.createElement("img");
            img.src = f.thumb;
            img.alt = "脸 " + (i + 1);
            thumb.appendChild(img);
          }
          const tag = el("span", "tag", thumb);
          tag.textContent = "脸 " + (i + 1);
        });
      }

      function renderAll() {
        renderFaces();
        applySize();
      }

      function applyResult(fullJson, report) {
        if (Array.isArray(fullJson)) fullJson = fullJson[0];
        if (fullJson) {
          try {
            const proj = JSON.parse(fullJson);
            if (proj && typeof proj === "object") {
              state.project = proj;
              renderAll();
              syncProject();
            }
          } catch (e) {
            console.error("[人脸修复台] 回执 JSON 解析失败", e);
          }
        }
        let rep = report;
        if (Array.isArray(rep)) rep = rep.join("\n");
        if (rep) {
          const tone = rep.startsWith("⚠️") || rep.startsWith("❌") ? "err" : "";
          setStatus(String(rep).split("\n")[0], tone);
          statusLine.title = String(rep);
        }
      }

      function onExecuted(detail) {
        if (String(detail.node) !== String(node.id)) return;
        const out = detail.output || {};
        applyResult(out.project, out.report);
      }

      const onExecHandler = (e) => onExecuted(e.detail);
      api.addEventListener("executed", onExecHandler);
      const onErrHandler = (e) => {
        const d = (e && e.detail) || {};
        if (String(d.node_id) !== String(node.id)) return;
        const msg = d.exception_message || d.exception_type || "未知错误";
        setStatus("❌ 执行失败：" + msg, "err");
      };
      api.addEventListener("execution_error", onErrHandler);
      chain(node, "onRemoved", function () {
        api.removeEventListener("executed", onExecHandler);
        api.removeEventListener("execution_error", onErrHandler);
      });

      // ── 尺寸双通道 ─────────────────────────────────────────────
      const domWidget = node.addDOMWidget(
        "facefix_panel", "facefix", root, { serialize: false });
      node.widgets.unshift(node.widgets.pop());
      if (domWidget) {
        // 旧引擎（litegraph）问 computeSize，新引擎（v2 VueNodes）问 computeLayoutSize，
        // 两个都必须报「真实内容高」，缺一个就会按默认值排布 → 面板溢出/压住端口
        domWidget.computeSize = () => [node.size[0], panelHeight()];
        domWidget.computeLayoutSize = () => ({
          minHeight: panelHeight(), maxHeight: undefined, minWidth: 0,
        });
      }
      card.style.height = cardHeight() + "px";
      applySize();

      chain(node, "onResize", function (size) {
        if (app.canvas && app.canvas.resizing_node === node) {
          // 用户亲手拖：只记宽度真值，高度由内容推导，松手后下次渲染再对齐
          node.properties[W_KEY] = Math.round(size[0]);
          return;
        }
        const wantW = wantWidth();
        const wantH = nodeHeight();
        if (Math.abs(size[0] - wantW) > 1 && !node._bz_fixingW) {
          node._bz_fixingW = true;
          node.setSize([wantW, wantH]);
          node._bz_fixingW = false;
          return;
        }
        if (Math.abs(size[1] - wantH) > 1) size[1] = wantH;
      });

      // 旧工作流存档会带着已删除的端口（参考脸/正条件/多身份条件），litegraph 的
      // configure 会照抄存档 inputs 重建 slot —— 后端已无定义，留着只会误导接线。
      // 白名单只认后端 schema（单一真值），取不到才退回本地端口表。
      function knownInputs() {
        const def = node.constructor?.nodeData?.input;
        const names = new Set();
        for (const grp of [def?.required, def?.optional]) {
          if (grp) Object.keys(grp).forEach((k) => names.add(k.toLowerCase()));
        }
        if (!names.size) Object.keys(PORT_LABELS).forEach((k) => names.add(k));
        return names;
      }
      function pruneStaleSlots() {
        const known = knownInputs();
        const inputs = node.inputs || [];
        for (let i = inputs.length - 1; i >= 0; i--) {
          if (!known.has(String(inputs[i].name || "").toLowerCase())) {
            try { node.removeInput(i); } catch (_) {}
          }
        }
      }

      chain(node, "onConfigure", function () {
        bindWidgets();
        promptFromWidget();
        const raw = node.properties?.facefix_project;
        if (raw) {
          try {
            state.project = JSON.parse(raw);
            renderAll();
          } catch (_) {}
        }
        pruneStaleSlots();
        pinPortLabels(node);
        requestAnimationFrame(() => {
          promptFromWidget();
          pruneStaleSlots();
          pinPortLabels(node);
          applySize();
        });
      });

      pinPortLabels(node);
      renderAll();
    });

    // 接线变化会重建 slot，补钉中文标签
    chain(nodeType.prototype, "onConnectionsChange", function () {
      pinPortLabels(this);
    });
  },
});
